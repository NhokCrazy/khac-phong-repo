# KP Auto 0.8.9 — Kịch bản dùng chung trên Dopamine và RootHide

Hai gói jailbreak dùng chung JavaScript runtime và API; chỉ khác kiến trúc gói, dependency và đường dẫn bootstrap. Kịch bản xuất ra không cần thay `/var/jb` hoặc `jbroot` khi chuyển giữa hai loại. Mỗi máy vẫn dùng cấu hình, DATA, tài khoản và vùng Crane riêng.

Bản 0.8.9 giữ đủ cửa sổ chờ phản hồi 41 giây của thao tác Crane thay vì bị IPC cắt sau 30 giây, với giới hạn transport tối đa 45 giây. Các phản hồi boolean native được chuẩn hóa về JSON `true`/`false` để kịch bản so sánh chặt nhận đúng kiểu dữ liệu. Không tự thử lại thao tác có kết quả chưa rõ.

Khi đóng hẳn rồi mở lại tool, phiên mới về **Sẵn Sàng**; cấu hình, DATA và kết quả đã lưu được giữ. Bản cập nhật không ghi đè các kịch bản JS đã nhập.

## 0.8.5 — Chọn dấu hiệu kết thúc khi ghi

Khi ghi kịch bản mới, mở menu logo và nhấn **CHỌN KẾT THÚC**, rồi chọn chữ hoặc nút đang hiện trong ứng dụng. Thao tác chọn lưu một bước **KẾT THÚC** và kết thúc phiên ghi. Có thể hủy chọn để tiếp tục ghi. Khi phát lại, tool chờ đúng phần tử và nội dung đã chọn xuất hiện ổn định trước khi hoàn tất lượt; không tự nhấn nút được chọn làm dấu hiệu.

Bước KẾT THÚC nằm cuối các bước đang bật. Có thể sửa tên và thời gian chờ trong danh sách bước. Hết thời gian mà chưa thấy dấu hiệu thì báo `END_CONDITION_NOT_MET`, không ghi hoàn tất. Kịch bản cũ chưa có bước này giữ hành vi hiện tại; khi cần nối thêm vào kịch bản đã có dấu hiệu kết thúc, tắt hoặc xóa bước KẾT THÚC trước.

## 0.8.4 — Hỗ trợ AEON có sẵn trong gói cài

Gói cài mới tích hợp module Flutter riêng cho AEON Wallet cùng dữ liệu nhận diện công khai. Máy cài mới không cần chạy bộ cài hỗ trợ AEON trên PC. Module chỉ nạp vào `jp.co.aeon.credit.ios.wallet`; kịch bản, DATA, key, vùng Crane và bố cục KP Auto được giữ nguyên.

Hai bản Dopamine thường/rootless và Dopamine RootHide vẫn tách riêng, yêu cầu iOS 16. Bản phát hành phải có đủ `arm64` và `arm64e` ABI hiện đại trong cả ba dylib, dành cho iPhone 8/X, SE2 và các dòng A12+ chạy jailbreak phù hợp. Kiến trúc trong tên DEB xác định loại bootstrap, không phải danh sách chip bị giới hạn. Bản biên dịch Windows chỉ có `arm64`, dùng kiểm tra nội bộ; bản phát hành dùng macOS/Xcode và kiểm tra từng slice trước khi đóng gói.

Đã xác định trực tiếp trên SE2/iOS 16.0.2 RootHide: KP Auto 0.8.3 mở được AEON Wallet nhưng kịch bản dừng `STARTUP_REQUIRED` do thiếu module AEON. Sau khi bổ sung module, máy đọc được 42 phần tử và nút `同意する`, dữ liệu nhận diện sẵn sàng; người dùng xác nhận chạy được. Đây là bằng chứng trên SE2 cho phần hỗ trợ vừa tích hợp; không khẳng định đã thử mọi dòng máy hoặc rootless trên thiết bị thật.

## 0.8.3 — Sao lưu & làm trắng / Restore

Tab **Backup** có chọn iAEON, đặt tên bản sao, **SAO LƯU & LÀM TRẮNG**, và Restore hồ sơ trên cùng iPhone. Bản sao chứa dữ liệu app cùng hai nhóm Keychain đã xác minh từ chữ ký app; được mã hóa AES-256 với HMAC-SHA256, khóa riêng lưu trong Keychain `ThisDeviceOnly`. Không lưu mật khẩu/token vào log, UI, Google Sheet hay PC. Mỗi file được ràng buộc bằng SHA-256 trong manifest mã hóa. Bản đầu chỉ hỗ trợ iAEON, phiên bản app phải trùng bản sao.

Bản 0.8.3 đổi thao tác chính thành **SAO LƯU & LÀM TRẮNG**: ghi bản sao mã hóa, đọc lại manifest và toàn bộ tệp để xác minh, rồi mới thay dữ liệu app bằng thư mục trống và xóa đúng nhóm Keychain đã sao lưu. App được giữ đóng sau thao tác; lần mở tiếp theo bắt đầu với dữ liệu trắng. Lỗi trước làm trắng giữ dữ liệu hiện tại; lỗi trong giao dịch hoàn tác dữ liệu/Keychain hoặc giữ bản sao để phục hồi rõ ràng khi bị gián đoạn. Bản sao cũ vẫn dùng được. Người dùng đã thử trên tài khoản iAEON thật với 0.8.3 và xác nhận sao lưu thành công, mở lại iAEON thấy màn hình mới/chưa đăng nhập. Sau đó, người dùng đã khôi phục chính bản sao này và xác nhận mở được thông tin của đúng tài khoản cũ ngay, không cần đăng nhập hoặc SMS. Kiểm tra metadata sau lượt thử thấy bốn bản sao mã hóa, không còn marker phục hồi hay thư mục tạm. Đây là kiểm thử một tài khoản trên cùng iPhone; phiên hết hạn hoặc bị máy chủ thu hồi vẫn có thể cần đăng nhập lại.

Bản 0.8.2 sửa nhận diện đường dẫn `/private/var` và thư mục lưu của RootHide; giữ đúng kiểu chuỗi/dữ liệu của thuộc tính Keychain, phân biệt mục không có dữ liệu với dữ liệu rỗng, và khôi phục khóa public nhập dạng raw mà vẫn kiểm tra vật liệu khóa trước khi ghi. Tab Backup hiển thị nguyên nhân cùng mã lỗi đã lọc an toàn, không hiển thị thông báo thô chứa dữ liệu app.

Tệp quản lý container của iOS được giữ nguyên trên máy. Bản sao không chứa nội dung `Library/Caches` có thể tạo lại; vẫn giữ Documents, dữ liệu Library khác và Keychain. Điều này tránh lỗi hardlink trong cache của iAEON mà không nới kiểm tra hardlink đối với dữ liệu phiên. Phân loại cache theo [hướng dẫn filesystem của Apple](https://developer.apple.com/documentation/foundation/using-the-file-system-effectively).

Liên kết `IndexedDB/v0` chuẩn của WebKit được giữ cùng dữ liệu DB: chỉ chấp nhận liên kết tới chính thư mục IndexedDB chứa nó, lưu/khôi phục thành `.` và không duyệt xuyên liên kết. Manifest từ chối liên kết khác hoặc mục con đi qua alias. Kiểm tra chỉ đọc trên iAEON thật đã qua toàn bộ bước thư mục và Keychain; chưa thay dữ liệu tài khoản trong lượt kiểm tra này.

Trước Restore, tool giữ một bản dự phòng đầy đủ. App phải dừng khi đổi dữ liệu; lỗi trước ghi giữ nguyên Keychain, lỗi sau ghi rollback cả dữ liệu và Keychain. Marker phục hồi được công bố nguyên tử và đồng bộ trước mutation. Nếu bị gián đoạn, tab Backup chỉ cho chọn đúng bản dự phòng để khôi phục; không tự Restore khi mở tab. Không sửa UUID/User-Agent, không chép `keychain.db` hệ thống và không dùng Crane để lưu/khôi phục. Vùng Crane không phải DEFAULT, nhóm dùng chung, Keychain không thể xuất, chứng chỉ/identity chưa hỗ trợ, mục đồng bộ iCloud, user view không hỗ trợ hoặc phiên không đọc được sẽ bị từ chối trước thao tác.

Ngày 2026-10-11, fixture trên iPhone 8/iOS 16.1.1 RootHide đã kiểm tra mã hóa/HMAC, giới hạn scope và ACL, sao lưu/khôi phục filesystem + Keychain thực với dữ liệu giả, bản dự phòng, rollback, giữ persistent reference khi lỗi trước ghi Keychain, lỗi đồng bộ marker, phục hồi sau gián đoạn mô phỏng và từ chối tráo blob hợp lệ. Khóa RSA public/private và AES-256 mẫu đã khôi phục đúng dữ liệu; RSA tiếp tục ký/xác minh được, dữ liệu khóa hỏng bị từ chối trước ghi. Quyền truy cập và lớp bảo vệ giữ nguyên. Chính sách UserPresence không bị bỏ: tạo fixture bảo vệ bị hệ thống từ chối khi không cho hiện xác thực, không tạo item dở. Sao lưu tài khoản iAEON thật trên 0.8.2 đã thành công qua UI; kiểm tra chỉ đọc xác nhận một bản sao có manifest mã hóa, không có marker phục hồi hoặc thư mục tạm. Người dùng đã xác nhận khôi phục 0.8.2 thành công; kiểm tra metadata thấy hai bản sao mã hóa, không còn marker phục hồi/thư mục tạm. Chưa thử chuyển giữa hai tài khoản thật; token hết hạn/thu hồi vẫn cần đăng nhập hoặc SMS. Rootless đã build, chưa thử thiết bị rootless/A12+.

## 0.7.7 — Ghi nút iAEON / Ionic

Đọc trực tiếp file `reg aeon` trên iPhone xác nhận 18 bước đều là `unsupported`: 12 `RECORD_PAGE_UNSUPPORTED` và 6 `RECORD_ELEMENT_UNSUPPORTED`. Giao diện iAEON (`jp.co.aeonst.app.myaeon`) dùng `ionic://com.iaeon:8100/tabs/home` và nút trong open Shadow DOM. Các bước lỗi cũ không chứa danh tính hoặc thao tác thật để khôi phục; cần ghi lại sau cập nhật. Không thay đổi file cũ hoặc DATA.

Bộ ghi hỗ trợ trang app nội bộ Ionic/Capacitor với origin gồm scheme + host + port (nếu có), vẫn so khớp đường dẫn trang và bundle app. Nút/ô nhập trong open Shadow DOM giữ selector của từng host và phần tử đích; bộ chạy so khớp duy nhất từng lớp trước thao tác. Không lưu tọa độ, dữ liệu nhập, query hoặc fragment. Các trang file/about/data và các lớp đóng hoặc mơ hồ vẫn từ chối.

Thao tác check với ARIA checkbox/radio/switch có thể cập nhật sau khi click. Bộ chạy chỉ click một lần rồi đọc xác minh tối đa 1,5 giây trên cùng document, phần tử, target và trang; không click lại hoặc chuyển sang document mới. Phần tử/trang đổi, mất kết nối hoặc quá hạn thì dừng. Kiểm tra nút bị che đi qua open shadow roots và slot; hộp thoại che nút vẫn chặn thao tác.

352 kiểm thử Node và 45 kiểm thử Python đạt, mỗi bộ có một skip theo môi trường. Native RootHide và rootless build đạt; self-test policy lưu lỗi chạy trực tiếp trên iPhone đạt Ionic/Capacitor, cổng 8100, shadow chain, giới hạn depth và lọc dữ liệu nhạy cảm. Chưa kiểm tra thiết bị rootless/A12+.

Ngày 2026-10-10, readonly trên iAEON xác nhận 22/22 phần tử describe → resolve đúng, 18 trong shadow roots. Sau khi cài 0.7.7, HID thật ghi hai tab キャンペーン → ホーム thành hai bước web/shadow, phát lại đạt `workflowStatus:success` và về `/tabs/home`. Lượt đầu bị hộp thoại hướng dẫn che tab, tool dừng `WAIT_TIMEOUT`; người dùng đóng hướng dẫn rồi lượt thử đạt. Chưa thử đăng ký tài khoản hoặc các checkbox thật của iAEON.

## 0.7.6 — Mở lại với trạng thái chạy mới

Khi tắt hẳn và mở lại KP Auto, trạng thái Hoàn tất/Lỗi/Đã dừng cùng tiến độ/feedback cũ trở về **Sẵn sàng**. Không tự chạy lại kịch bản hoặc tiếp tục từ bước cũ. Kịch bản, DATA, SETTING, key, nhật ký và bộ đếm tên vùng Crane được giữ. Lượt mới trong phiên vẫn hiển thị kết quả bình thường.

Reset chỉ thực hiện lúc tạo tiến trình manager mới. Cùng `run.lock` của worker bảo vệ cả giai đoạn khởi động/chạy/thu hồi; lock bận hoặc worker đúng còn sống thì giữ trạng thái thật. Không reset khi đổi tab hoặc quay về manager từ kịch bản. Các status trong Keychain được giữ để đồng bộ bước nối và nhật ký; session hiển thị trong RAM lọc kết quả cũ.

Fixture chạy trực tiếp trên iPhone đạt reset các trạng thái chết, giữ worker sống, flock thật giữa hai process, từ chối alias state/lock trỏ DATA sentinel và giữ nguyên file script/data/key/counter/history giả lập. Reset giữ kết quả mới nếu state đổi giữa snapshot và lúc lấy lock. Display-session fixture đạt ẩn kết quả cũ, giữ lượt mới/live và lỗi startup chưa có namespace. 326 kiểm thử Node và 45 kiểm thử Python đạt, mỗi bộ có một skip theo môi trường; rootless đã build fixture và kiểm tra cú pháp, chưa thử rootless/A12+ trên thiết bị.

Ngày 2026-10-10 đã cài 0.7.6 trên iPhone 8 RootHide. Người dùng tắt hẳn/mở lại và xác nhận Dashboard Sẵn sàng, kịch bản/DATA còn nguyên. Kiểm tra trực tiếp thấy `state.json` chỉ còn `{status:"idle"}`, không còn pid/runId/code/namespace cũ. Fingerprint toàn bộ 19 file JS trước và sau cài/mở lại khớp hoàn toàn.

## 0.7.5 — Kiểm tra key trên Dashboard

Khi mở KP Auto, Dashboard hiển thị **Đang kiểm tra key…** và vòng xoay. Trong lúc chờ hoặc khi key chưa hợp lệ, chỉ phần key xuất hiện; tab Kịch bản, chỉnh sửa/nhập/xuất và bảng mở nhanh được khóa. Thành công hiển thị **Key hợp lệ** cùng hạn dùng rồi mở các mục khác. Lỗi kết nối, key hoặc Keychain hiển thị ngay trên Dashboard; nhập key và kiểm tra lại key đã lưu đều ở Dashboard, không tự bật cửa sổ key riêng. Nút KÍCH HOẠT nằm trên thanh trên để dùng được khi bàn phím mở.

Mỗi tiến trình manager chỉ tự kiểm tra online một lần lúc mở. Chạy/ghi/kiểm tra/nối kịch bản dùng phiên đã xác thực qua IPC `license.attach` với PID/start time và runId; không kiểm tra Google lại khi bấm chạy và không có heartbeat. Chỉ thao tác kiểm tra lại/kích hoạt key do người dùng chọn mới tạo lượt online khác. Runner ngoài manager vẫn xác thực lúc khởi động. Một lượt check tại một thời điểm, thông báo thay đổi chỉ có trạng thái đã lọc; key và installation seed ở Keychain.

Native fixture chạy trực tiếp trên iPhone với IPC/Keychain giả lập đã xác nhận loading đồng bộ, single-flight, từ chối/kiểm tra lại, giữ key cũ khi candidate lỗi, gate Dashboard, child chuyển về Dashboard không popup và ba worker manager chỉ attach, không tăng số lượt online. Fixture có target riêng và không nằm trong package. 325 kiểm thử Node và 45 kiểm thử Python đạt, mỗi bộ có một skip theo môi trường. Rootless đã kiểm tra cú pháp, chưa kiểm tra thiết bị rootless/A12+.

Ngày 2026-10-10 đã cài 0.7.5 trên iPhone 8 RootHide; người dùng xác nhận loading/vòng xoay trên Dashboard, tab Kịch bản bị khóa tới Key hợp lệ. Hai lượt chạy từ manager của file thử chỉ chờ 1,5 giây đã hoàn tất đúng namespace; `LAST_CHECK_AT` trên Sheet giữ nguyên `2026-10-10T12:40:09.539Z` giữa snapshot trước 21:40:59 và sau 21:43:30 JST, xác nhận RUN không xác thực Google lại. File thử và namespace riêng được dọn sau kiểm tra.

Đồng thời sửa slot manager bị giữ sau khi iOS tự thu hồi child (`SIGCHLD` ignored, `waitpid` trả `ECHILD`). PID worker đã chết không còn làm kịch bản tiếp theo bị chặn; chỉ ghi lỗi cuối khi trạng thái còn running và thuộc đúng child, giữ lỗi DATA và không ghi đè lượt khác. Hai lượt chạy liên tiếp trên máy xác nhận slot được giải phóng.

## 0.7.3 — Sửa logo ghi khi mở Yamada

Đã đọc trực tiếp lỗi `AMBIGUOUS_WEBVIEW` của lượt ghi Yamada trên bản 0.7.2. Bộ ghi và bộ chạy dùng chung cách kiểm tra WebView: cắt theo vùng nhìn của cửa sổ/ancestor và xác nhận vùng đó nhận tương tác; trang cũ bị che không được tính là trang đang thao tác. Hai WebView thực sự tương tác được vẫn báo lỗi thay vì chọn tùy ý. Callback cài bộ ghi cũ không được kết thúc phiên hoặc WebView mới.

Ghi mới chờ tối đa 5 giây khi app/agent chưa sẵn sàng hoặc các WebView còn chuyển trạng thái, chỉ mở app một lần. Timeout/kết quả chưa rõ không phát lại lệnh bắt đầu. `recordStatus` giữ mã lỗi và số bước khi dừng, kể cả queue đã bị khóa do lỗi truyền. DATA chỉ xóa sau khi phiên ghi mới được chấp nhận. 60 kiểm thử recorder đạt; toàn bộ Node đạt 210 pass, 1 skip; Python đạt 45 pass, 1 skip. Các nguồn native đã qua kiểm tra cú pháp RootHide và rootless.

Ngày 2026-10-09 đã cài và respring 0.7.3 trên iPhone 8 RootHide. Native policy chạy trực tiếp trên máy đạt các trường hợp WK bị clip, WK chồng che nhau và hai WK tách biệt; kiểm tra modal window được skip vì helper CLI không có inventory cửa sổ ứng dụng. Người dùng thử lại ghi Yamada và xác nhận logo giữ được, lưu được bước. Trạng thái thiết bị xác nhận bản 0.7.3, mã runtime khớp, phiên ghi từ manager còn chạy và không có mã lỗi. Fixture ứng dụng thử riêng không lên foreground nên không coi bài đó là đã đạt. Chưa thử rootless/A12+ trên thiết bị.

## 0.7.2 — Tên vùng chứa Crane theo số thứ tự

Khi thêm hoặc sửa khối **TẠO VÙNG CHỨA CRANE MỚI**, đặt **SỐ BẮT ĐẦU** từ 0 đến 999999999. Ví dụ đặt 100: vùng mới mang tên 100, 101, 102… **Số kế tiếp** của từng khối được lưu riêng trong Keychain, tiếp tục khi chạy lại hoặc mở lại tool; DATA giữ nguyên. Lưu lại cùng số bắt đầu giữ tiến độ. Đổi số bắt đầu sẽ bắt đầu chuỗi mới từ số vừa đặt.

Khối tạo vùng mới và chuyển sang vùng đó trước khi chạy bước tiếp theo. Nếu tên đã tồn tại, kịch bản dừng và không tự bỏ số. Nếu kết quả tạo/chuyển chưa xác định, lượt chạy sau bị chặn để tránh tạo lặp. Bộ đếm không kèm theo khi xuất JS; các khối cũ thiếu ID được gán ID ổn định để giữ tiến độ.

Ngày 2026-10-09 đã cài và thử trực tiếp 0.7.2 trên iPhone 8 RootHide, app Yamada: hai tiến trình chạy riêng tạo vùng tên 100 rồi 101, tổng vùng 5 → 6 → 7; số kế tiếp lưu là 102. Cả hai lượt chọn đúng vùng mới, chạy bước CHỜ tiếp theo, giữ DATA và chuyển lại vùng cũ số 4. Hai vùng mới được giữ, không xóa vùng hoặc thao tác tài khoản. 206 kiểm thử Node đạt, một skip theo môi trường; 45 kiểm thử Python đạt, một skip theo môi trường. Rootless đã kiểm tra cú pháp; chưa thử rootless/A12+ trên thiết bị.

## 0.7.1 — Tạo vùng chứa Crane mới

**THÊM KHỐI → TẠO VÙNG CHỨA CRANE MỚI** thêm một bước có ID ổn định vào kịch bản. Khi chạy, khối đóng app, tạo đúng một vùng chứa mới có tên tự động, chuyển sang vùng mới bằng API xác thực của Crane, mở lại app rồi tiếp tục bước sau. Giữ vùng cũ, DATA, thứ tự acc và số vòng chạy. Kiểm tra bước đầu/khối tắt không tạo hoặc chuyển vùng. Nếu phản hồi tạo/chuyển không xác định, kịch bản dừng và không gửi lại lệnh tạo.

Ngày 2026-10-09 đã cài và thử trực tiếp 0.7.1 trên iPhone 8 RootHide, app Yamada: 4 → 5 vùng chứa, vùng mới số 5 được chọn, bước CHỜ tiếp theo hoàn tất và DATA của bài thử giữ nguyên. Bài thử chuyển lại đúng vùng cũ số 4, giữ vùng mới, không xóa vùng hoặc thao tác tài khoản. 198 kiểm thử Node và 45 kiểm thử Python đạt, mỗi bộ có một skip theo môi trường. Rootless đã kiểm tra cú pháp; chưa thử rootless/A12+ trên thiết bị.

## 0.7.0 — Nối kịch bản và key Google Sheet

**NỐI KỊCH BẢN** nằm trong màn hình kịch bản và bảng chọn nhanh. Mở sẵn đúng app tới bước cần ghi tiếp, chọn kịch bản cần nối rồi quay lại app trong 2 phút. Mở menu logo và nhấn **BẮT ĐẦU NỐI**; từ lúc đó mới ghi thao tác. **LƯU & NỐI** thêm các bước vào cuối, **HỦY NỐI** bỏ lượt nối. Các bước, DATA, cấu hình và nhánh cũ được giữ. Lượt nối không chạy lại kịch bản, mở URL hay reset app. Đổi app, dừng bằng phím âm lượng, lỗi/thiếu sự kiện hoặc kịch bản bị sửa trong lúc ghi thì không ghi đè phần cũ.

Dashboard có **LICENSE → KEY KP AUTO** để nhập key, lưu key hợp lệ trong Keychain và xem hạn dùng. Xác thực online khi mở KP Auto; trạng thái/hạn dùng được kiểm tra khi mở và không có heartbeat trong phiên chạy. Mỗi key gắn một installation; Sheet quản trị hỗ trợ tạo key, gia hạn, khóa/mở và reset thiết bị. Chi tiết triển khai ở [licensing/README.md](licensing/README.md), mã máy chủ ở [licensing/Code.gs](licensing/Code.gs).

Google Sheet KP Auto License Manager là tài liệu quản trị riêng, chỉ chủ sở hữu có quyền. Apps Script version 1 đã triển khai và `packaging/license.plist` đã có endpoint. Ngày 2026-10-09 đã build, ký, cài 0.7.0 và respring trên iPhone 8 RootHide; controller báo 0.7.0 và touch sẵn sàng. Key thử một ngày đã lưu vào Keychain và gắn thiết bị. Xác thực key hợp lệ, từ chối key DISABLED và key hết hạn đều đã kiểm tra trực tiếp với máy chủ Google.

Kiểm tra local: 56 bài recorder đạt, gồm kịch bản khoảng 40 KB với thông điệp lưu nối dưới giới hạn 64 KiB; 8 bài backend key với mock Sheet đạt. Toàn bộ bộ kiểm thử Node/Python đạt với một skip theo môi trường mỗi bộ; các nguồn native cho RootHide và rootless qua kiểm tra cú pháp iOS. Trên iPhone, `STORAGE_SELF_TEST_OK` và `CATALOG_RENAME_NAMESPACE_DATA_BODY_EXPORT_DELETE_OK` xác nhận CAS Keychain, đồng bộ bước mới ra JS và giữ DATA/mã JS tùy chỉnh. Người dùng đã thao tác trực tiếp trên form Safari loopback có nonce: LƯU & NỐI thêm đúng một bước fill và một bước click, giữ bước gốc/DATA, không lưu chữ TEST; HỦY NỐI bỏ một bước mới và giữ toàn bộ phần cũ. Đã sửa lỗi NSNumber boxing biểu thức BOOL điều kiện thành số 0/1 làm bộ chạy từ chối phản hồi. Logo đóng khi lưu/hủy kết thúc lượt ghi. Không dùng tài khoản hoặc trang thanh toán; chưa thử rootless/A12+ trên thiết bị.

## 0.6.3 — Reset IP, mẫu lỗi và phím dừng

**THÊM KHỐI → RESET IP** bật chế độ máy bay 3 giây, tắt lại và xác nhận trạng thái OFF trước bước tiếp theo. Thao tác kết nối lại mạng di động không bảo đảm nhà mạng cấp một IP công cộng khác. Chế độ kiểm tra bước đầu không thực hiện reset.

Dashboard bỏ thẻ TIẾN ĐỘ và bốn nút trùng. Trạng thái và số kịch bản vẫn có trên Dashboard; chức năng ghi/chạy/quản lý nằm trong tab Kịch bản và logo.

Menu logo có **LƯU LỖI** cả khi ghi, chạy và sau khi dừng: chạm vùng thông báo để lưu mẫu đã che email/OTP, không lấy giá trị ô nhập hoặc tọa độ. Mẫu nằm trong Keychain của đúng kịch bản; helper chỉ được nhận mẫu qua cấp quyền có MAC, PID/app và thời hạn, không ghi DATA hoặc khóa khác. Trong **THÊM KHỐI → NẾU • LỖI ĐÃ LƯU**, chọn mẫu rồi đặt nhánh ĐÚNG/SAI. Mỗi kịch bản giữ tối đa 20 mẫu.

Giữ tăng âm lượng khoảng một giây khi chạy/ghi sẽ dừng ngay bộ chạy, báo VOLUME_STOP trên logo và chặn các bước tiếp theo. Reset chế độ máy bay đang thực hiện có đường tắt lại OFF khi bộ chạy dừng. Khi không có lượt chạy, giữ nút vẫn mở bảng kịch bản. Các thao tác đã gửi cho hệ thống không được phát lại.

166 kiểm tra Node và 45 kiểm tra Python đạt, 2 skip theo môi trường; cả hai scheme đã biên dịch. Đã cài và thử trực tiếp trên iPhone 8 RootHide: RESET IP xác nhận máy bay OFF rồi chạy bước CHỜ tiếp theo; người dùng giữ phím tăng âm lượng và xác nhận dừng ngay, trạng thái lưu `VOLUME_STOP`, không chạy bước sau. Bài LƯU LỖI qua logo sau khi chạy xong lưu đúng một thông báo thử đã che email/OTP; mẫu dùng trong điều kiện NEXT ACC bỏ qua đúng hai hàng DATA giả. Kiểm tra policy native đạt. Người dùng xác nhận Dashboard đã bỏ thẻ/nút trùng và THÊM KHỐI có RESET IP cùng NẾU • LỖI ĐÃ LƯU. Chưa xác nhận thao tác tay trên form chọn mẫu lỗi; bản rootless/A12+ chưa được thử trên thiết bị trong lần sửa này. Các file và Keychain riêng của bài thử được dọn.

## 0.6.2 — Khối Next Container của Crane

**THÊM KHỐI → NEXT CONTAINER (CRANE)** thêm một bước có ID ổn định vào kịch bản. Giữ và kéo tới vị trí cần dùng. Khối chuyển sang container tiếp theo trong thứ tự Crane trả về cho app đã cấu hình, mở lại app rồi chạy bước kế tiếp; không tự chuyển hàng DATA. Container cuối dừng cả kịch bản với `CRANE_AT_END`, hiển thị **Hết container** và không quay về đầu. Kiểm tra bước đầu/khối bị tắt không chuyển container.

Tích hợp qua [libCrane của opa334](https://github.com/opa334/Crane-Resources/blob/master/libCrane/libCrane.h), luôn gọi API có xác thực sinh trắc học nếu Crane yêu cầu; không viết preference Crane hay gọi setter không xác thực. Kiểm tra trạng thái trước khi đóng app; token trạng thái ngăn đổi nhầm nếu danh sách/container đã đổi. Không tạo/xóa container. Kết quả chưa rõ dừng, không tự chuyển lần nữa. Nhật ký lưu chỉ số/tổng số container, không lưu tên, ID container hay dữ liệu bên trong.

164 kiểm tra Node và 45 kiểm tra Python đạt, 2 skip theo môi trường; cả hai scheme đã biên dịch. Đã cài và kiểm tra trên iPhone 8 RootHide: khối chuyển Yamada từ container 3 sang 4, chạy bước CHỜ sau đó; lần NEXT ở container 4 dừng với `CRANE_AT_END` và logo hiển thị Hết container. Người dùng xác nhận thấy khối trong THÊM KHỐI và kéo được trong danh sách bước. Người dùng đã tạo thêm container trong lúc thử; kiểm tra token chặn việc trả về theo trạng thái cũ. Không xóa container, kết thúc vẫn chọn container số 4. Mẫu kịch bản thử và Keychain riêng của mẫu được dọn.

Callback của Crane đang cài trả `false` trên nhánh chuyển không cần sinh trắc học; nhánh sau xác thực trả `true`. Giá trị này không được dùng làm kết quả chuyển. Sau callback, bộ điều khiển chỉ đọc lại và xác nhận chính xác container đích cùng danh sách chưa đổi, không gửi thêm lệnh chuyển. API có xác thực của Crane vẫn là đường duy nhất thực hiện thay đổi. Không xác nhận được thì dừng với kết quả chưa rõ.

## 0.6.1 — Checkbox và nhật ký chạy

Checkbox HTML bị ẩn có thể dùng đúng một nhãn `label` nhìn thấy và liên kết với input đó. Ghi giữ selector và trạng thái `checked`; replay không đảo trạng thái nếu ô đã đúng, và xác minh trạng thái sau thao tác. Nhãn thiếu/mơ hồ, ô bị khóa hoặc thao tác không đổi trạng thái báo lỗi. Không nới quy tắc nhấn các phần tử ẩn khác.

Logo khi chạy có nhãn trạng thái và bước/acc. Mở menu để xem 16 sự kiện gần nhất: bắt đầu bước, xong bước, chuyển nhánh, xong acc và mã lỗi. Khi hoàn tất/dừng/lỗi, giữ trạng thái cuối và log tối đa 5 phút hoặc tới khi nhấn ĐÓNG LOGO. Mất heartbeat hiển thị `RUNNER_DISCONNECTED`. Nhật ký đầy đủ trong kịch bản giữ tối đa 200 sự kiện và có XUẤT NHẬT KÝ. Log không chứa DATA, email, mật khẩu, OTP hay thông báo ngoại lệ tùy ý; phản hồi kết thúc không phát lại thao tác bị timeout.

Đã cài 0.6.1 và thử trực tiếp trên màn hình Yamada `https://cdn.mymd.jp/sp/static/gold/membership/index.html`: input `#terms` có `display:none`, nhãn hiển thị; chạm thật ghi một bước `check`, replay bật checkbox và lần lặp không bỏ tick, log bước hoàn tất. Trả checkbox về trạng thái ban đầu; không nhấn nút đăng ký thành viên. Native xác nhận giữ trạng thái lỗi/dừng/hoàn tất; chạm HID lên logo mở được menu. Người dùng xác nhận nhìn thấy trạng thái và cuộn đọc được log. Các mẫu thử và Keychain riêng của chúng được dọn sau kiểm tra.

160 bài Node và 45 bài Python đạt, 2 bài skip theo môi trường. Cả hai scheme đã biên dịch; kiểm tra trực tiếp ở trên dùng iPhone 8 RootHide. Bản rootless/A12+ chưa được kiểm tra thiết bị trong lần sửa này.

## 0.6.0 — Dashboard và quản lý kịch bản

0.6.0 dùng logo PNG người dùng cung cấp, giữ nguyên file ảnh và nền trong suốt. Giao diện tách hai tab **Dashboard** (trạng thái, tiến độ lượt/acc/bước, số kịch bản và các thao tác chạy/dừng/ghi/kiểm tra) và **Kịch bản**. Nhấn giữ một kịch bản hoặc vuốt chọn TÙY CHỌN để đổi tên, xuất hoặc xóa. Đổi tên giữ nguyên ID/filename để giữ DATA và các nhánh; xóa chuyển file vào `.Deleted`, không xóa DATA Keychain.

**CẤU HÌNH → Số lượt chạy toàn kịch bản** nhận 1–1.000. Mỗi lượt chạy toàn bộ DATA theo thứ tự; dừng sau acc hiện tại chặn cả các lượt tiếp theo. Tiến độ và nhật ký có số lượt.

Controller theo dõi riêng nút tăng âm lượng, giữ một giây để mở trực tiếp bảng chọn **Kịch bản** trong KP Auto qua URL cố định `kpauto://scripts`. Chọn tên rồi bấm CHẠY; runner vẫn kiểm tra khóa chạy và đọc DATA riêng trong Keychain. Không phải truy cập mục tweak hoặc tìm app thủ công. URL chỉ mở bảng, không nhận đường dẫn script hay tự chạy. Cửa sổ UIWindow độc lập trong SpringBoard đã không hiện trên máy thử, nên bảng dùng cửa sổ ứng dụng của KP Auto. Yêu cầu SBS chạy trên luồng nền để SpringBoard tiếp tục xử lý mở ứng dụng. Người dùng đã xác nhận nhìn thấy bảng chọn.

Khi mở, app đang ở phía trước có nhãn **Đang mở kịch bản…** kèm vòng xoay, tự ẩn khi bảng sẵn sàng/chuyển nền hoặc sau tối đa 8 giây. Bảng có trạng thái **Đang tải kịch bản…**, đọc danh sách trên luồng nền, dùng lại thumbnail logo và cache metadata để giảm thời gian chờ. Nhãn không nhận chạm và không được ghi thành thao tác/thông báo lỗi. Sau cài bản loading, người dùng xác nhận giữ nút mở bảng và chạy thành công; chưa có xác nhận riêng về hình thức nhãn loading trong từng app.

Kiểm tra 0.6.0: 154 bài Node và 45 bài Python đạt, 2 bài skip theo môi trường; cả hai scheme đã biên dịch. Helper native trên iPhone xác nhận đổi tên giữ ID/DATA/thân JS, xuất không kèm DATA và xóa vào `.Deleted` giữ DATA. Phím vật lý ghi nhận một yêu cầu mở thành công; người dùng xác nhận bảng hiện và chạy được. Bài riêng qua CLI chỉ mở KidsRepublic và chờ, ghi `round: 2`, `totalRounds: 2`, `completedRows: 2`, `failedRows: 0`, `skippedRows: 0`. Mẫu thử được dọn sau kiểm tra. Build rootless chưa chứng minh hoạt động trên thiết bị rootless/A12+; thao tác đổi tên/xuất/xóa bằng giao diện và Dashboard vẫn cần kiểm tra hình thức bằng tay.

## Nền 0.5.0

0.5.0 thêm logo **KP** nổi 48 pt, kéo đổi vị trí và mở menu ngay trong app. Menu ghi có tạm dừng/tiếp tục, **GHI THÔNG BÁO LỖI** (chọn vùng thông báo để tạo điều kiện) và **LƯU & KẾT THÚC**. Logo giữ trên các cửa sổ của app và chuyển theo scene đang mở; khi chạy lại có tạm dừng và dừng sau acc hiện tại. Logo được đặt lại vị trí nếu che nút native sắp nhấn. Vị trí logo là tùy chọn giao diện, không đi vào các bước ghi.

Trong trình sửa, giữ và kéo một bước để đổi thứ tự. **THÊM NẾU… THÌ…** trên bước hoặc **THÊM KHỐI** tạo điều kiện có/không có phần tử, nội dung thông báo chứa/đúng bằng, DATA trống/có nội dung. Hai nhánh ĐÚNG/SAI cho chọn chạy tiếp, chạy từ một bước, next acc hoặc dừng. Đích dùng ID ổn định nên đổi thứ tự không đổi nhánh; bước đang được tham chiếu phải đổi đích trước khi xóa. Khối CHỜ, MỞ LẠI APP và NEXT ACC có thể đặt vào danh sách. Cấu hình có tùy chọn đóng/mở lại app khi bắt đầu mỗi acc (mặc định giữ màn hình).

**NẾU LỖI THÌ…** định nghĩa quy tắc theo mã lỗi, đích xử lý và tối đa 1–10 lần mỗi acc. Các lỗi có kết quả chưa rõ (`OUTCOME_UNKNOWN`, `NATIVE_TIMEOUT`, phản hồi sai) dừng; không tự nhấn lại hoặc next acc. Có giới hạn tổng bước/vòng lặp. Acc được bỏ qua hiển thị riêng, không tính là hoàn tất bước. **NHẬT KÝ LỖI** lưu tối đa 200 sự kiện theo acc/bước/mã và xuất JSON; không lưu email, mật khẩu, OTP, payload hoặc thông báo ngoại lệ tùy ý trong log.

DATA một acc dùng form từng ô; **NHIỀU ACC** mở danh sách thêm/sửa/xóa bằng form, mật khẩu được che và LƯU luôn ở trên. JSON là lựa chọn nhập nâng cao. Kịch bản/JS xuất ra chỉ chứa thao tác, điều kiện và tên biến; DATA vẫn ở Keychain.

0.5.0 đã cài trên iPhone 8 RootHide. Bài thử KidsRepublic trực tiếp đạt: kéo logo mà không tạo bước giả; logo vẫn hiện sau khi form đăng nhập mở; dùng nút kết thúc; chọn thông báo mẫu trong app để ghi điều kiện và che email/OTP; điều kiện chuyển qua hai acc; lỗi chờ một phần tử không có nhảy tới khối NEXT ACC và lưu đúng hai acc lỗi/bỏ qua. Thông báo lỗi là banner thử tạm trong WebView, đã xóa sau bài thử; không gửi đăng nhập. Bố cục form/danh sách kéo thả đã biên dịch và cài, chưa có bài kiểm tra thao tác tay trực tiếp trên các form này.

Kiểm tra tự động: 152 bài Node và 45 bài Python đạt, 2 bài skip theo môi trường; hai scheme native biên dịch được. Policy UIKit thật trên iPhone đã xác minh selector thông báo không chứa giá trị, che email/OTP và loại bỏ nhãn con nằm trong ô nhập. Controller SpringBoard giữ API 0.4.1; cập nhật agent/giao diện không cần respring.

## Kết quả nền 0.4.1

0.4.1 thêm **CHỌN ỨNG DỤNG** từ app đã cài, native tab/button/control, cell danh sách/lưới, nút có tap gesture và nút Accessibility. Với phần tử không có ID/nhãn, tool dùng đường dẫn trong cây giao diện kèm màn hình; không ghi tọa độ. Khi chạy, tool tìm đúng phần tử trong giao diện hiện tại rồi dùng vị trí hiện tại của phần tử để phát chạm tin cậy, kiểm tra bundle/PID/foreground/deadline trước khi gửi. Phần tử bị che, khớp nhiều mục hoặc đổi màn hình sẽ không được nhấn. Native input tiếp tục gắn biến DATA, không chụp giá trị nhập.

API native: `auto.ui.elements(bundleId)`, `auto.ui.inspect(bundleId,selector)`, `auto.ui.waitFor(bundleId,selector,options)`, `auto.ui.click(bundleId,selector)`, `auto.ui.fill(bundleId,selector,value,{requireEmpty:true})`. `elements` chỉ trả selector, enabled/empty; không trả nội dung input hay hình học mặc định. Điền kiểm tra lại giá trị sau callback bằng boolean, không đưa giá trị vào kết quả/log. Form cấu hình cho chọn app và nhập deep link của chính app nếu cần; không buộc URL web.

Phần native mới đã kiểm tra policy bằng UIKit thật trên iPhone (button, cell, field, Accessibility, selector sau dịch vị trí, che email/OTP trong nhãn và danh sách app). 0.4.1 đã cài trên máy. KidsRepublic đã ghi và chạy lại toàn chuỗi bốn bước với hai hàng DATA giả: nút native `KidsRepublic.HighlightButton` mở trang `gate.aeon.com/ns/auth/login` trong app, hai ô ID/mật khẩu nhận DATA, nút native `_UIButtonBarButton` “閉じる” đóng form. Mỗi hàng kết thúc ở màn hình đầu; không lưu tọa độ hoặc giá trị đã gõ trong sự kiện, không bấm đăng nhập, form thử đã đóng. Lỗi `ELEMENT_OCCLUDED` khi bấm lại nút đầu là do form đăng nhập đã phủ lên màn hình đầu; bộ ghi nay nhận diện nút UIKit bên trong WebView và chờ phần tử hết bị che trước khi chạy. iAEON bị yêu cầu cập nhật nên đã chuyển mục tiêu sang KidsRepublic. Source/UI Cyusen giữ nguyên.

**GHI THAO TÁC MỚI** mở danh sách chọn ứng dụng ngay; mỗi kịch bản ghi riêng cho app được chọn. Nếu có các bước nhập nhưng DATA chưa đủ, **CHẠY KỊCH BẢN** mở form DATA trước khi tạo runner. Một hàng dùng các ô nhập theo tên biến/nhãn phần tử, mật khẩu được che và LƯU cố định phía trên; **NHIỀU HÀNG** giữ cách nhập JSON theo dòng. Các cột DATA khác được giữ khi sửa một hàng. Không xóa DATA khi Keychain báo lỗi đọc.

Manager khởi chạy runner với argv[0] theo đường dẫn bootstrap và môi trường riêng, kiểm tra lỗi tạo file actions, lưu errno nếu spawn thất bại. Đã xác minh `kpautorun --diagnose` được spawn từ tiến trình KP Auto thật; người dùng cũng đã ghi và chạy từ giao diện (lượt chạy thiếu DATA dừng `DATA_MISSING`, từ đó thêm form DATA trước khi chạy). Kiểm tra tự động: 140 bài Node và 45 bài Python đạt, 2 bài skip do môi trường; hai scheme native biên dịch được. Bố cục mới của picker/DATA đã biên dịch và cài, chưa có bài tự động thao tác trực tiếp lên hai form này.

Mã nguồn 0.4.0 bổ sung trình tạo kịch bản trực tiếp trên iPhone. Gói cập nhật riêng cho iPhone 8 RootHide đang kết nối nằm trong `packages`; repo Sileo công khai vẫn giữ 0.3.1. Bản 0.4.0 build Windows chỉ có arm64; chưa xác nhận A12+ hoặc bản Dopamine thường trên thiết bị.

1. Mở **GHI THAO TÁC**, chọn **CẤU HÌNH** để nhập tên, Bundle ID app và URL bắt đầu nếu dùng web (Safari: `com.apple.mobilesafari`).
2. Chọn **GHI THAO TÁC MỚI**, thao tác bình thường trong app. **MENU • GHI** trên cùng có tạm dừng/tiếp tục và **LƯU & KẾT THÚC**. Nhấn bên ngoài để đóng menu. Rời app cũng kết thúc bản ghi và giữ bản nháp.
3. Ô nhập được gắn biến `data_1`, `data_2`…; không lấy nội dung đã gõ. Web hỗ trợ nút/link, ô text/password/email/tel, textarea/contenteditable, checkbox/radio và select đơn. Native có UIButton, UITextField/UITextView và UISwitch với Accessibility ID, placeholder hoặc nhãn nhận diện được. Custom gesture/canvas, hàng table/collection, iframe và shadow DOM chưa có bộ ghi đầy đủ; không chuyển sang tọa độ.
4. Nhấn từng bước để sửa nhãn/selector, tên biến và timeout; bật/tắt, nhân bản, xóa, đưa lên/xuống hoặc thêm bước chờ/kiểm tra. **SẮP XẾP** cho kéo đổi thứ tự. Chạy lại chỉ gửi thao tác một lần, dừng khi định danh khớp nhiều phần tử, phần tử thay đổi hoặc kết quả bridge chưa rõ.
5. Mở **DATA**, nhập mỗi dòng một JSON, ví dụ `{"data_1":"email của bạn","data_2":"giá trị cần nhập"}`. Có thể đổi tên cột trong bước trước khi nhập DATA. DATA ở Keychain; tất cả hàng được kiểm tra đủ cột trước khi mở app/chạy. Mỗi hàng chạy lại cùng chuỗi bước; URL bắt đầu và các bước phải đưa app về trạng thái đầu phù hợp.
6. **KIỂM TRA BƯỚC ĐẦU** chỉ kiểm tra phần tử đầu tiên, không điền/nhấn. **CHẠY KỊCH BẢN** thực hiện các bước, hiển thị hàng/bước lỗi. **XUẤT JS** tạo kịch bản chứa selector và biến, không kèm DATA. File sao lưu trước khi ghi lại không chứa DATA; DATA của bản sao giữ riêng ở Keychain. Khi bắt đầu ghi mới thành công, mapping DATA cũ được xóa khỏi kịch bản đang ghi để tránh điền nhầm sang form mới.

Bản nháp được lưu sau từng lô sự kiện trước khi xác nhận đã nhận. Phiên ghi tự hết hạn khi mất runner (15 giây) hoặc sau 30 phút; ngừng nhận sau khi kết thúc. CSS cấu trúc là phương án dự phòng khi trang không có ID/name/test ID duy nhất; cần xem lại khi trang đổi bố cục.

Đã cài 0.4.0 trên iPhone 8 RootHide đang kết nối USB; controller phản hồi 0.4.0 và mã thực thi giao diện sau bản vá RootHide khớp build cuối. Đã kiểm tra trực tiếp trên bản cài bằng trang loopback/dữ liệu giả: chạm tin cậy được ghi thành selector, ô DATA, không ghi tọa độ/giá trị đã nhập, MENU tạm dừng/tiếp tục/kết thúc, phiên ghi qua điều hướng, rồi điền DATA mới và xác nhận click sau khi dịch vị trí nút. Agent native trong Cài đặt đã start/read/stop được khi không có WebView. Chưa xác nhận ghi/chạy mọi UIButton hoặc UITextField native: form native thử riêng không nối được agent và ô tìm kiếm Cài đặt chưa xuất hiện trong bài thử. Không khẳng định tương thích mọi app/trang web hoặc đã thử trực tiếp màn hình sửa/DATA với bàn phím.

Kiểm tra offline: 133 bài Node và 45 bài Python đạt, 2 bài được skip vì điều kiện môi trường. Cả hai scheme native đã biên dịch; gói `.deb` RootHide đã ký và kiểm tra cấu trúc/allowlist. Không build EXE hoặc ZIP, không đăng bản 0.4.0 lên repo công khai.

Thiết kế dùng [WKUserScript trong content world riêng](https://developer.apple.com/documentation/webkit/wkuserscript/init(source:injectiontime:formainframeonly:in:)) và sự kiện/control UIKit, không phụ thuộc kích thước màn hình. `runtime/recorder.js` là bộ ghi DOM, `runtime/workflow.js` là lưu/rà soát/chạy bước, `native/webview/KPRecorderAgent.m` là agent/MENU/native selector, `native/app/KPWorkflowController.m` là trình sửa kịch bản.

## Nền tảng và gói 0.3.1 đã có

Bản thử nghiệm chạy JavaScript trực tiếp trên iPhone jailbreak. Có hai gói riêng: **Dopamine thường/rootless** (`iphoneos-arm64`, cài vào `/var/jb`) và **Dopamine RootHide** (`iphoneos-arm64e`, dùng `jbroot`). Hai gói có cùng Package ID `com.khacphong.auto`; Sileo chọn theo kiến trúc jailbreak.

Hai gói 0.3.1 dùng binary build thực tế bằng Xcode 16.4 trên macOS: app/runner **arm64**, hai dylib **universal arm64 + arm64e ABI hiện đại** cho iOS 16. Bản RootHide 0.2.0 đã được kiểm tra trực tiếp trên iPhone 8; bản Dopamine thường, A12+ và bản 0.3.1 chưa được cài/kiểm tra trên thiết bị. Build/cấu trúc gói không chứng minh toàn bộ chức năng trên máy.

Bản rootless giữ script và trạng thái trong `/var/mobile/Library/KPAuto`; descriptor kết nối DOM riêng nằm ở `/var/jb/Library/KPAuto/IPC/worker-mach.json` để phù hợp quyền đọc bootstrap của Safari. Installer tạo thư mục IPC riêng, native kiểm tra đường dẫn/chủ sở hữu/quyền/loại file trước khi đọc hoặc ghi. RootHide giữ đường dẫn descriptor hiện tại. Kết nối controller và quyền SpringBoard trên Dopamine thường vẫn cần kiểm tra thiết bị thật.

Nguồn công khai: **https://nhokcrazy.github.io/khac-phong-repo/**. Thư mục `repo/` chứa hai file cài 0.3.1, `Packages`/bản nén, `Release` và trang tải. Ví dụ build lại: `python tools/build-repo.py --deb packages/com.khacphong.auto_0.3.1_iphoneos-arm64.deb --deb packages/com.khacphong.auto_0.3.1_iphoneos-arm64e.deb --expected-version 0.3.1 --base-url https://nhokcrazy.github.io/khac-phong-repo/`. Các dự án khác được thêm bằng đường dẫn `.deb` tường minh; không quét cả workspace.

Đường build A12+ nằm ở `tools/build-native-macos.sh` và `.github/workflows/build-native.yml`: Xcode/macOS tạo hai dylib universal arm64 + arm64e ABI hiện đại, sau đó ký và đóng gói riêng. Cả hai job rootless/RootHide của GitHub Actions run `37602487300` đã thành công; artifact ZIP khớp SHA256 GitHub và kiểm tra từng slice thực tế. Chưa kiểm tra A12+ trên thiết bị thật.

Sau khi tải artifact build Mac vào `.local/build-macos/<scheme>`, dùng `node tools/sign-native.js --scheme <scheme> --build-dir .local/build-macos/<scheme> --require-universal-system` rồi `python tools/package-deb.py --scheme <scheme> --build-dir .local/build-macos/<scheme> --version <phiên-bản-mới> --require-universal-system`. Flag này kiểm tra cả hai dylib universal và ABI arm64e đúng, bắt buộc cho bản phát hành 0.3.1.

Đã cài và cấu hình package trên đúng iPhone qua USB. Đã kiểm tra **JavaScriptCore, Mach IPC có xác thực PID, dừng vòng lặp vô hạn, trạng thái/mở/đóng app, DOM Safari, nhập tiếng Việt và click DOM**. Chạm/vuốt được trang thử xác nhận qua sự kiện `isTrusted`; không chỉ dựa vào kết quả gửi HID. 14 kiểm tra JS/DOM trên PC và kiểm tra bố cục package đều đạt.

**Đã kiểm tra nút CHẠY trên điện thoại:** người dùng chạy `02-kiem-tra-iphone.js` trong KP Auto; Cài đặt tự mở rồi đóng khi manager chuyển nền, runner ghi nhận `origin: manager` và `status: success`. Kết quả trên trang thử không chứng minh mọi app hoặc trang web đều tương thích; kiểm tra selector và kết quả trên app cần dùng trước khi chạy kịch bản thật.

## Sử dụng

**Cyusen trên Safari:** mở `CyusenBrowser.js` để vào dashboard DATA/SETTING/SUCCESS/FAILED. Hướng dẫn và phạm vi kiểm tra nằm tại [conversions/CyusenBrowser/README.md](conversions/CyusenBrowser/README.md). Bản 0.2.0 bổ sung Keychain, HTTPS, Gmail IMAP, progress, DỪNG sau tài khoản, Shortcuts callback và xóa dữ liệu riêng Pokémon Center trong Safari. Các kiểm tra nền tảng dưới đây có từ bản 0.1.0; đọc hướng dẫn Cyusen để xem đúng phần đã kiểm tra của bản chuyển đổi.

1. Cài đúng gói `.deb` qua Sileo. Cần ElleKit; bản RootHide cần thêm RootHide. Helper USB trên PC hiện chọn riêng iPhone 8 RootHide đã cấu hình. Respring để nạp controller vào SpringBoard.
2. Mở **KP Auto**, dùng **NHẬP JS** hoặc dấu **+** để thêm script.
3. Mở script, sửa và nhấn **LƯU** hoặc **CHẠY** ở thanh trên. Script khai báo `main(auto)`.
4. **DỪNG** ngăn lệnh tiếp theo; lệnh native đang xử lý có thể hoàn tất. Runner tự thoát khi JS treo sau yêu cầu dừng. Có **DỪNG CƯỠNG BỨC** khi còn chờ native.
5. **KIỂM TRA KẾT NỐI** kiểm tra controller. Touch cần chạm tay thật một lần sau respring để nhận ID phần cứng.

Tool dùng runner riêng, không cần JSBox hoặc PC khi chạy kịch bản. RootHide phải cho phép inject tweak vào app cần auto; tool không tự thay lựa chọn này.

DOM áp dụng cho **WKWebView đang hiển thị, main frame**. App native không có HTML DOM. 0.4.0 thêm bộ ghi theo phần tử như trên; iframe, shadow DOM đóng, OCR và dò ảnh chưa được hỗ trợ đầy đủ.

## API

```js
async function main(auto) {
  await auto.app.launch("com.apple.mobilesafari");
  await auto.sleep(1000);
  await auto.app.openURL("com.apple.mobilesafari", "https://example.com/");
  await auto.sleep(1500);
  const views = await auto.web.list("com.apple.mobilesafari");
  const visible = views.filter(view => view.visible);
  if (visible.length !== 1) throw Object.assign(new Error(), {code:"CHOOSE_WEBVIEW"});
  const page = await auto.web.attach({bundleId:"com.apple.mobilesafari", webViewId:visible[0].webViewId});
  await page.waitFor("h1", {timeoutMs:10000});
  const heading = await page.text("h1");
  // Dùng heading trong logic. Không ghi dữ liệu trang vào log mặc định.
}
```

| API | Ý nghĩa |
|---|---|
| `auto.app.launch/close/state(bundleId)` | Mở/chờ foreground, đóng PID đã xác minh, đọc trạng thái |
| `auto.app.openURL(bundleId,url)` | Mở URL vào đúng app chỉ định, chờ app lên foreground |
| `auto.touch.tap(x,y)` | Tọa độ point theo orientation hiện tại |
| `auto.touch.swipe(x1,y1,x2,y2,durationMs)` | Mặc định 400 ms, tối đa 5000 ms |
| `auto.web.list(bundleId)` | Process/WebView và cờ `visible` |
| `auto.web.attach({bundleId,webViewId})` | Chọn đúng WebView và document |
| `page.query/exists/text(selector)` | Metadata tối đa 100 phần tử, boolean, nội dung text |
| `page.fill(selector,value)` / `page.click(selector)` | Nhập/click phần tử khớp duy nhất |
| `page.evaluate(source,args)` | Thân hàm JS, tham số qua `args`, kết quả JSON |
| `page.loginSecurity()` | Đọc cờ sẵn sàng của thư viện trên trang đăng nhập Pokémon Center/Safari; chỉ trả boolean |
| `page.waitFor(selector,{timeoutMs,intervalMs})` | Chờ khi phần tử chưa có, lỗi bridge không retry |
| `auto.sleep(ms)` / `auto.stop()` | Chờ / dừng hợp tác |
| `auto.store.get/set(key,value)` | JSON Keychain theo namespace của script |
| `auto.network.request(options)` | HTTPS, response status/headers/body, hạn tối đa 30 giây |
| `auto.network.airplaneState()` / `auto.network.resetAirplane(holdMs)` | Đọc trạng thái / bật máy bay, giữ 1–4 giây, tắt và xác nhận |
| `auto.imap.baseline/messages/trash(options)` | Gmail TLS, UIDVALIDITY/UIDNEXT, đúng một UID khi chuyển Trash |
| `auto.progress.update(value)` / `auto.run.control()` | Trạng thái an toàn và yêu cầu DỪNG sau tài khoản |
| `auto.shortcuts.run(name,timeoutMs)` | Chạy phím tắt, chờ callback gắn với lượt chạy |
| `page.clearData('pokemoncenter-online.com')` | Xóa và kiểm tra dữ liệu/cookie của domain trong phiên Safari đã chọn |

Ví dụ evaluate: `await page.evaluate("return document.title;", {})`.

Click/fill chỉ báo đã gửi sự kiện, không xác nhận kết quả nghiệp vụ. Sự kiện DOM khác chạm thật (`isTrusted`), cần kiểm tra với trang/framework thực tế. Sau điều hướng phải attach lại; document đổi trả `STALE_DOCUMENT`. Không tự chuyển WebView hoặc tự chạy lại thao tác khi timeout.

## Native và dữ liệu

- `native/app`: quản lý, nhập/sửa, chạy/dừng script; dữ liệu ở `jbroot("/var/mobile/Library/KPAuto")`.
- `native/worker`: process/JSContext mới cho mỗi lần chạy, `flock` ngăn chạy trùng, script tối đa 1 MB, xử lý dừng cả vòng lặp treo.
- `native/controller`: SpringBoard chỉ nhận thao tác từ executable runner đã xác minh; manager chỉ đọc trạng thái. Không tự mở khóa màn hình.
- `native/webview`: content world riêng; kiểm tra bundle/PID/WebView/document, visibility và deadline trước khi thực thi. JS trang không truy cập native bridge.
- `native/common`: Mach JSON tối đa 64 KB; audit PID do kernel cấp cho request và reply; ID/run ID chống nhận kết quả cũ.

Không lưu kết quả `main`, payload DOM, giá trị nhập, cookie hoặc thông báo lỗi JS tùy ý vào log mặc định. Native timeout không chứng minh thao tác chưa xảy ra.

Runner đăng ký Mach service mới cho từng lượt chạy, gồm PID và nonce. Capability cho riêng service đó được ghi trong thư mục riêng của tool với quyền `0600`; bridge tiêu thụ sandbox extension để gọi service và kiểm tra PID của phản hồi bằng audit trailer từ kernel. Worker xác minh bundle của app gọi tới. Capability được xóa khi lượt chạy kết thúc bình thường hoặc watchdog dừng runner. Không ghi token capability vào log. Đã kiểm tra trao đổi hai chiều với Safari sandbox trên máy; không cần cài RocketBootstrap. Thư viện RocketBootstrap tương thích nếu có vẫn được hỗ trợ.

## Build Windows

Toolchain trong `.local`, không thay cài đặt Windows hoặc dùng WSL: LLVM 20.1.8 chính thức; SDK iPhoneOS16.5 từ `theos/sdks` commit `0222fd5413cf4b9af096f37b4621afa2688572f7`; libroothide đọc từ máy để link (không nhúng vào package). Ký bằng ldid sẵn có trên iPhone.

```powershell
npm test
node tools/build-cyusen.js
node tools/build-native.js --all
node tools/device-smoke.js
node tools/sign-native.js
python tools/package-deb.py
```

Chỉ tiếp tục khi lệnh trước thành công. Package ở `packages`. Không tạo EXE hoặc ZIP phân phối.

USB proxy chọn đúng model/iOS/serial suffix mỗi kết nối, từ chối nếu không khớp duy nhất. SSH cổng 2222, host key đã kiểm tra, key riêng dự án. Không tác động các iPhone khác.

`device-smoke.js` chỉ chạy binary trong thư mục riêng `kpauto-build-test` bên RootHide, không cài tweak/mở app/respring. Kiểm tra vòng lặp có watchdog, chỉ kết thúc process kiểm tra của helper.

`tools/install-iphone.ps1` chuyển đúng package, kiểm tra SHA256, cài và respring. SSH dùng key của **mobile**, rồi hỏi mật khẩu **mobile/sudo** ở terminal với ký tự ẩn. Mật khẩu đi qua pipe/stdin để xác thực sudo; không ghi vào file, argv hoặc biến môi trường. Không cần đăng nhập SSH root. Chỉ chạy khi sẵn sàng cài bản thử nghiệm và respring.

Package có các record thư mục cha trước file để dpkg giải nén vào máy chưa có thư mục app. Kiểm tra hồi quy: `python -m unittest discover -s tests -p test_deb_layout.py`.

Sau cài, `node tools/ssh-iphone.js '"$(jbroot /usr/libexec/kpautorun)" --diagnose'` đọc trạng thái controller. Kiểm tra tiếp với app/trang thử không có giao dịch. Gỡ qua Sileo package `com.khacphong.auto` rồi respring; giữ thư mục script người dùng.

`node tools/build-native.js --fixture` và `node tools/device-web-probe.js` chạy bài thử với server loopback tạm thời, URL riêng cho mỗi lượt. Bài thử xác minh đúng trang trước khi chạm/vuốt, đọc kết quả DOM, rồi đóng Safari và dọn script/server của lượt kiểm tra. `--reload-bridge` đóng Safari trước khi thử nếu vừa thay bridge. Các helper này cần PC để kiểm tra; kịch bản bình thường trong KP Auto chạy trực tiếp trên điện thoại.

`node tools/prepare-manager-check.js` đặt script cố định `02-kiem-tra-iphone.js` lên máy, giữ nguyên nếu người dùng đã sửa nội dung. Script mở Cài đặt, xác minh foreground, chờ 4 giây rồi đóng; không thay đổi cài đặt. Mở script trong KP Auto và nhấn CHẠY để kiểm tra runner khi manager chuyển nền. Trạng thái lượt chạy lưu `origin: manager` khi tiến trình được tạo trực tiếp bởi KP Auto, giúp phân biệt bài thử qua SSH.

## Tài liệu đối chiếu

[RootHide Developer](https://github.com/roothide/Developer), [RootHide Theos](https://github.com/roothide/theos), [LLVM 20.1.8](https://github.com/llvm/llvm-project/releases/tag/llvmorg-20.1.8), [Theos SDKs](https://github.com/theos/sdks), [Theos SpringBoardServices](https://github.com/theos/headers/tree/master/SpringBoardServices), [LLVM debugserver](https://github.com/llvm/llvm-project/tree/main/lldb/tools/debugserver/source), [Apple WebKit HID](https://github.com/WebKit/WebKit/blob/main/Tools/WebKitTestRunner/ios/HIDEventGenerator.mm), [RocketBootstrap](https://github.com/rpetrich/rocketbootstrap).

Mã triển khai của tool được viết trong dự án này; không nhúng mã GPL của AutoTouch hoặc ZXTouch.
