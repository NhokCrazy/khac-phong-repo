// Nhấn CHẠY trong KP Auto. Kịch bản mở Cài đặt rồi đóng sau 4 giây.
async function main(auto) {
  let stage = "APP_LAUNCH";
  const bundle = "com.apple.Preferences";
  try {
    await auto.app.launch(bundle);
    await auto.sleep(1000);
    const opened = await auto.app.state(bundle);
    if (!opened.running || !opened.foreground) {
      throw Object.assign(new Error(), { code: "APP_NOT_FOREGROUND" });
    }
    await auto.sleep(4000);
    stage = "APP_CLOSE";
    await auto.app.close(bundle);
    const closed = await auto.app.state(bundle);
    if (closed.running) throw Object.assign(new Error(), { code: "APP_STILL_RUNNING" });
  } catch (error) {
    error.code = stage + "_" + (error.code || "SCRIPT_ERROR");
    throw error;
  }
}
