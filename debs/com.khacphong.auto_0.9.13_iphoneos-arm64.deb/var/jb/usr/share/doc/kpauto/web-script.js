/* KP Auto calls main(auto) in its on-device JavaScriptCore runner. */
async function main(auto) {
  const bundleId = "com.apple.mobilesafari";
  await auto.app.launch(bundleId);
  await auto.sleep(1000);
  await auto.app.openURL(bundleId, "https://example.com/");
  await auto.sleep(1500);
  const views = (await auto.web.list(bundleId)).filter(view => view.visible);
  if (!Array.isArray(views) || views.length !== 1) {
    throw new Error("Choose a webViewId explicitly when multiple WebViews exist");
  }
  const web = await auto.web.attach({ bundleId: bundleId, webViewId: views[0].webViewId });
  await web.waitFor("h1", { timeoutMs: 10000 });
  const title = await web.text("h1");
  // Example only: use selectors belonging to the actual target website.
  // await web.fill('input[name="search"]', "One Piece");
  // await web.click('button[type="submit"]');
  // Reattach after navigation; an old document handle must fail closed.
  return title;
}

if (typeof module !== "undefined" && module.exports) module.exports = { main: main };
