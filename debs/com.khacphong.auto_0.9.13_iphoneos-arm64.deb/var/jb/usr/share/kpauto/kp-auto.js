/* JavaScriptCore-compatible API. Requires a native host; no device emulation. */
(function (root) {
  "use strict";

  function fault(code, message) {
    const error = new Error(message || code);
    error.code = code;
    return error;
  }

  function string(value, name) {
    if (typeof value !== "string" || !value.trim()) {
      throw fault("INVALID_ARGUMENT", name + " must be a non-empty string");
    }
    return value;
  }

  function number(value, name, min) {
    if (typeof value !== "number" || !Number.isFinite(value) || value < min) {
      throw fault("INVALID_ARGUMENT", name + " is invalid");
    }
    return value;
  }

  function createAutomation(host) {
    if (!host || typeof host.invoke !== "function" || typeof host.sleep !== "function") {
      throw fault("HOST_REQUIRED", "A native invoke/sleep bridge is required");
    }
    const now = typeof host.now === "function" ? () => host.now() : () => Date.now();
    let stopped = false;
    let queue = Promise.resolve();

    function check() {
      if (stopped) throw fault("STOPPED", "Script stopped");
    }

    function invoke(method, payload) {
      const operation = queue.then(async function () {
        check();
        // The host must enforce a bounded timeout. Never replay a timed-out mutation.
        let reply;
        try { reply = await host.invoke(method, payload); }
        catch (_) {
          stopped = true;
          throw fault("OUTCOME_UNKNOWN", "Native transport failed; inspect device state before restarting");
        }
        if (!reply || typeof reply.ok !== "boolean") {
          stopped = true;
          throw fault("INVALID_REPLY", "Invalid native reply");
        }
        if (!reply.ok) {
          const code = reply.error && reply.error.code || "NATIVE_ERROR";
          if (["NATIVE_TIMEOUT", "OUTCOME_UNKNOWN", "INVALID_REPLY"].indexOf(code) >= 0) stopped = true;
          throw fault(code,
            reply.error && reply.error.message || "Native operation failed");
        }
        check();
        return reply.result;
      });
      queue = operation.catch(function () {});
      return operation;
    }

    async function sleep(ms) {
      number(ms, "ms", 0);
      check();
      // Short slices let cooperative stop interrupt long waits.
      let remaining = ms;
      while (remaining > 0) {
        const slice = Math.min(remaining, 100);
        await host.sleep(slice);
        check();
        remaining -= slice;
      }
    }

    async function attach(options) {
      options = options || {};
      const bundleId = string(options.bundleId, "bundleId");
      const requestedId = options.webViewId === undefined ? null : string(options.webViewId, "webViewId");
      const target = await invoke("web.attach", { bundleId: bundleId, webViewId: requestedId });
      if (!target || target.bundleId !== bundleId ||
          !Number.isInteger(target.processId) || target.processId <= 0 ||
          typeof target.webViewId !== "string" || !target.webViewId ||
          typeof target.documentId !== "string" || !target.documentId ||
          (requestedId !== null && requestedId !== target.webViewId)) {
        throw fault("INVALID_TARGET", "Native host did not return the requested WebView");
      }
      const selected = Object.freeze({ bundleId: bundleId, processId: target.processId,
        webViewId: target.webViewId, documentId: target.documentId });

      function dom(action, selector, value) {
        string(selector, "selector");
        const command = { action: action, selector: selector };
        if (value !== undefined) command.value = value;
        return invoke("web.dom", { target: selected, command: command }).then(function (result) {
          if (action === "exists" && typeof result !== "boolean") {
            stopped = true;
            throw fault("INVALID_REPLY", "exists must return a boolean");
          }
          return result;
        });
      }

      return Object.freeze({
        target: selected,
        query: selector => dom("query", selector),
        exists: selector => dom("exists", selector),
        text: selector => dom("text", selector),
        click: selector => dom("click", selector),
        fill: function (selector, value) {
          if (typeof value !== "string") throw fault("INVALID_ARGUMENT", "value must be a string");
          return dom("fill", selector, value);
        },
        evaluate: function (source, args) {
          string(source, "source");
          return invoke("web.evaluate", { target: selected, source: source, args: args || {} });
        },
        loginSecurity: function () {
          if (selected.bundleId !== "com.apple.mobilesafari") throw fault("INVALID_TARGET", "Login readiness requires Safari");
          return invoke("web.loginSecurity", { target: selected }).then(function (result) {
            const keys = ["hasRecaptcha", "documentReady", "apiReady", "frameReady", "ready"];
            if (result && Object.prototype.hasOwnProperty.call(result, "sdkReady")) keys.push("sdkReady");
            if (!result || keys.some(key => typeof result[key] !== "boolean")) {
              stopped = true;
              throw fault("INVALID_REPLY", "Login readiness must contain Boolean fields");
            }
            const safe = {};
            keys.forEach(key => { safe[key] = result[key]; });
            return Object.freeze(safe);
          });
        },
        clearData: domain => invoke("web.clearData", { target: selected, domain: string(domain, "domain") }),
        waitFor: async function (selector, options) {
          string(selector, "selector");
          options = options || {};
          const timeoutMs = options.timeoutMs === undefined ? 10000 : number(options.timeoutMs, "timeoutMs", 0);
          const intervalMs = options.intervalMs === undefined ? 250 : number(options.intervalMs, "intervalMs", 1);
          const deadline = now() + timeoutMs;
          while (true) {
            // Only a successful exists=false is retryable; bridge errors propagate.
            if (await dom("exists", selector)) return true;
            const remaining = deadline - now();
            if (remaining <= 0) throw fault("WAIT_TIMEOUT", "Element did not appear");
            await sleep(Math.min(intervalMs, remaining));
          }
        }
      });
    }
    function nativeSelector(value) {
      if (!value || typeof value !== 'object' || Array.isArray(value)) throw fault('INVALID_ARGUMENT','Native selector is required');
      const allowed=['kind','class','role','identifier','label','placeholder','sensitive','path','screen','screenTitle'];
      if(Object.keys(value).some(key=>allowed.indexOf(key)<0))throw fault('INVALID_ARGUMENT','Native selectors cannot contain geometry');
      const selector=Object.assign({kind:'native'},value);
      if(selector.kind!=='native' || typeof selector.class!=='string' || !selector.class ||
         ![selector.identifier,selector.label,selector.placeholder,selector.path].some(x=>typeof x==='string' && x.length))throw fault('INVALID_ARGUMENT','Native identity is required');
      return selector;
    }

    const api = {
      stop: function () { stopped = true; },
      sleep: sleep,
      store: Object.freeze({
        get: key => invoke("store.get", {key: string(key, "key")}),
        set: (key, value) => invoke("store.set", {key: string(key, "key"), value: value === undefined ? null : value})
      }),
      network: Object.freeze({
        request: options => invoke("network.request", options || {}),
        airplaneState: () => invoke("network.airplaneState", {}),
        resetAirplane: holdMs => invoke("network.resetAirplane", {holdMs:number(holdMs === undefined ? 3000 : holdMs,"holdMs",1000)})
      }),
      imap: Object.freeze({
        baseline: options => invoke("imap.baseline", options || {}),
        messages: options => invoke("imap.messages", options || {}),
        trash: options => invoke("imap.trash", options || {})
      }),
      progress: Object.freeze({update: value => invoke("progress.update", value || {})}),
      run: Object.freeze({control: () => invoke("run.control", {})}),
      shortcuts: Object.freeze({run: (name, timeoutMs) => invoke("shortcuts.run", {
        name: string(name, "name"), timeoutMs: number(timeoutMs === undefined ? 120000 : timeoutMs, "timeoutMs", 1000)
      })}),
      app: Object.freeze({
        launch: bundleId => invoke("app.launch", { bundleId: string(bundleId, "bundleId") }),
        openURL: (bundleId, url) => invoke("app.openURL", { bundleId: string(bundleId, "bundleId"), url: string(url, "url") }),
        close: bundleId => invoke("app.close", { bundleId: string(bundleId, "bundleId") }),
        state: bundleId => invoke("app.state", { bundleId: string(bundleId, "bundleId") })
      }),
      touch: Object.freeze({
        tap: function (x, y) {
          return invoke("touch.tap", { x: number(x, "x", 0), y: number(y, "y", 0) });
        },
        swipe: function (x1, y1, x2, y2, durationMs) {
          return invoke("touch.swipe", { x1: number(x1, "x1", 0), y1: number(y1, "y1", 0),
            x2: number(x2, "x2", 0), y2: number(y2, "y2", 0),
            durationMs: number(durationMs === undefined ? 400 : durationMs, "durationMs", 1) });
        }
      }),
      web: Object.freeze({
        list: bundleId => invoke("web.list", { bundleId: string(bundleId, "bundleId") }),
        attach: attach
      }),
      crane: Object.freeze({
        state: bundleId=>invoke('crane.state',{bundleId:string(bundleId,'bundleId')}),
        temporaryCapabilities: bundleId=>{
          if(bundleId!=='com.google.chrome.ios')throw fault('INVALID_ARGUMENT','Invalid temporary container bundle');
          return invoke('crane.temporaryCapabilities',{bundleId});
        },
        createTemporary: (bundleId,stateToken,containerNumber,operationId)=>{
          if(bundleId!=='com.google.chrome.ios' || typeof stateToken!=='string' || !/^[a-f0-9]{64}$/.test(stateToken) ||
             !Number.isInteger(containerNumber) || containerNumber<0 || containerNumber>999999999 ||
             typeof operationId!=='string' || !/^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/i.test(operationId))
            throw fault('INVALID_ARGUMENT','Invalid temporary container creation');
          return invoke('crane.create',{bundleId,stateToken,containerNumber,temporaryOperationId:operationId});
        },
        deleteTemporary: (bundleId,expectedState,operationId)=>{
          if(bundleId!=='com.google.chrome.ios' || typeof operationId!=='string' ||
             !/^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/i.test(operationId) ||
             !expectedState || typeof expectedState!=='object' || Array.isArray(expectedState) ||
             Object.keys(expectedState).length!==4 || Object.keys(expectedState).some(key=>!['count','current','hasNext','stateToken'].includes(key)) ||
             !Number.isInteger(expectedState.count) || expectedState.count<2 || expectedState.count>2000 ||
             !Number.isInteger(expectedState.current) || expectedState.current<1 || expectedState.current>expectedState.count ||
             expectedState.hasNext!==(expectedState.current<expectedState.count) ||
             typeof expectedState.stateToken!=='string' || !/^[a-f0-9]{64}$/.test(expectedState.stateToken))
            throw fault('INVALID_ARGUMENT','Invalid temporary container deletion proof');
          return invoke('crane.deleteCurrent',{bundleId,expectedState:{count:expectedState.count,current:expectedState.current,
            hasNext:expectedState.hasNext,stateToken:expectedState.stateToken},operationId,creationOperationId:operationId});
        },
        temporaryReceipt: (bundleId,operationId)=>{
          if(bundleId!=='com.google.chrome.ios' || typeof operationId!=='string' ||
             !/^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/i.test(operationId))
            throw fault('INVALID_ARGUMENT','Invalid temporary container receipt');
          return invoke('crane.deletionReceipt',{bundleId,operationId,temporary:true});
        },
        deleteCurrent: (bundleId,expectedState,operationId)=>{
          if(bundleId!=='jp.naver.line' || typeof operationId!=='string' ||
             !/^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/i.test(operationId) ||
             !expectedState || typeof expectedState!=='object' || Array.isArray(expectedState) ||
             Object.keys(expectedState).length!==4 || Object.keys(expectedState).some(key=>
               !['count','current','hasNext','stateToken'].includes(key)) ||
             !Number.isInteger(expectedState.count) || expectedState.count<2 || expectedState.count>2000 ||
             !Number.isInteger(expectedState.current) || expectedState.current<1 || expectedState.current>expectedState.count ||
             typeof expectedState.hasNext!=='boolean' || expectedState.hasNext!==(expectedState.current<expectedState.count) ||
             typeof expectedState.stateToken!=='string' || !/^[a-f0-9]{64}$/.test(expectedState.stateToken))
            throw fault('INVALID_ARGUMENT','Invalid LINE deletion proof');
          return invoke('crane.deleteCurrent',{bundleId,expectedState:{count:expectedState.count,current:expectedState.current,
            hasNext:expectedState.hasNext,stateToken:expectedState.stateToken},operationId});
        },
        deletionReceipt: (bundleId,operationId)=>{
          if(bundleId!=='jp.naver.line' || typeof operationId!=='string' ||
             !/^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/i.test(operationId))
            throw fault('INVALID_ARGUMENT','Invalid LINE deletion receipt');
          return invoke('crane.deletionReceipt',{bundleId,operationId});
        },
        renamePlan: (bundleId,expectedState,operationId)=>{
          if(bundleId!=='jp.naver.line' || typeof operationId!=='string' ||
             !/^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/i.test(operationId) ||
             !expectedState || typeof expectedState!=='object' || Array.isArray(expectedState) ||
             Object.keys(expectedState).length!==4 || Object.keys(expectedState).some(key=>
               !['count','current','hasNext','stateToken'].includes(key)) ||
             !Number.isInteger(expectedState.count) || expectedState.count<1 || expectedState.count>2000 ||
             !Number.isInteger(expectedState.current) || expectedState.current<1 || expectedState.current>expectedState.count ||
             typeof expectedState.hasNext!=='boolean' || expectedState.hasNext!==(expectedState.current<expectedState.count) ||
             typeof expectedState.stateToken!=='string' || !/^[a-f0-9]{64}$/.test(expectedState.stateToken))
            throw fault('INVALID_ARGUMENT','Invalid LINE rename proof');
          return invoke('crane.renamePlan',{bundleId,expectedState:{count:expectedState.count,current:expectedState.current,
            hasNext:expectedState.hasNext,stateToken:expectedState.stateToken},operationId});
        },
        renameNext: (bundleId,planToken,operationId)=>{
          if(bundleId!=='jp.naver.line' || typeof planToken!=='string' || !/^[a-f0-9]{64}$/.test(planToken) ||
             typeof operationId!=='string' || !/^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/i.test(operationId))
            throw fault('INVALID_ARGUMENT','Invalid LINE rename plan');
          return invoke('crane.renameNext',{bundleId,planToken,operationId});
        },
        next: (bundleId,stateToken)=>{
          if(typeof stateToken!=='string' || !/^[a-f0-9]{64}$/.test(stateToken))throw fault('INVALID_ARGUMENT','Invalid Crane state');
          return invoke('crane.next',{bundleId:string(bundleId,'bundleId'),stateToken});
        },
        select: (bundleId,stateToken,containerIndex,targetProof)=>{
          if(typeof stateToken!=='string' || !/^[a-f0-9]{64}$/.test(stateToken) ||
             !Number.isInteger(containerIndex) || containerIndex<1 || containerIndex>2000)
            throw fault('INVALID_ARGUMENT','Invalid Crane selection');
          const payload={bundleId:string(bundleId,'bundleId'),stateToken,containerIndex};
          if(targetProof!==undefined) {
            if(!targetProof || typeof targetProof!=='object' || Array.isArray(targetProof) ||
               Object.keys(targetProof).length!==4 || Object.keys(targetProof).some(key=>
                 !['count','current','hasNext','stateToken'].includes(key)) ||
               !Number.isInteger(targetProof.count) || targetProof.count<1 || targetProof.count>2000 ||
               targetProof.current!==containerIndex || targetProof.current>targetProof.count ||
               typeof targetProof.hasNext!=='boolean' || targetProof.hasNext!==(targetProof.current<targetProof.count) ||
               typeof targetProof.stateToken!=='string' || !/^[a-f0-9]{64}$/.test(targetProof.stateToken))
              throw fault('INVALID_ARGUMENT','Invalid Crane target proof');
            payload.targetProof={count:targetProof.count,current:targetProof.current,
              hasNext:targetProof.hasNext,stateToken:targetProof.stateToken};
          }
          return invoke('crane.select',payload);
        },
        create: (bundleId,stateToken,containerNumber)=>{
          if(typeof stateToken!=='string' || !/^[a-f0-9]{64}$/.test(stateToken))throw fault('INVALID_ARGUMENT','Invalid Crane state');
          if(!Number.isInteger(containerNumber) || containerNumber<0 || containerNumber>999999999)throw fault('INVALID_ARGUMENT','Invalid Crane container number');
          return invoke('crane.create',{bundleId:string(bundleId,'bundleId'),stateToken,containerNumber});
        }
      }),
      ui: Object.freeze({
        elements: bundleId => invoke('ui.elements',{bundleId:string(bundleId,'bundleId')}),
        inspect: (bundleId,selector) => invoke('ui.inspect',{bundleId:string(bundleId,'bundleId'),selector:nativeSelector(selector)}),
        click: (bundleId,selector) => invoke('ui.perform',{bundleId:string(bundleId,'bundleId'),selector:nativeSelector(selector),action:'click'}),
        fill: (bundleId,selector,value,options) => {
          if(typeof value!=='string')throw fault('INVALID_ARGUMENT','value must be a string');
          return invoke('ui.perform',{bundleId:string(bundleId,'bundleId'),selector:nativeSelector(selector),action:'fill',value:value,requireEmpty:!!(options && options.requireEmpty)});
        },
        waitFor: async (bundleId,selector,options) => {
          options=options || {};
          const deadline=now()+(options.timeoutMs===undefined ? 15000 : number(options.timeoutMs,'timeoutMs',0));
          while(true) {
            const reply=await invoke('ui.inspect',{bundleId:string(bundleId,'bundleId'),selector:nativeSelector(selector)});
            if(!reply || !Number.isInteger(reply.count) || reply.count<0 || typeof reply.enabled!=='boolean' || (reply.interactable!==undefined && typeof reply.interactable!=='boolean'))throw fault('INVALID_REPLY','Invalid native inspection');
            if(reply.count>1)throw fault('AMBIGUOUS_ELEMENT','Native selector must match exactly one element');
            if(reply.count===1 && reply.enabled && reply.interactable!==false)return true;
            if(now()>=deadline)throw fault('WAIT_TIMEOUT','Native element did not appear');
            await sleep(Math.min(250,deadline-now()));
          }
        }
      })
    };
    if (root.KPWorkflow) api.recorder = root.KPWorkflow.create(api, invoke, async function(status) {
      // Terminal transport errors block further device actions, but local status can still be saved.
      // This private callback exposes neither arbitrary methods nor DATA to the workflow module.
      try { await host.invoke('store.set', {key:'workflowStatus',value:status}); } catch (_) {}
    }, async function(log) {
      try { await host.invoke('store.set',{key:'workflowLog',value:log}); }catch(_){}
    }, async function(payload) {
      // Final UI feedback is independent of the stopped action queue. This
      // fixed endpoint only shows status; it never retries a device action.
      try { await host.invoke('ui.overlay.end',payload); }catch(_){}
    }, async function(status) {
      // Recording failures remain visible after an uncertain startup has
      // stopped the action queue. The namespace and storage key stay fixed.
      try { await host.invoke('store.set',{key:'recordStatus',value:status}); }catch(_){}
    });
    return Object.freeze(api);
  }

  if (typeof module !== "undefined" && module.exports) module.exports = { createAutomation: createAutomation };
  else root.KPAuto = Object.freeze({ createAutomation: createAutomation });
})(typeof globalThis !== "undefined" ? globalThis : this);
