/* Evaluated inside the selected WKWebView, never in the script runner. */
(function (root) {
  "use strict";
  const pendingChecks=new Map();let checkSerial=0;
  function targetIdentity(command) {
    const target=command.target;
    return target ? JSON.stringify([target.selector,target.tag,target.type,target.strategy,target.label,
      target.shadowPath && target.shadowPath.map(h=>[h.selector,h.tag,h.strategy,h.label])]) : JSON.stringify([command.selector]);
  }

  function composedParent(node) {
    if(node.assignedSlot)return node.assignedSlot;
    if(node.parentElement)return node.parentElement;
    const tree=typeof node.getRootNode==='function' ? node.getRootNode() : null;
    return tree && tree.host || null;
  }
  function composedNodes(node) {
    const result=[],seen=new Set();
    for(let item=node;item && !seen.has(item);item=composedParent(item)){seen.add(item);result.push(item);}
    return result;
  }
  function disabled(node) {
    return composedNodes(node).some(item=>item.disabled || item.inert || (typeof item.hasAttribute==='function' && (item.hasAttribute('inert') || item.hasAttribute('disabled'))) ||
      (typeof item.getAttribute==='function' && item.getAttribute('aria-disabled')==='true') ||
      (typeof item.closest==='function' && item.closest('[inert], [aria-disabled="true"]')));
  }
  function selectedNodes(command,doc) {
    if(command.target!==undefined) {
      if(!command.target || typeof command.target!=='object' || command.target.kind!=='web' ||
         (command.selector!==undefined && command.selector!==command.target.selector))throw failure('INVALID_TARGET','Invalid recorded target');
      const recorder=typeof module!=='undefined' && module.exports ? require('./recorder') : root.KPRecorder;
      if(!recorder || typeof recorder.resolve!=='function')throw failure('INVALID_TARGET','Recorder target resolution is unavailable');
      try{return [recorder.resolve(command.target,doc)];}
      catch(error){if(['exists','query'].includes(command.action) && error.code==='ELEMENT_NOT_FOUND')return [];throw error;}
    }
    if(typeof command.selector!=='string' || !command.selector.trim())throw failure('INVALID_ARGUMENT','selector must be a non-empty string');
    try{return Array.from(doc.querySelectorAll(command.selector));}catch(_){throw failure('INVALID_SELECTOR','Invalid CSS selector');}
  }
  function unobscured(node,doc,win,requireOnscreen) {
    if(typeof doc.elementFromPoint!=='function')return true;
    const rect=node.getBoundingClientRect(),x=rect.x+rect.width/2,y=rect.y+rect.height/2;
    // An offscreen target may still be scrolled after its entire command is
    // validated. Check occlusion only at a point currently inside the viewport.
    if(!Number.isFinite(x) || !Number.isFinite(y) || x<0 || y<0 || (Number.isFinite(win.innerWidth)&&x>=win.innerWidth) || (Number.isFinite(win.innerHeight)&&y>=win.innerHeight))return !requireOnscreen;
    let hit=doc.elementFromPoint(x,y);const seen=new Set();
    while(hit && hit.shadowRoot && typeof hit.shadowRoot.elementFromPoint==='function' && !seen.has(hit)) {
      seen.add(hit);const next=hit.shadowRoot.elementFromPoint(x,y);if(!next || next===hit)break;hit=next;
    }
    return !!hit && composedNodes(hit).includes(node);
  }
  function confirmAfterViewChange(command,node,doc,win) {
    if(!command.target)return;
    const current=selectedNodes(command,doc);
    if(current.length!==1 || current[0]!==node)throw failure('ELEMENT_CHANGED','Recorded element changed');
    const hit=surface(node,command.action,win);
    if(command.action==='fill' && node.readOnly)throw failure('ELEMENT_READONLY','Element is read-only');
    if(!unobscured(hit,doc,win,true))throw failure('ELEMENT_OCCLUDED','Element is covered');
  }
  function toggleState(node,win) {
    if(node instanceof win.HTMLInputElement && ['checkbox','radio'].includes(node.type))return {kind:'native',role:node.type,checked:!!node.checked};
    const role=typeof node.getAttribute==='function' && node.getAttribute('role'),value=typeof node.getAttribute==='function' && node.getAttribute('aria-checked');
    if(!['checkbox','radio','switch'].includes(role) || !['true','false'].includes(value))throw failure('UNSUPPORTED_ELEMENT','Expected a checkbox, radio or switch');
    return {kind:'aria',role,checked:value==='true'};
  }
  function rememberCheck(command,node,doc,win,role) {
    const now=Date.now();for(const [id,entry] of pendingChecks)if(entry.expires<=now)pendingChecks.delete(id);
    if(pendingChecks.size>=20)pendingChecks.delete(pendingChecks.keys().next().value);
    const checkId='check-'+now.toString(36)+'-'+(++checkSerial).toString(36);
    pendingChecks.set(checkId,{node,doc,win,role,identity:targetIdentity(command),checked:command.checked,expires:now+2000});return checkId;
  }
  function verifyCheckDOM(command,doc) {
    try {
      if(!command || typeof command.checkId!=='string' || typeof command.checked!=='boolean')throw failure('INVALID_ARGUMENT','Invalid check verification');
      const pending=pendingChecks.get(command.checkId);
      if(!pending || pending.doc!==doc || pending.identity!==targetIdentity(command) || pending.checked!==command.checked)throw failure('ELEMENT_CHANGED','Check target changed');
      if(Date.now()>=pending.expires){pendingChecks.delete(command.checkId);throw failure('CHECK_STATE_NOT_CHANGED','Check verification expired');}
      const selected=selectedNodes(command,doc);
      if(selected.length!==1 || selected[0]!==pending.node)throw failure('ELEMENT_CHANGED','Check target changed');
      const hit=surface(pending.node,'check',pending.win);
      if(command.target && !unobscured(hit,doc,pending.win,true))throw failure('ELEMENT_OCCLUDED','Element is covered');
      const state=toggleState(pending.node,pending.win),verified=state.checked===command.checked;
      if(state.kind!=='aria' || state.role!==pending.role)throw failure('ELEMENT_CHANGED','Check role changed');
      if(verified)pendingChecks.delete(command.checkId);
      return success({checked:state.checked,verified,pending:!verified});
    }catch(error){return {ok:false,error:{code:error.code||'DOM_ERROR',message:error.code||'DOM_ERROR'}};}
  }

  function visible(node, win) {
    const style=win.getComputedStyle(node), rect=node.getBoundingClientRect();
    return !!(node.isConnected && node.getClientRects().length && rect.width>0 && rect.height>0 && style.display!=="none" && style.visibility!=="hidden" && style.visibility!=="collapse" &&
      composedNodes(node).every(item=>{const s=win.getComputedStyle(item);return !item.hidden && s.display!=='none' && s.visibility!=='hidden' && s.visibility!=='collapse';}));
  }
  function surface(node, action, win) {
    let target=node;
    if(!visible(node,win)) {
      if(action!=="check" || !(node instanceof win.HTMLInputElement) || !["checkbox","radio"].includes(node.type) || !node.isConnected)
        throw failure("ELEMENT_HIDDEN","Element is not visible");
      const labels=Array.from(node.labels || []).filter(label=>label.control===node && visible(label,win));
      if(!labels.length)throw failure("ELEMENT_HIDDEN","Checkbox has no visible label");
      if(labels.length!==1)throw failure("AMBIGUOUS_ELEMENT","Checkbox has multiple visible labels");
      target=labels[0];
    }
    if(disabled(node) || disabled(target))
      throw failure("ELEMENT_DISABLED","Element is disabled");
    return target;
  }
  function readyDOM(command,doc) {
    try {
      if(!command || !["click","fill","select","check","assert"].includes(command.action))throw failure("INVALID_ARGUMENT","Invalid readiness command");
      const nodes=selectedNodes(command,doc);
      if(!nodes.length)throw failure("ELEMENT_NOT_FOUND","Element not found");if(nodes.length!==1)throw failure("AMBIGUOUS_ELEMENT","Selector must match exactly one element");
      const win=nodes[0].ownerDocument && nodes[0].ownerDocument.defaultView || doc.defaultView,hit=surface(nodes[0],command.action,win);
      if(command.action==='check')toggleState(nodes[0],win);
      if(command.target && !unobscured(hit,doc,win))throw failure('ELEMENT_OCCLUDED','Element is covered');
      return success({ready:true});
    }catch(error){return {ok:false,error:{code:error.code || "DOM_ERROR",message:error.code || "DOM_ERROR"}};}
  }

  function executeDOM(command, doc) {
    try {
      if (!command) {
        throw failure("INVALID_ARGUMENT", "selector must be a non-empty string");
      }
      const allowed = ["query", "exists", "text", "click", "fill", "select", "check"];
      if (allowed.indexOf(command.action) < 0) throw failure("UNSUPPORTED_ACTION", "Unknown DOM action");
      const nodes=selectedNodes(command,doc);
      const win=nodes[0] && nodes[0].ownerDocument && nodes[0].ownerDocument.defaultView || doc.defaultView;

      if (command.action === "exists") return success(nodes.length > 0);
      if (command.action === "query") {
        return success({ count: nodes.length, truncated: nodes.length > 100,
          elements: nodes.slice(0, 100).map(function (node) {
            const rect = node.getBoundingClientRect();
            return { tag: node.tagName, text: (node.textContent || "").slice(0, 200),
              rect: { x: rect.x, y: rect.y, width: rect.width, height: rect.height } };
          }) });
      }
      if (!nodes.length) throw failure("ELEMENT_NOT_FOUND", "Element not found");
      if (nodes.length !== 1) throw failure("AMBIGUOUS_ELEMENT", "Selector must match exactly one element");
      const node = nodes[0];
      if (command.action === "text") return success(node.textContent || "");

      const interactionSurface=surface(node,command.action,win);
      if(command.target && !unobscured(interactionSurface,doc,win))throw failure('ELEMENT_OCCLUDED','Element is covered');

      if (command.action === "click") {
        if (typeof node.click !== "function") throw failure("UNSUPPORTED_ELEMENT", "Element has no click method");
        node.scrollIntoView({ block: "center", inline: "nearest" });
        confirmAfterViewChange(command,node,doc,win);
        node.click();
        return success({ dispatched: true });
      }
      if (command.action === "check") {
        if (typeof command.checked !== "boolean" || typeof node.click!=='function')
          throw failure("UNSUPPORTED_ELEMENT", "Expected a checkbox or radio button");
        const toggle=toggleState(node,win);
        if (toggle.role === "radio" && !command.checked) throw failure("UNSUPPORTED_ELEMENT", "Radio cannot be cleared individually");
        if(typeof interactionSurface.scrollIntoView==='function')interactionSurface.scrollIntoView({block:"center",inline:"nearest"});
        confirmAfterViewChange(command,node,doc,win);
        const changed=toggleState(node,win).checked!==command.checked;
        if(changed)node.click();
        const finalState=toggleState(node,win);
        if(finalState.checked!==command.checked) {
          if(toggle.kind==='aria' && changed)return success({dispatched:true,checked:finalState.checked,verified:false,pending:true,checkId:rememberCheck(command,node,doc,win,toggle.role)});
          throw failure("CHECK_STATE_NOT_CHANGED","Checkbox did not reach the requested state");
        }
        return success({ dispatched:changed, checked:finalState.checked, verified:true });
      }
      if (command.action === "select") {
        if (!win.HTMLSelectElement || !(node instanceof win.HTMLSelectElement) || node.multiple || typeof command.value !== "string")
          throw failure("UNSUPPORTED_ELEMENT", "Expected a single select");
        const matches = Array.from(node.options).filter(option => option.value === command.value && !option.disabled && !(option.parentElement && option.parentElement.disabled));
        if (!matches.length) throw failure("SELECT_OPTION_NOT_FOUND", "Option not found");
        if (matches.length !== 1) throw failure("AMBIGUOUS_ELEMENT", "Option must be unique");
        const setter = Object.getOwnPropertyDescriptor(win.HTMLSelectElement.prototype, "value");
        if (!setter || typeof setter.set !== "function") throw failure("UNSUPPORTED_ELEMENT", "Select has no native value setter");
        if(command.target && typeof node.scrollIntoView==='function'){node.scrollIntoView({block:'center',inline:'nearest'});confirmAfterViewChange(command,node,doc,win);}
        node.focus(); confirmAfterViewChange(command,node,doc,win);setter.set.call(node, command.value);
        node.dispatchEvent(new win.Event("input", { bubbles: true, composed: true }));
        node.dispatchEvent(new win.Event("change", { bubbles: true, composed: true }));
        return success({ dispatched: true });
      }
      if (typeof command.value !== "string") throw failure("INVALID_ARGUMENT", "value must be a string");
      if (node.readOnly) throw failure("ELEMENT_READONLY", "Element is read-only");
      let prototype;
      if (node instanceof win.HTMLInputElement) {
        const types = ["text", "password", "email", "search", "tel", "url", "number"];
        if (types.indexOf(node.type) < 0) throw failure("UNSUPPORTED_ELEMENT", "Input type is unsupported");
        prototype = win.HTMLInputElement.prototype;
      } else if (node instanceof win.HTMLTextAreaElement) {
        prototype = win.HTMLTextAreaElement.prototype;
      } else if (!node.isContentEditable) {
        throw failure("UNSUPPORTED_ELEMENT", "Element is not editable");
      }
      // Validate the entire command before changing focus or page state.
      const setter = prototype && Object.getOwnPropertyDescriptor(prototype, "value");
      if (prototype && (!setter || typeof setter.set !== "function")) {
        throw failure("UNSUPPORTED_ELEMENT", "Input has no native value setter");
      }
      if(command.target && typeof node.scrollIntoView==='function'){node.scrollIntoView({block:'center',inline:'nearest'});confirmAfterViewChange(command,node,doc,win);}
      node.focus();
      confirmAfterViewChange(command,node,doc,win);
      if (setter) setter.set.call(node, command.value);
      else node.textContent = command.value;
      node.dispatchEvent(new win.Event("input", { bubbles: true, composed: true }));
      node.dispatchEvent(new win.Event("change", { bubbles: true, composed: true }));
      return success({ dispatched: true });
    } catch (error) {
      return { ok: false, error: { code: error.code || "DOM_ERROR", message: error.code ? error.message : "DOM operation failed" } };
    }
  }

  function success(result) { return { ok: true, result: result }; }
  function failure(code, message) {
    const error = new Error(message);
    error.code = code;
    return error;
  }
  if (typeof module !== "undefined" && module.exports) module.exports = { executeDOM: executeDOM, readyDOM:readyDOM,verifyCheckDOM:verifyCheckDOM };
  else root.KPDOM = Object.freeze({ execute: function (command) { return executeDOM(command, root.document); }, ready:function(command){return readyDOM(command,root.document);},verifyCheck:function(command){return verifyCheckDOM(command,root.document);} });
})(typeof globalThis !== "undefined" ? globalThis : this);
