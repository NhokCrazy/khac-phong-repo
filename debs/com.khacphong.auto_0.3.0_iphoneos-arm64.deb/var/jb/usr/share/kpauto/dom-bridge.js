/* Evaluated inside the selected WKWebView, never in the script runner. */
(function (root) {
  "use strict";

  function executeDOM(command, doc) {
    try {
      if (!command || typeof command.selector !== "string" || !command.selector.trim()) {
        throw failure("INVALID_ARGUMENT", "selector must be a non-empty string");
      }
      const allowed = ["query", "exists", "text", "click", "fill"];
      if (allowed.indexOf(command.action) < 0) throw failure("UNSUPPORTED_ACTION", "Unknown DOM action");
      let nodes;
      try { nodes = Array.from(doc.querySelectorAll(command.selector)); }
      catch (_) { throw failure("INVALID_SELECTOR", "Invalid CSS selector"); }
      const win = doc.defaultView;

      if (command.action === "exists") return success(nodes.length > 0);
      if (command.action === "query") {
        return success({ count: nodes.length, truncated: nodes.length > 100,
          elements: nodes.slice(0, 100).map(function (node) {
            const rect = node.getBoundingClientRect();
            return { tag: node.tagName, text: (node.textContent || "").slice(0, 200),
              rect: { x: rect.x, y: rect.y, width: rect.width, height: rect.height } };
          }) });
      }
      if (!nodes.length) throw failure("ELEMENT_NOT_FOUND", "Element not found");
      if (nodes.length !== 1) throw failure("AMBIGUOUS_ELEMENT", "Selector must match exactly one element");
      const node = nodes[0];
      if (command.action === "text") return success(node.textContent || "");

      const style = win.getComputedStyle(node);
      const rect = node.getBoundingClientRect();
      if (!node.isConnected || !node.getClientRects().length || rect.width <= 0 || rect.height <= 0 ||
          style.display === "none" || style.visibility === "hidden" || style.visibility === "collapse") {
        throw failure("ELEMENT_HIDDEN", "Element is not visible");
      }
      if (node.disabled || node.closest('[inert], [aria-disabled="true"]')) {
        throw failure("ELEMENT_DISABLED", "Element is disabled");
      }

      if (command.action === "click") {
        if (typeof node.click !== "function") throw failure("UNSUPPORTED_ELEMENT", "Element has no click method");
        node.scrollIntoView({ block: "center", inline: "nearest" });
        node.click();
        return success({ dispatched: true });
      }
      if (typeof command.value !== "string") throw failure("INVALID_ARGUMENT", "value must be a string");
      if (node.readOnly) throw failure("ELEMENT_READONLY", "Element is read-only");
      let prototype;
      if (node instanceof win.HTMLInputElement) {
        const types = ["text", "password", "email", "search", "tel", "url", "number"];
        if (types.indexOf(node.type) < 0) throw failure("UNSUPPORTED_ELEMENT", "Input type is unsupported");
        prototype = win.HTMLInputElement.prototype;
      } else if (node instanceof win.HTMLTextAreaElement) {
        prototype = win.HTMLTextAreaElement.prototype;
      } else if (!node.isContentEditable) {
        throw failure("UNSUPPORTED_ELEMENT", "Element is not editable");
      }
      // Validate the entire command before changing focus or page state.
      const setter = prototype && Object.getOwnPropertyDescriptor(prototype, "value");
      if (prototype && (!setter || typeof setter.set !== "function")) {
        throw failure("UNSUPPORTED_ELEMENT", "Input has no native value setter");
      }
      node.focus();
      if (setter) setter.set.call(node, command.value);
      else node.textContent = command.value;
      node.dispatchEvent(new win.Event("input", { bubbles: true }));
      node.dispatchEvent(new win.Event("change", { bubbles: true }));
      return success({ dispatched: true });
    } catch (error) {
      return { ok: false, error: { code: error.code || "DOM_ERROR", message: error.code ? error.message : "DOM operation failed" } };
    }
  }

  function success(result) { return { ok: true, result: result }; }
  function failure(code, message) {
    const error = new Error(message);
    error.code = code;
    return error;
  }
  if (typeof module !== "undefined" && module.exports) module.exports = { executeDOM: executeDOM };
  else root.KPDOM = Object.freeze({ execute: function (command) { return executeDOM(command, root.document); } });
})(typeof globalThis !== "undefined" ? globalThis : this);
