/* JavaScriptCore-compatible API. Requires a native host; no device emulation. */
(function (root) {
  "use strict";

  function fault(code, message) {
    const error = new Error(message || code);
    error.code = code;
    return error;
  }

  function string(value, name) {
    if (typeof value !== "string" || !value.trim()) {
      throw fault("INVALID_ARGUMENT", name + " must be a non-empty string");
    }
    return value;
  }

  function number(value, name, min) {
    if (typeof value !== "number" || !Number.isFinite(value) || value < min) {
      throw fault("INVALID_ARGUMENT", name + " is invalid");
    }
    return value;
  }

  function createAutomation(host) {
    if (!host || typeof host.invoke !== "function" || typeof host.sleep !== "function") {
      throw fault("HOST_REQUIRED", "A native invoke/sleep bridge is required");
    }
    const now = typeof host.now === "function" ? () => host.now() : () => Date.now();
    let stopped = false;
    let queue = Promise.resolve();

    function check() {
      if (stopped) throw fault("STOPPED", "Script stopped");
    }

    function invoke(method, payload) {
      const operation = queue.then(async function () {
        check();
        // The host must enforce a bounded timeout. Never replay a timed-out mutation.
        let reply;
        try { reply = await host.invoke(method, payload); }
        catch (_) {
          stopped = true;
          throw fault("OUTCOME_UNKNOWN", "Native transport failed; inspect device state before restarting");
        }
        if (!reply || typeof reply.ok !== "boolean") {
          stopped = true;
          throw fault("INVALID_REPLY", "Invalid native reply");
        }
        if (!reply.ok) {
          const code = reply.error && reply.error.code || "NATIVE_ERROR";
          if (["NATIVE_TIMEOUT", "OUTCOME_UNKNOWN", "INVALID_REPLY"].indexOf(code) >= 0) stopped = true;
          throw fault(code,
            reply.error && reply.error.message || "Native operation failed");
        }
        check();
        return reply.result;
      });
      queue = operation.catch(function () {});
      return operation;
    }

    async function sleep(ms) {
      number(ms, "ms", 0);
      check();
      // Short slices let cooperative stop interrupt long waits.
      let remaining = ms;
      while (remaining > 0) {
        const slice = Math.min(remaining, 100);
        await host.sleep(slice);
        check();
        remaining -= slice;
      }
    }

    async function attach(options) {
      options = options || {};
      const bundleId = string(options.bundleId, "bundleId");
      const requestedId = options.webViewId === undefined ? null : string(options.webViewId, "webViewId");
      const target = await invoke("web.attach", { bundleId: bundleId, webViewId: requestedId });
      if (!target || target.bundleId !== bundleId ||
          !Number.isInteger(target.processId) || target.processId <= 0 ||
          typeof target.webViewId !== "string" || !target.webViewId ||
          typeof target.documentId !== "string" || !target.documentId ||
          (requestedId !== null && requestedId !== target.webViewId)) {
        throw fault("INVALID_TARGET", "Native host did not return the requested WebView");
      }
      const selected = Object.freeze({ bundleId: bundleId, processId: target.processId,
        webViewId: target.webViewId, documentId: target.documentId });

      function dom(action, selector, value) {
        string(selector, "selector");
        const command = { action: action, selector: selector };
        if (value !== undefined) command.value = value;
        return invoke("web.dom", { target: selected, command: command }).then(function (result) {
          if (action === "exists" && typeof result !== "boolean") {
            stopped = true;
            throw fault("INVALID_REPLY", "exists must return a boolean");
          }
          return result;
        });
      }

      return Object.freeze({
        target: selected,
        query: selector => dom("query", selector),
        exists: selector => dom("exists", selector),
        text: selector => dom("text", selector),
        click: selector => dom("click", selector),
        fill: function (selector, value) {
          if (typeof value !== "string") throw fault("INVALID_ARGUMENT", "value must be a string");
          return dom("fill", selector, value);
        },
        evaluate: function (source, args) {
          string(source, "source");
          return invoke("web.evaluate", { target: selected, source: source, args: args || {} });
        },
        loginSecurity: function () {
          if (selected.bundleId !== "com.apple.mobilesafari") throw fault("INVALID_TARGET", "Login readiness requires Safari");
          return invoke("web.loginSecurity", { target: selected }).then(function (result) {
            const keys = ["hasRecaptcha", "documentReady", "apiReady", "frameReady", "ready"];
            if (result && Object.prototype.hasOwnProperty.call(result, "sdkReady")) keys.push("sdkReady");
            if (!result || keys.some(key => typeof result[key] !== "boolean")) {
              stopped = true;
              throw fault("INVALID_REPLY", "Login readiness must contain Boolean fields");
            }
            const safe = {};
            keys.forEach(key => { safe[key] = result[key]; });
            return Object.freeze(safe);
          });
        },
        clearData: domain => invoke("web.clearData", { target: selected, domain: string(domain, "domain") }),
        waitFor: async function (selector, options) {
          string(selector, "selector");
          options = options || {};
          const timeoutMs = options.timeoutMs === undefined ? 10000 : number(options.timeoutMs, "timeoutMs", 0);
          const intervalMs = options.intervalMs === undefined ? 250 : number(options.intervalMs, "intervalMs", 1);
          const deadline = now() + timeoutMs;
          while (true) {
            // Only a successful exists=false is retryable; bridge errors propagate.
            if (await dom("exists", selector)) return true;
            const remaining = deadline - now();
            if (remaining <= 0) throw fault("WAIT_TIMEOUT", "Element did not appear");
            await sleep(Math.min(intervalMs, remaining));
          }
        }
      });
    }

    return Object.freeze({
      stop: function () { stopped = true; },
      sleep: sleep,
      store: Object.freeze({
        get: key => invoke("store.get", {key: string(key, "key")}),
        set: (key, value) => invoke("store.set", {key: string(key, "key"), value: value === undefined ? null : value})
      }),
      network: Object.freeze({
        request: options => invoke("network.request", options || {}),
        airplaneState: () => invoke("network.airplaneState", {}),
        resetAirplane: holdMs => invoke("network.resetAirplane", {holdMs:number(holdMs === undefined ? 3000 : holdMs,"holdMs",1000)})
      }),
      imap: Object.freeze({
        baseline: options => invoke("imap.baseline", options || {}),
        messages: options => invoke("imap.messages", options || {}),
        trash: options => invoke("imap.trash", options || {})
      }),
      progress: Object.freeze({update: value => invoke("progress.update", value || {})}),
      run: Object.freeze({control: () => invoke("run.control", {})}),
      shortcuts: Object.freeze({run: (name, timeoutMs) => invoke("shortcuts.run", {
        name: string(name, "name"), timeoutMs: number(timeoutMs === undefined ? 120000 : timeoutMs, "timeoutMs", 1000)
      })}),
      app: Object.freeze({
        launch: bundleId => invoke("app.launch", { bundleId: string(bundleId, "bundleId") }),
        openURL: (bundleId, url) => invoke("app.openURL", { bundleId: string(bundleId, "bundleId"), url: string(url, "url") }),
        close: bundleId => invoke("app.close", { bundleId: string(bundleId, "bundleId") }),
        state: bundleId => invoke("app.state", { bundleId: string(bundleId, "bundleId") })
      }),
      touch: Object.freeze({
        tap: function (x, y) {
          return invoke("touch.tap", { x: number(x, "x", 0), y: number(y, "y", 0) });
        },
        swipe: function (x1, y1, x2, y2, durationMs) {
          return invoke("touch.swipe", { x1: number(x1, "x1", 0), y1: number(y1, "y1", 0),
            x2: number(x2, "x2", 0), y2: number(y2, "y2", 0),
            durationMs: number(durationMs === undefined ? 400 : durationMs, "durationMs", 1) });
        }
      }),
      web: Object.freeze({
        list: bundleId => invoke("web.list", { bundleId: string(bundleId, "bundleId") }),
        attach: attach
      })
    });
  }

  if (typeof module !== "undefined" && module.exports) module.exports = { createAutomation: createAutomation };
  else root.KPAuto = Object.freeze({ createAutomation: createAutomation });
})(typeof globalThis !== "undefined" ? globalThis : this);
