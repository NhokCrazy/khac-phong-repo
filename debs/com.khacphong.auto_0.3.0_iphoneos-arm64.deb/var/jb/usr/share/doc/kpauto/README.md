# KP Auto 0.3.0 — Dopamine / Dopamine RootHide

Bản thử nghiệm chạy JavaScript trực tiếp trên iPhone jailbreak. Có hai gói riêng: **Dopamine thường/rootless** (`iphoneos-arm64`, cài vào `/var/jb`) và **Dopamine RootHide** (`iphoneos-arm64e`, dùng `jbroot`). Hai gói có cùng Package ID `com.khacphong.auto`; Sileo chọn theo kiến trúc jailbreak.

Hai bản build Windows 0.3.0 hiện chứa binary **arm64**, giới hạn iPhone 8/A11, iOS 16. Bản RootHide 0.2.0 đã được kiểm tra trực tiếp; bản Dopamine thường và bản 0.3.0 chưa được cài/kiểm tra trên thiết bị. Build/cấu trúc gói không chứng minh toàn bộ chức năng trên máy.

Bản rootless giữ script và trạng thái trong `/var/mobile/Library/KPAuto`; descriptor kết nối DOM riêng nằm ở `/var/jb/Library/KPAuto/IPC/worker-mach.json` để phù hợp quyền đọc bootstrap của Safari. Installer tạo thư mục IPC riêng, native kiểm tra đường dẫn/chủ sở hữu/quyền/loại file trước khi đọc hoặc ghi. RootHide giữ đường dẫn descriptor hiện tại. Kết nối controller và quyền SpringBoard trên Dopamine thường vẫn cần kiểm tra thiết bị thật.

Thư mục `repo/` chứa đúng hai file cài 0.3.0, `Packages`/bản nén, `Release` và trang tải. Chưa có URL công khai khi tài khoản GitHub chưa kết nối. Ví dụ build lại: `python tools/build-repo.py --deb packages/com.khacphong.auto_0.3.0_iphoneos-arm64.deb --deb packages/com.khacphong.auto_0.3.0_iphoneos-arm64e.deb --expected-version 0.3.0`. Các dự án khác được thêm bằng đường dẫn `.deb` tường minh; không quét cả workspace.

Đường build A12+ nằm ở `tools/build-native-macos.sh` và `.github/workflows/build-native.yml`: Xcode/macOS tạo hai dylib universal arm64 + arm64e ABI hiện đại, sau đó ký và đóng gói riêng. Workflow, fixtures và metadata đã được kiểm tra; chưa chạy build Mac hoặc kiểm tra A12+ thật. Không dùng output arm64e lỗi của linker Windows để phát hành.

Sau khi tải artifact build Mac vào `.local/build-macos/<scheme>`, dùng `node tools/sign-native.js --scheme <scheme> --build-dir .local/build-macos/<scheme> --require-universal-system` rồi `python tools/package-deb.py --scheme <scheme> --build-dir .local/build-macos/<scheme> --version <phiên-bản-mới> --require-universal-system`. Flag này kiểm tra cả hai dylib universal và ABI arm64e đúng; không dùng nó cho hai gói A11 hiện tại.

Đã cài và cấu hình package trên đúng iPhone qua USB. Đã kiểm tra **JavaScriptCore, Mach IPC có xác thực PID, dừng vòng lặp vô hạn, trạng thái/mở/đóng app, DOM Safari, nhập tiếng Việt và click DOM**. Chạm/vuốt được trang thử xác nhận qua sự kiện `isTrusted`; không chỉ dựa vào kết quả gửi HID. 14 kiểm tra JS/DOM trên PC và kiểm tra bố cục package đều đạt.

**Đã kiểm tra nút CHẠY trên điện thoại:** người dùng chạy `02-kiem-tra-iphone.js` trong KP Auto; Cài đặt tự mở rồi đóng khi manager chuyển nền, runner ghi nhận `origin: manager` và `status: success`. Kết quả trên trang thử không chứng minh mọi app hoặc trang web đều tương thích; kiểm tra selector và kết quả trên app cần dùng trước khi chạy kịch bản thật.

## Sử dụng

**Cyusen trên Safari:** mở `CyusenBrowser.js` để vào dashboard DATA/SETTING/SUCCESS/FAILED. Hướng dẫn và phạm vi kiểm tra nằm tại [conversions/CyusenBrowser/README.md](conversions/CyusenBrowser/README.md). Bản 0.2.0 bổ sung Keychain, HTTPS, Gmail IMAP, progress, DỪNG sau tài khoản, Shortcuts callback và xóa dữ liệu riêng Pokémon Center trong Safari. Các kiểm tra nền tảng dưới đây có từ bản 0.1.0; đọc hướng dẫn Cyusen để xem đúng phần đã kiểm tra của bản chuyển đổi.

1. Cài đúng gói `.deb` qua Sileo. Cần ElleKit; bản RootHide cần thêm RootHide. Helper USB trên PC hiện chọn riêng iPhone 8 RootHide đã cấu hình. Respring để nạp controller vào SpringBoard.
2. Mở **KP Auto**, dùng **NHẬP JS** hoặc dấu **+** để thêm script.
3. Mở script, sửa và nhấn **LƯU** hoặc **CHẠY** ở thanh trên. Script khai báo `main(auto)`.
4. **DỪNG** ngăn lệnh tiếp theo; lệnh native đang xử lý có thể hoàn tất. Runner tự thoát khi JS treo sau yêu cầu dừng. Có **DỪNG CƯỠNG BỨC** khi còn chờ native.
5. **KIỂM TRA KẾT NỐI** kiểm tra controller. Touch cần chạm tay thật một lần sau respring để nhận ID phần cứng.

Tool dùng runner riêng, không cần JSBox hoặc PC khi chạy kịch bản. RootHide phải cho phép inject tweak vào app cần auto; tool không tự thay lựa chọn này.

DOM áp dụng cho **WKWebView đang hiển thị, main frame**. App native không có HTML DOM, có thể dùng touch. Bản đầu chưa có iframe, shadow DOM đóng, OCR, dò ảnh, ghi thao tác hoặc overlay nổi.

## API

```js
async function main(auto) {
  await auto.app.launch("com.apple.mobilesafari");
  await auto.sleep(1000);
  await auto.app.openURL("com.apple.mobilesafari", "https://example.com/");
  await auto.sleep(1500);
  const views = await auto.web.list("com.apple.mobilesafari");
  const visible = views.filter(view => view.visible);
  if (visible.length !== 1) throw Object.assign(new Error(), {code:"CHOOSE_WEBVIEW"});
  const page = await auto.web.attach({bundleId:"com.apple.mobilesafari", webViewId:visible[0].webViewId});
  await page.waitFor("h1", {timeoutMs:10000});
  const heading = await page.text("h1");
  // Dùng heading trong logic. Không ghi dữ liệu trang vào log mặc định.
}
```

| API | Ý nghĩa |
|---|---|
| `auto.app.launch/close/state(bundleId)` | Mở/chờ foreground, đóng PID đã xác minh, đọc trạng thái |
| `auto.app.openURL(bundleId,url)` | Mở URL vào đúng app chỉ định, chờ app lên foreground |
| `auto.touch.tap(x,y)` | Tọa độ point theo orientation hiện tại |
| `auto.touch.swipe(x1,y1,x2,y2,durationMs)` | Mặc định 400 ms, tối đa 5000 ms |
| `auto.web.list(bundleId)` | Process/WebView và cờ `visible` |
| `auto.web.attach({bundleId,webViewId})` | Chọn đúng WebView và document |
| `page.query/exists/text(selector)` | Metadata tối đa 100 phần tử, boolean, nội dung text |
| `page.fill(selector,value)` / `page.click(selector)` | Nhập/click phần tử khớp duy nhất |
| `page.evaluate(source,args)` | Thân hàm JS, tham số qua `args`, kết quả JSON |
| `page.loginSecurity()` | Đọc cờ sẵn sàng của thư viện trên trang đăng nhập Pokémon Center/Safari; chỉ trả boolean |
| `page.waitFor(selector,{timeoutMs,intervalMs})` | Chờ khi phần tử chưa có, lỗi bridge không retry |
| `auto.sleep(ms)` / `auto.stop()` | Chờ / dừng hợp tác |
| `auto.store.get/set(key,value)` | JSON Keychain theo namespace của script |
| `auto.network.request(options)` | HTTPS, response status/headers/body, hạn tối đa 30 giây |
| `auto.network.airplaneState()` / `auto.network.resetAirplane(holdMs)` | Đọc trạng thái / bật máy bay, giữ 1–4 giây, tắt và xác nhận |
| `auto.imap.baseline/messages/trash(options)` | Gmail TLS, UIDVALIDITY/UIDNEXT, đúng một UID khi chuyển Trash |
| `auto.progress.update(value)` / `auto.run.control()` | Trạng thái an toàn và yêu cầu DỪNG sau tài khoản |
| `auto.shortcuts.run(name,timeoutMs)` | Chạy phím tắt, chờ callback gắn với lượt chạy |
| `page.clearData('pokemoncenter-online.com')` | Xóa và kiểm tra dữ liệu/cookie của domain trong phiên Safari đã chọn |

Ví dụ evaluate: `await page.evaluate("return document.title;", {})`.

Click/fill chỉ báo đã gửi sự kiện, không xác nhận kết quả nghiệp vụ. Sự kiện DOM khác chạm thật (`isTrusted`), cần kiểm tra với trang/framework thực tế. Sau điều hướng phải attach lại; document đổi trả `STALE_DOCUMENT`. Không tự chuyển WebView hoặc tự chạy lại thao tác khi timeout.

## Native và dữ liệu

- `native/app`: quản lý, nhập/sửa, chạy/dừng script; dữ liệu ở `jbroot("/var/mobile/Library/KPAuto")`.
- `native/worker`: process/JSContext mới cho mỗi lần chạy, `flock` ngăn chạy trùng, script tối đa 1 MB, xử lý dừng cả vòng lặp treo.
- `native/controller`: SpringBoard chỉ nhận thao tác từ executable runner đã xác minh; manager chỉ đọc trạng thái. Không tự mở khóa màn hình.
- `native/webview`: content world riêng; kiểm tra bundle/PID/WebView/document, visibility và deadline trước khi thực thi. JS trang không truy cập native bridge.
- `native/common`: Mach JSON tối đa 64 KB; audit PID do kernel cấp cho request và reply; ID/run ID chống nhận kết quả cũ.

Không lưu kết quả `main`, payload DOM, giá trị nhập, cookie hoặc thông báo lỗi JS tùy ý vào log mặc định. Native timeout không chứng minh thao tác chưa xảy ra.

Runner đăng ký Mach service mới cho từng lượt chạy, gồm PID và nonce. Capability cho riêng service đó được ghi trong thư mục riêng của tool với quyền `0600`; bridge tiêu thụ sandbox extension để gọi service và kiểm tra PID của phản hồi bằng audit trailer từ kernel. Worker xác minh bundle của app gọi tới. Capability được xóa khi lượt chạy kết thúc bình thường hoặc watchdog dừng runner. Không ghi token capability vào log. Đã kiểm tra trao đổi hai chiều với Safari sandbox trên máy; không cần cài RocketBootstrap. Thư viện RocketBootstrap tương thích nếu có vẫn được hỗ trợ.

## Build Windows

Toolchain trong `.local`, không thay cài đặt Windows hoặc dùng WSL: LLVM 20.1.8 chính thức; SDK iPhoneOS16.5 từ `theos/sdks` commit `0222fd5413cf4b9af096f37b4621afa2688572f7`; libroothide đọc từ máy để link (không nhúng vào package). Ký bằng ldid sẵn có trên iPhone.

```powershell
npm test
node tools/build-cyusen.js
node tools/build-native.js --all
node tools/device-smoke.js
node tools/sign-native.js
python tools/package-deb.py
```

Chỉ tiếp tục khi lệnh trước thành công. Package ở `packages`. Không tạo EXE hoặc ZIP phân phối.

USB proxy chọn đúng model/iOS/serial suffix mỗi kết nối, từ chối nếu không khớp duy nhất. SSH cổng 2222, host key đã kiểm tra, key riêng dự án. Không tác động các iPhone khác.

`device-smoke.js` chỉ chạy binary trong thư mục riêng `kpauto-build-test` bên RootHide, không cài tweak/mở app/respring. Kiểm tra vòng lặp có watchdog, chỉ kết thúc process kiểm tra của helper.

`tools/install-iphone.ps1` chuyển đúng package, kiểm tra SHA256, cài và respring. SSH dùng key của **mobile**, rồi hỏi mật khẩu **mobile/sudo** ở terminal với ký tự ẩn. Mật khẩu đi qua pipe/stdin để xác thực sudo; không ghi vào file, argv hoặc biến môi trường. Không cần đăng nhập SSH root. Chỉ chạy khi sẵn sàng cài bản thử nghiệm và respring.

Package có các record thư mục cha trước file để dpkg giải nén vào máy chưa có thư mục app. Kiểm tra hồi quy: `python -m unittest discover -s tests -p test_deb_layout.py`.

Sau cài, `node tools/ssh-iphone.js '"$(jbroot /usr/libexec/kpautorun)" --diagnose'` đọc trạng thái controller. Kiểm tra tiếp với app/trang thử không có giao dịch. Gỡ qua Sileo package `com.khacphong.auto` rồi respring; giữ thư mục script người dùng.

`node tools/build-native.js --fixture` và `node tools/device-web-probe.js` chạy bài thử với server loopback tạm thời, URL riêng cho mỗi lượt. Bài thử xác minh đúng trang trước khi chạm/vuốt, đọc kết quả DOM, rồi đóng Safari và dọn script/server của lượt kiểm tra. `--reload-bridge` đóng Safari trước khi thử nếu vừa thay bridge. Các helper này cần PC để kiểm tra; kịch bản bình thường trong KP Auto chạy trực tiếp trên điện thoại.

`node tools/prepare-manager-check.js` đặt script cố định `02-kiem-tra-iphone.js` lên máy, giữ nguyên nếu người dùng đã sửa nội dung. Script mở Cài đặt, xác minh foreground, chờ 4 giây rồi đóng; không thay đổi cài đặt. Mở script trong KP Auto và nhấn CHẠY để kiểm tra runner khi manager chuyển nền. Trạng thái lượt chạy lưu `origin: manager` khi tiến trình được tạo trực tiếp bởi KP Auto, giúp phân biệt bài thử qua SSH.

## Tài liệu đối chiếu

[RootHide Developer](https://github.com/roothide/Developer), [RootHide Theos](https://github.com/roothide/theos), [LLVM 20.1.8](https://github.com/llvm/llvm-project/releases/tag/llvmorg-20.1.8), [Theos SDKs](https://github.com/theos/sdks), [Theos SpringBoardServices](https://github.com/theos/headers/tree/master/SpringBoardServices), [LLVM debugserver](https://github.com/llvm/llvm-project/tree/main/lldb/tools/debugserver/source), [Apple WebKit HID](https://github.com/WebKit/WebKit/blob/main/Tools/WebKitTestRunner/ios/HIDEventGenerator.mm), [RocketBootstrap](https://github.com/rpetrich/rocketbootstrap).

Mã triển khai của tool được viết trong dự án này; không nhúng mã GPL của AutoTouch hoặc ZXTouch.
