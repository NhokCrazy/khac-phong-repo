/* JavaScriptCore-compatible recording and replay. Values live in the script's Keychain DATA. */
(function(root) {
  'use strict';
  function fault(code,step) { const e=Object.assign(new Error(code),{code:code}); if (step!==undefined)e.step=step; return e; }
  function text(v) { return typeof v==='string' && v.length>0; }
  let serial=0;
  function newId() { return 'step-'+Date.now().toString(36)+'-'+(++serial).toString(36)+'-'+Math.random().toString(36).slice(2,10); }
  const recoverableCodes=['WAIT_TIMEOUT','ELEMENT_NOT_FOUND','ELEMENT_HIDDEN','ELEMENT_DISABLED','ELEMENT_OCCLUDED','ELEMENT_READONLY','WRONG_PAGE','WEB_AGENT_UNAVAILABLE','APP_NOT_ACTIVE'];
  function safeCode(v) { return typeof v==='string' && /^[A-Z][A-Z0-9_]{0,63}$/.test(v) ? v : 'WORKFLOW_FAILED'; }
  function customOriginValid(origin) {
    if(!/^(?:ionic|capacitor):/i.test(origin))return true;
    const parts=/^(?:ionic|capacitor):\/\/([^/:@?#]+)(?::([0-9]{1,5}))?$/.exec(origin);
    return !!parts && parts[1].length<=253 && parts[1].split('.').every(part=>/^[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?$/.test(part)) &&
      (!parts[2] || (Number(parts[2])>=1 && Number(parts[2])<=65535 && String(Number(parts[2]))===parts[2]));
  }
  function validateShadowPath(path,index) {
    if(!Array.isArray(path) || !path.length || path.length>12)throw fault('WORKFLOW_INVALID',index);
    path.forEach(host=>{
      if(!host || typeof host!=='object' || Array.isArray(host) || Object.keys(host).some(k=>!['selector','tag','strategy','label'].includes(k)) ||
         typeof host.selector!=='string' || !host.selector.trim() || host.selector.length>2048 || typeof host.tag!=='string' || !/^[a-z][a-z0-9-]{0,63}$/.test(host.tag) ||
         !['data-testid','data-test','id','name','aria-label','placeholder','structure'].includes(host.strategy) || typeof host.label!=='string' || host.label.length>200)throw fault('WORKFLOW_INVALID',index);
    });
  }
  function effectValid(effect,ids) {
    if(!effect || !['continue','goto','nextRow','stop'].includes(effect.action))throw fault('BRANCH_INVALID');
    if(effect.action==='goto' && !text(effect.stepId))throw fault('BRANCH_TARGET_MISSING');
    if(effect.stepId && !ids.has(effect.stepId))throw fault('BRANCH_TARGET_MISSING');
    if(effect.stepId && !['goto','nextRow'].includes(effect.action))throw fault('BRANCH_INVALID');
  }
  function validate(workflow) {
    if (!workflow || ![1,2].includes(workflow.version) || !text(workflow.bundleId) || !Array.isArray(workflow.steps) || workflow.steps.length>1000)
      throw fault('WORKFLOW_INVALID');
    const ids=new Set();workflow.steps.forEach(step=>{if(step && step.id) {if(!/^[A-Za-z0-9_-]{1,100}$/.test(step.id) || ids.has(step.id))throw fault('STEP_ID_INVALID');ids.add(step.id);}});
    const createIds=new Set();workflow.steps.forEach((step,index)=>{
      if(!step || step.action!=='createContainer')return;
      const id=step.id || 'legacy-create-'+index;
      if(createIds.has(id) || (!step.id && ids.has(id)))throw fault('STEP_ID_INVALID',index+1);
      createIds.add(id);
    });
    workflow.steps.forEach(function(step,index) {
      if (!step || !['click','fill','select','check','wait','assert','condition','restartApp','nextRow','nextContainer','createContainer','resetIP','unsupported'].includes(step.action)) throw fault('WORKFLOW_INVALID',index+1);
      if (step.disabled===true)return;
      if (step.action==='unsupported')throw fault('RECORD_ELEMENT_UNSUPPORTED',index+1);
      if(step.action==='createContainer') {
        if(step.startNumber!==undefined && (!Number.isInteger(step.startNumber) || step.startNumber<0 || step.startNumber>999999999))throw fault('CRANE_NUMBER_INVALID',index+1);
        return;
      }
      if(['restartApp','nextRow','nextContainer'].includes(step.action))return;
      if(step.action==='resetIP'){if(step.holdMs!==undefined && (!Number.isInteger(step.holdMs)||step.holdMs<1000||step.holdMs>7000))throw fault('WORKFLOW_INVALID',index+1);return;}
      if (step.action==='wait') { if (!Number.isFinite(step.ms) || step.ms<0 || step.ms>60000)throw fault('WORKFLOW_INVALID',index+1); return; }
      if(step.action==='condition') {
        const test=step.test;
        if(!test || !['element','text','data'].includes(test.type))throw fault('CONDITION_INVALID',index+1);
        if(test.type==='data') {if(!/^[A-Za-z][A-Za-z0-9_]{0,63}$/.test(test.variable||'') || !['empty','notEmpty'].includes(test.operator))throw fault('CONDITION_INVALID',index+1);}
        else if(test.type==='element') {if(!['exists','absent'].includes(test.operator))throw fault('CONDITION_INVALID',index+1);}
        else if(!['contains','equals'].includes(test.operator) || !text(test.expected) || test.expected.length>200)throw fault('CONDITION_INVALID',index+1);
        effectValid(step.then||{action:'continue'},ids);effectValid(step.else||{action:'continue'},ids);
        if(step.maxUses!==undefined && (!Number.isInteger(step.maxUses) || step.maxUses<1 || step.maxUses>10))throw fault('BRANCH_LIMIT_INVALID');
        if(test.type==='data') {if(step.target || step.page)throw fault('CONDITION_INVALID',index+1);return;}
      }
      if (!step.target || !['web','native'].includes(step.target.kind))throw fault('WORKFLOW_INVALID',index+1);
      if(step.target.kind==='native') {
        const allowed=['kind','class','role','identifier','label','placeholder','sensitive','path','screen','screenTitle'];
        if(!text(step.target.class) || ![step.target.identifier,step.target.label,step.target.placeholder,step.target.path].some(text) || Object.keys(step.target).some(k=>!allowed.includes(k)))throw fault('NATIVE_SELECTOR_INVALID',index+1);
      }
      if (step.target.kind==='web' && (!text(step.target.selector) || !text(step.target.tag) || !step.page || !text(step.page.origin) || !text(step.page.path)))throw fault('WORKFLOW_INVALID',index+1);
      if(step.target.kind==='web' && !customOriginValid(step.page.origin))throw fault('WORKFLOW_INVALID',index+1);
      if(step.target.kind==='web' && step.target.shadowPath!==undefined)validateShadowPath(step.target.shadowPath,index+1);
      if (['fill','select'].includes(step.action) && !/^[A-Za-z][A-Za-z0-9_]{0,63}$/.test(step.variable || ''))throw fault('DATA_FIELD_INVALID',index+1);
      if (step.action==='check' && typeof step.checked!=='boolean')throw fault('WORKFLOW_INVALID',index+1);
      if(step.timeoutMs!==undefined && (!Number.isFinite(step.timeoutMs) || step.timeoutMs<0 || step.timeoutMs>60000))throw fault('WORKFLOW_INVALID',index+1);
    });
    if(workflow.onError!==undefined && (!Array.isArray(workflow.onError) || workflow.onError.length>40))throw fault('ERROR_RULE_INVALID');
    const codes=new Set();(workflow.onError||[]).forEach(rule=>{
      if(!rule || safeCode(rule.code)!==rule.code || codes.has(rule.code))throw fault('ERROR_RULE_INVALID');codes.add(rule.code);effectValid(rule.effect,ids);
      if(rule.effect.action==='continue')throw fault('ERROR_RULE_INVALID');
      if(rule.effect.action!=='stop' && !recoverableCodes.includes(rule.code))throw fault('ERROR_RULE_UNSAFE');
      if(!Number.isInteger(rule.maxUses) || rule.maxUses<1 || rule.maxUses>10)throw fault('BRANCH_LIMIT_INVALID');
    });
    if(workflow.maxStepsPerRow!==undefined && (!Number.isInteger(workflow.maxStepsPerRow) || workflow.maxStepsPerRow<1 || workflow.maxStepsPerRow>20000))throw fault('WORKFLOW_INVALID');
    if(workflow.resetBeforeRow!==undefined && typeof workflow.resetBeforeRow!=='boolean')throw fault('WORKFLOW_INVALID');
    if(workflow.runCount!==undefined && (!Number.isInteger(workflow.runCount) || workflow.runCount<1 || workflow.runCount>1000))throw fault('RUN_COUNT_INVALID');
    return workflow;
  }
  function append(workflow,event,options) {
    options=options || {};
    if (workflow.steps.length>=1000)throw fault('RECORD_LIMIT');
    if (!event || !['click','fill','select','check','condition','unsupported'].includes(event.action))throw fault('RECORD_EVENT_INVALID');
    const ids=new Set(workflow.steps.map(s=>s.id));let identifier;do{identifier=newId();}while(ids.has(identifier));
    const step={id:identifier,action:event.action};
    if (event.action==='unsupported')step.code=event.code || 'RECORD_ELEMENT_UNSUPPORTED';
    else {
      const fields=event.target && event.target.kind==='native' ? ['kind','class','role','identifier','label','placeholder','sensitive','path','screen','screenTitle'] : ['kind','selector','tag','type','label','strategy','sensitive'];
      step.target={};fields.forEach(k=>{if(event.target && event.target[k]!==undefined)step.target[k]=event.target[k];}); if (event.page)step.page={origin:event.page.origin,path:event.page.path};
      if(step.target.kind==='web' && event.target.shadowPath!==undefined) {
        validateShadowPath(event.target.shadowPath);
        step.target.shadowPath=event.target.shadowPath.map(host=>({selector:host.selector,tag:host.tag,strategy:host.strategy,label:host.label}));
      }
      if(event.action==='condition') {
        const expected=event.test && event.test.expected;
        if(!text(expected) || expected.length>200)throw fault('CONDITION_INVALID');
        step.test={type:'text',operator:'contains',expected:expected};step.then={action:'stop'};step.else={action:'continue'};step.maxUses=1;
      }
      if (event.action==='check')step.checked=event.checked;
      if (['fill','select'].includes(event.action)) {
        const identity=x=>JSON.stringify([fields.map(k=>x.target && x.target[k]),x.target && x.target.shadowPath && x.target.shadowPath.map(h=>[h.selector,h.tag,h.strategy,h.label]),x.page && x.page.origin,x.page && x.page.path]);
        const previous=workflow.steps.find(x=>x.variable && identity(x)===identity(step));
        const variables=new Set(workflow.steps.flatMap(x=>[x.variable,x.test && x.test.variable]).filter(Boolean));
        let number=variables.size+1;while(variables.has('data_'+number))number++;
        step.variable=previous ? previous.variable : 'data_'+number;
        const last=workflow.steps[workflow.steps.length-1];
        if (workflow.steps.length>(options.minimumIndex || 0) && last && ['fill','select'].includes(last.action) && last.variable===step.variable && identity(last)===identity(step)) {
          last.action=step.action; return;
        }
      }
    }
    // Whitelist above deliberately drops value/text/coordinates and arbitrary message fields.
    workflow.steps.push(step);
  }
  function dataRows(workflow,data) {
    const variables=Array.from(new Set(workflow.steps.filter(s=>!s.disabled).flatMap(s=>[s.variable,s.test && s.test.type==='data' && s.test.variable]).filter(Boolean)));
    const rows=data===null || data===undefined ? [{}] : (Array.isArray(data) ? data : [data]);
    if (!rows.length || rows.length>2000)throw fault('DATA_INVALID');
    rows.forEach(row=> { if (!row || typeof row!=='object' || Array.isArray(row) || variables.some(k=>!Object.prototype.hasOwnProperty.call(row,k) || typeof row[k]!=='string'))throw fault('DATA_MISSING'); });
    return rows;
  }
  function create(auto,invoke,persistFailure,persistLog,finishOverlay,persistRecordFailure) {
    async function captureAppend(options) {
      const snapshot=await invoke('store.snapshot',{key:'workflow'});
      if(!snapshot || !Object.prototype.hasOwnProperty.call(snapshot,'value') || typeof snapshot.revision!=='string' || !/^[a-f0-9]{64}$/.test(snapshot.revision))throw fault('INVALID_REPLY');
      const stored=snapshot.value;
      const original=stored || options.workflow;
      validate(original);
      if(original.bundleId!==options.bundleId)throw fault('RECORD_APP_MISMATCH');
      const workflow=JSON.parse(JSON.stringify(original)),originalSteps=workflow.steps.length;
      if(originalSteps>=1000)throw fault('RECORD_LIMIT');
      const timeout=options.attachTimeoutMs===undefined ? 120000 : options.attachTimeoutMs;
      if(!Number.isInteger(timeout) || timeout<500 || timeout>120000)throw fault('INVALID_ARGUMENT');
      const session=options.session;let cursor=0,started=false,committed=false,cancelled=false,phase='waiting',code='';
      const status=()=>({mode:'append',phase:phase,session:session,originalSteps:originalSteps,steps:workflow.steps.length,addedSteps:workflow.steps.length-originalSteps,stopped:['complete','cancelled','failed'].includes(phase),committed:committed,code:code});
      try {
        await auto.store.set('recordControl',{stop:false,cancel:false});
        await auto.store.set('recordingDraft',{mode:'append',session:session,workflow:workflow,originalSteps:originalSteps});
        await auto.store.set('recordStatus',status());
        const until=Date.now()+timeout;
        while(true) {
          const control=await auto.store.get('recordControl');
          if(control && (control.stop || control.cancel)){cancelled=true;break;}
          const state=await auto.app.state(workflow.bundleId);
          if(!state || typeof state.foreground!=='boolean' || state.bundleId!==workflow.bundleId)throw fault('INVALID_REPLY');
          if(state.foreground)break;
          if(Date.now()>=until)throw fault('RECORD_APP_NOT_READY');
          await auto.sleep(250);
        }
        if(!cancelled) {
          await invoke('record.start',{bundleId:workflow.bundleId,session:session,mode:'append',armed:true});started=true;phase='armed';
          while(true) {
            const control=await auto.store.get('recordControl');
            if(control && control.cancel){cancelled=true;break;}
            const packet=await invoke('record.read',{bundleId:workflow.bundleId,session:session,after:cursor,stop:!!(control && control.stop)});
            if(!packet || !Array.isArray(packet.events) || typeof packet.stopped!=='boolean' || typeof packet.started!=='boolean' || typeof packet.cancelled!=='boolean')throw fault('INVALID_REPLY');
            if(packet.cancelled){cancelled=true;break;}
            if(packet.failure)throw fault(safeCode(packet.failure));
            if(!packet.started && packet.events.length)throw fault('INVALID_REPLY');
            for(const event of packet.events) {
              if(!Number.isInteger(event.seq) || event.seq!==cursor+1)throw fault('RECORD_SEQUENCE_LOST');
              append(workflow,event,{minimumIndex:originalSteps});cursor=event.seq;
            }
            // Only the separate draft is durable until the user saves the completed append.
            await auto.store.set('recordingDraft',{mode:'append',session:session,workflow:workflow,originalSteps:originalSteps});
            phase=packet.started ? 'recording' : 'armed';await auto.store.set('recordStatus',Object.assign(status(),{paused:!!packet.paused}));
            if(packet.stopped && !packet.more) {
              if(!packet.started){cancelled=true;break;}
              const finalControl=await auto.store.get('recordControl');
              if(finalControl && finalControl.cancel){cancelled=true;break;}
              validate(workflow);
              try{await invoke('store.compareSet',{key:'workflow',expectedRevision:snapshot.revision,value:workflow});}
              catch(error){if(error.code==='STORE_CONFLICT')throw fault('RECORD_WORKFLOW_CHANGED');throw error;}
              committed=true;break;
            }
            await auto.sleep(packet.more ? 10 : 250);
          }
        }
        phase=cancelled ? 'cancelled' : 'complete';code=cancelled ? 'RECORD_CANCELLED' : '';
        try{await auto.store.set('recordStatus',status());}catch(_){}
        return status();
      } catch(error) {
        phase='failed';code=safeCode(error.code);
        try{await auto.store.set('recordStatus',status());}catch(_){}
        throw error;
      } finally {
        if(started)try{await invoke('record.stop',{bundleId:workflow.bundleId,session:session});}catch(_){}
        try{await auto.store.set('recordingDraft',null);}catch(_){}
      }
    }
    async function capture(options) {
      if(!options || !text(options.session) || !text(options.bundleId) || (options.mode!==undefined && !['new','append'].includes(options.mode)))throw fault('INVALID_ARGUMENT');
      if(options.mode==='append')return captureAppend(options);
      const workflow={version:2,name:options.name || 'Kịch bản ghi',bundleId:options.bundleId,startURL:options.startURL || '',steps:[]};
      const session=options.session;
      if (!text(session) || !text(options.bundleId))throw fault('INVALID_ARGUMENT');
      let cursor=0, started=false;
      try {
        await auto.store.set('recordStatus',{mode:'new',phase:'starting',session:session,steps:0,stopped:false,code:''});
        await auto.store.set('recordControl',{stop:false});
        await auto.store.set('workflow',workflow);
        await auto.app.launch(workflow.bundleId);
        if (workflow.startURL)await auto.app.openURL(workflow.bundleId,workflow.startURL);
        await auto.sleep(800);
        const startUntil=Date.now()+5000;
        while(true) {
          try{await invoke('record.start',{bundleId:workflow.bundleId,session:session});started=true;break;}
          catch(error){
            // These native refusals happen before a recording session exists.
            // A launch transition can settle; an uncertain mutation cannot retry.
            if(!['APP_NOT_ACTIVE','WEB_AGENT_UNAVAILABLE','AMBIGUOUS_WEBVIEW'].includes(error.code) || Date.now()>=startUntil)throw error;
            await auto.sleep(Math.min(250,startUntil-Date.now()));
          }
        }
        // A newly recorded form must never inherit values from the previous field mapping.
        await auto.store.set('data',null);
        while (true) {
          const control=await auto.store.get('recordControl');
          const packet=await invoke('record.read',{bundleId:workflow.bundleId,session:session,after:cursor,stop:!!(control && control.stop)});
          if (!packet || !Array.isArray(packet.events) || typeof packet.stopped!=='boolean')throw fault('INVALID_REPLY');
          for (const event of packet.events) {
            if (!Number.isInteger(event.seq) || event.seq!==cursor+1)throw fault('RECORD_SEQUENCE_LOST');
            append(workflow,event); cursor=event.seq;
          }
          // Commit before acknowledging events on the next poll. Process crashes preserve a usable draft.
          await auto.store.set('workflow',workflow);
          await auto.store.set('recordStatus',{mode:'new',phase:packet.stopped && !packet.more ? 'complete' : 'recording',session:session,steps:workflow.steps.length,paused:!!packet.paused,stopped:packet.stopped,code:''});
          if (packet.failure)throw fault(packet.failure);
          if (packet.stopped && !packet.more)break;
          await auto.sleep(packet.more ? 10 : 250);
        }
      } catch(error) {
        const status={mode:'new',phase:'failed',session:session,steps:workflow.steps.length,stopped:true,code:safeCode(error.code)};
        try{if(persistRecordFailure)await persistRecordFailure(status);else await auto.store.set('recordStatus',status);}catch(_){}
        throw error;
      } finally {
        if (started) { try { await invoke('record.stop',{bundleId:workflow.bundleId,session:session}); } catch (_) {} }
      }
      await auto.app.launch('com.khacphong.auto');
    }
    async function currentPage(bundle) {
      const views=await auto.web.list(bundle), visible=views.filter(v=>v.visible);
      if (visible.length!==1)throw fault(visible.length ? 'AMBIGUOUS_WEBVIEW' : 'NO_WEBVIEW');
      return auto.web.attach({bundleId:bundle,webViewId:visible[0].webViewId});
    }
    async function condition(workflow,step,row,heartbeat) {
      const test=step.test;
      if(test.type==='data'){if(heartbeat)await heartbeat();return test.operator==='empty' ? row[test.variable]==='' : row[test.variable]!=='';}
      const end=Date.now()+(step.timeoutMs===undefined ? 1500 : Math.max(0,Math.min(step.timeoutMs,60000)));
      while(true) {
        if(heartbeat)await heartbeat();let found=false,content='',wrongPage=false,observed=false;
        try {
          if(step.target.kind==='native') {
            const result=await invoke('ui.inspect',{bundleId:workflow.bundleId,selector:step.target});
            if(!result || !Number.isInteger(result.count) || result.count<0)throw fault('INVALID_REPLY');
            if(result.count>1)throw fault('AMBIGUOUS_ELEMENT');
            found=result.count===1 && result.interactable!==false;
            if(found && test.type==='text') {if(typeof result.text!=='string')throw fault('CONDITION_TEXT_UNAVAILABLE');content=result.text;}
            observed=true;
          } else {
            const page=await currentPage(workflow.bundleId);
            const result=await page.evaluate("const c=KPRecorder.context(document);if(c.origin!==args.page.origin||c.path!==args.page.path)return {found:false,wrongPage:true,text:''};try{const e=KPRecorder.resolve(args.target,document);const r=KPDOM.ready({action:'assert',target:args.target});if(!r.ok && !['ELEMENT_HIDDEN','ELEMENT_DISABLED','ELEMENT_OCCLUDED'].includes(r.error.code))return {code:r.error.code};return {found:r.ok || r.error.code==='ELEMENT_DISABLED',text:args.readText?KPRecorder.cleanText(e.textContent):''};}catch(e){return e.code==='ELEMENT_NOT_FOUND'?{found:false,text:''}:{code:e.code||'INVALID_TARGET'};}",{target:step.target,page:step.page,readText:test.type==='text'});
            if(result.code)throw fault(result.code);found=result.found;content=result.text;wrongPage=!!result.wrongPage;
            if(typeof found!=='boolean' || typeof content!=='string')throw fault('INVALID_REPLY');
            observed=true;
          }
        }catch(error){if(!['STALE_DOCUMENT','NO_WEBVIEW','APP_NOT_ACTIVE'].includes(error.code))throw error;if(error.code==='NO_WEBVIEW'){wrongPage=true;observed=true;}}
        if(!observed){if(Date.now()>=end)throw fault('WAIT_TIMEOUT');await auto.sleep(Math.min(250,end-Date.now()));continue;}
        const match=!wrongPage && (test.type==='element' ? (test.operator==='exists' ? found : !found) : found && (test.operator==='equals' ? content===test.expected : content.includes(test.expected)));
        if(test.operator==='absent') {if(!match)return false;if(Date.now()>=end)return true;}
        else if(match)return true;
        if(Date.now()>=end)return false;
        await auto.sleep(Math.min(250,end-Date.now()));
      }
    }
    async function act(workflow,step,row,heartbeat) {
      const timeoutMs=Number.isFinite(step.timeoutMs) ? Math.max(100,Math.min(step.timeoutMs,60000)) : 15000;
      const deadline=Date.now()+timeoutMs;
      if (step.action==='condition')return condition(workflow,step,row,heartbeat);
      if (step.action==='wait') { const end=Date.now()+step.ms;while(Date.now()<end){if(heartbeat)await heartbeat();const remaining=end-Date.now();if(remaining>0)await auto.sleep(Math.min(500,remaining));}return; }
      while (true) {
        if(heartbeat)await heartbeat();
        let mutationSent=false;
        try {
          if (step.target.kind==='native') {
            const result=await invoke('ui.inspect',{bundleId:workflow.bundleId,selector:step.target});
            if (!result || !Number.isInteger(result.count) || result.count<0 || typeof result.enabled!=='boolean' || (result.interactable!==undefined && typeof result.interactable!=='boolean'))throw fault('INVALID_REPLY');
            if (result.count===0)throw fault('ELEMENT_NOT_FOUND');
            if (result.count!==1)throw fault('AMBIGUOUS_ELEMENT');
            if(step.action==='assert' && step.target.role==='text' && result.interactable!==false)return;
            if (!result.enabled)throw fault('ELEMENT_DISABLED');
            if (result.interactable===false)throw fault('ELEMENT_OCCLUDED');
            if (step.action==='assert')return;
            const payload={bundleId:workflow.bundleId,selector:step.target,action:step.action};
            if (step.variable)payload.value=row[step.variable];
            if (step.action==='check')payload.checked=step.checked;
            mutationSent=true; await invoke('ui.perform',payload); return;
          }
          const page=await currentPage(workflow.bundleId);
          // Query/readiness retries are allowed. Mutations below are sent only once.
          const readiness=await page.evaluate("const c=KPRecorder.context(document); if(c.origin!==args.page.origin||c.path!==args.page.path)return {ready:false,code:'WRONG_PAGE'}; try { const r=KPDOM.ready({action:args.action,target:args.target});return r.ok ? {ready:true} : {ready:false,code:r.error.code}; } catch(e) { return {ready:false,code:e.code||'INVALID_TARGET'}; }",{target:step.target,page:step.page,action:step.action==='assert' && ['checkbox','radio'].includes(step.target.type) ? 'check' : step.action});
          if (!readiness.ready)throw fault(readiness.code);
          if (step.action==='assert')return;
          const command={action:step.action,selector:step.target.selector,target:step.target};
          if(step.variable)command.value=row[step.variable];
          if(step.action==='check')command.checked=step.checked;
          mutationSent=true;
          const dispatched=await page.evaluate("try { const c=KPRecorder.context(document); if(c.origin!==args.page.origin||c.path!==args.page.path)return {ok:false,code:'WRONG_PAGE'}; const r=KPDOM.execute(args.command); return r.ok ? {ok:true,result:r.result} : {ok:false,code:r.error.code}; } catch(e) { return {ok:false,code:e.code||'DOM_ERROR'}; }",{target:step.target,page:step.page,command:command});
          if(!dispatched || dispatched.ok!==true)throw fault(dispatched && dispatched.code || 'INVALID_REPLY');
          if(step.action==='check' && dispatched.result && dispatched.result.pending===true) {
            const pending=dispatched.result;
            if(pending.dispatched!==true || pending.verified!==false || typeof pending.checked!=='boolean' || typeof pending.checkId!=='string' || !/^check-[a-z0-9-]{1,80}$/.test(pending.checkId))throw fault('INVALID_REPLY');
            const verifyUntil=Date.now()+1500,verification={target:step.target,selector:step.target.selector,checked:step.checked,checkId:pending.checkId};
            while(true) {
              const checked=await page.evaluate("try{const c=KPRecorder.context(document);if(c.origin!==args.page.origin||c.path!==args.page.path)return {ok:false,code:'WRONG_PAGE'};const r=KPDOM.verifyCheck(args.verification);return r.ok?{ok:true,result:r.result}:{ok:false,code:r.error.code};}catch(e){return {ok:false,code:e.code||'DOM_ERROR'};}",{page:step.page,verification});
              if(!checked || checked.ok!==true)throw fault(checked && checked.code || 'INVALID_REPLY');
              const result=checked.result;
              if(!result || typeof result.checked!=='boolean' || typeof result.verified!=='boolean' || typeof result.pending!=='boolean')throw fault('INVALID_REPLY');
              if(result.verified===true && result.checked===step.checked && result.pending===false)break;
              if(result.verified!==false || result.pending!==true)throw fault('INVALID_REPLY');
              if(Date.now()>=verifyUntil)throw fault('CHECK_STATE_NOT_CHANGED');
              await auto.sleep(Math.min(100,verifyUntil-Date.now()));
            }
          }
          return;
        } catch (err) {
          // Do not retry clicks/fills, transport errors, ambiguous targets, or changed identities.
          if (mutationSent || !['ELEMENT_NOT_FOUND','ELEMENT_HIDDEN','ELEMENT_DISABLED','ELEMENT_OCCLUDED','WRONG_PAGE','NO_WEBVIEW','APP_NOT_ACTIVE','STALE_DOCUMENT'].includes(err.code))throw err;
          if (Date.now()>=deadline)throw fault('WAIT_TIMEOUT');
          await auto.sleep(250);
        }
      }
    }
    async function run(workflow,data,options) {
      validate(workflow);
      options=options || {};
      const rows=options.inspectOnly ? [{}] : dataRows(workflow,data);
      const runCount=options.inspectOnly ? 1 : (workflow.runCount||1);
      const inspectionIndex=workflow.steps.findIndex(s=>!s.disabled && !!s.target);
      if(options.inspectOnly && inspectionIndex<0)throw fault('NOTHING_TO_INSPECT');
      await auto.store.set('recordStatus',{stopped:true});
      const controls=workflow.version===2 && !options.inspectOnly && options.overlayControls!==false,controlId=newId();
      let overlayStarted=false,stopAfterRow=false,completed=0,skipped=0,failedRows=0,nextStart=0,currentRow=0,currentStep=0,currentRound=1;
      let terminalStatus=null;
      const saved=await auto.store.get('workflowLog');let history=Array.isArray(saved) ? saved.slice(-200).map(sanitizeLog) : [];
      async function log(entry) {history.push(sanitizeLog(Object.assign({time:Date.now(),round:currentRound},entry)));history=history.slice(-200);try{await auto.store.set('workflowLog',history);}catch(_){if(persistLog)await persistLog(history);}}
      async function failure(status) {status=Object.assign({round:currentRound,totalRounds:runCount},status);terminalStatus=status;if(persistFailure)await persistFailure(status);else try{await auto.store.set('workflowStatus',status);}catch(_){} }
      const positions=new Map(workflow.steps.map((s,i)=>[s.id,i]));
      async function startOverlay() {
        if(!controls || overlayStarted)return;
        const deadline=Date.now()+5000;
        while(true) {try{await invoke('ui.overlay.start',{bundleId:workflow.bundleId,controlId});overlayStarted=true;return;}
          catch(error){if(!['WEB_AGENT_UNAVAILABLE','APP_NOT_ACTIVE'].includes(error.code) || Date.now()>=deadline)throw error;await auto.sleep(250);}}
      }
      async function restartApp() {
        if(overlayStarted){await invoke('ui.overlay.end',{bundleId:workflow.bundleId,controlId});overlayStarted=false;}
        await auto.app.close(workflow.bundleId);await auto.app.launch(workflow.bundleId);await startOverlay();
      }
      async function nextContainer() {
        const state=await auto.crane.state(workflow.bundleId);
        if(!state || !Number.isInteger(state.count) || state.count<1 || state.count>2000 || !Number.isInteger(state.current) || state.current<1 || state.current>state.count || typeof state.hasNext!=='boolean' || state.hasNext!==(state.current<state.count) || !/^[a-f0-9]{64}$/.test(state.stateToken || ''))throw fault('INVALID_REPLY');
        if(!state.hasNext)throw fault('CRANE_AT_END');
        if(overlayStarted){await invoke('ui.overlay.end',{bundleId:workflow.bundleId,controlId});overlayStarted=false;}
        await auto.app.close(workflow.bundleId);
        let result;
        try{result=await auto.crane.next(workflow.bundleId,state.stateToken);}
        catch(error){
          // Known refusals did not switch. Restore feedback in the app, then
          // propagate the error. Uncertain results never launch another step.
          if(['CRANE_SWITCH_DENIED','CRANE_STATE_CHANGED','CRANE_AT_END','CRANE_API_UNSUPPORTED','CRANE_UNAVAILABLE','CRANE_BUSY','CRANE_APP_RUNNING'].includes(error.code))try{await auto.app.launch(workflow.bundleId);await startOverlay();}catch(_){}
          throw error;
        }
        if(!result || result.current!==state.current+1 || result.count!==state.count)throw fault('OUTCOME_UNKNOWN');
        await auto.app.launch(workflow.bundleId);await startOverlay();return result;
      }
      async function craneNumbering(step,index) {
        const snapshot=await invoke('store.snapshot',{key:'craneNumbering'});
        if(!snapshot || !Object.prototype.hasOwnProperty.call(snapshot,'value') || typeof snapshot.revision!=='string' || !/^[a-f0-9]{64}$/.test(snapshot.revision))throw fault('INVALID_REPLY');
        if(snapshot.value!==null && (!snapshot.value || typeof snapshot.value!=='object' || Array.isArray(snapshot.value)))throw fault('CRANE_NUMBERING_INVALID');
        const map=JSON.parse(JSON.stringify(snapshot.value || {})),id=step.id || 'legacy-create-'+index,startNumber=step.startNumber===undefined ? 1 : step.startNumber;
        const hasEntry=Object.prototype.hasOwnProperty.call(map,id);let entry=hasEntry ? map[id] : null;
        if(hasEntry && (!entry || typeof entry!=='object' || Array.isArray(entry) || !Number.isInteger(entry.startNumber) || entry.startNumber<0 || entry.startNumber>999999999 || !Number.isInteger(entry.nextNumber) || entry.nextNumber<entry.startNumber || entry.nextNumber>1000000000 || typeof entry.pending!=='boolean'))throw fault('CRANE_NUMBERING_INVALID');
        // A changed user configuration starts a new sequence. Reopening/running
        // the same block keeps its progress in the script Keychain, outside DATA.
        if(!entry || entry.startNumber!==startNumber)entry={startNumber,nextNumber:startNumber,pending:false};
        if(entry.pending)throw fault('CRANE_CREATE_PENDING');
        if(entry.nextNumber>999999999)throw fault('CRANE_NUMBER_LIMIT');
        return {snapshot,map,id,entry};
      }
      async function saveCraneNumbering(numbering,entry) {
        Object.defineProperty(numbering.map,numbering.id,{value:entry,writable:true,enumerable:true,configurable:true});
        const result=await invoke('store.compareSet',{key:'craneNumbering',expectedRevision:numbering.snapshot.revision,value:numbering.map});
        if(result!==true)throw fault('INVALID_REPLY');
      }
      async function finishCraneNumbering(numbering,created) {
        const snapshot=await invoke('store.snapshot',{key:'craneNumbering'});
        if(!snapshot || !snapshot.value || typeof snapshot.value!=='object' || Array.isArray(snapshot.value) || !/^[a-f0-9]{64}$/.test(snapshot.revision || ''))throw fault('CRANE_NUMBERING_INVALID');
        const map=JSON.parse(JSON.stringify(snapshot.value)),entry=Object.prototype.hasOwnProperty.call(map,numbering.id) ? map[numbering.id] : null;
        if(!entry || entry.startNumber!==numbering.entry.startNumber || entry.nextNumber!==numbering.entry.nextNumber || entry.pending!==true)throw fault('CRANE_NUMBERING_CHANGED');
        await saveCraneNumbering({snapshot,map,id:numbering.id},{startNumber:entry.startNumber,nextNumber:entry.nextNumber+(created?1:0),pending:false});
      }
      async function createContainer(step,index) {
        const numbering=await craneNumbering(step,index),containerNumber=numbering.entry.nextNumber;
        const state=await auto.crane.state(workflow.bundleId);
        if(!state || !Number.isInteger(state.count) || state.count<1 || state.count>2000 || !Number.isInteger(state.current) || state.current<1 || state.current>state.count || typeof state.hasNext!=='boolean' || state.hasNext!==(state.current<state.count) || !/^[a-f0-9]{64}$/.test(state.stateToken || ''))throw fault('INVALID_REPLY');
        if(state.count===2000)throw fault('CRANE_CONTAINER_LIMIT');
        if(overlayStarted){await invoke('ui.overlay.end',{bundleId:workflow.bundleId,controlId});overlayStarted=false;}
        const closed=await auto.app.close(workflow.bundleId);
        if(!closed || closed.closed!==true)throw fault('OUTCOME_UNKNOWN');
        // Persist the reservation before the mutation. If its outcome is lost,
        // another run cannot create the same number without an explicit edit.
        await saveCraneNumbering(numbering,{startNumber:numbering.entry.startNumber,nextNumber:containerNumber,pending:true});
        let result;
        try{result=await auto.crane.create(workflow.bundleId,state.stateToken,containerNumber);}
        catch(error){
          // Only explicit refusals prove no creation occurred. A lost reply or
          // partial create/switch must be inspected before another run.
          if(['CRANE_CREATE_DENIED','CRANE_STATE_CHANGED','CRANE_API_UNSUPPORTED','CRANE_UNAVAILABLE','CRANE_BUSY','CRANE_APP_RUNNING','CRANE_CONTAINER_LIMIT','CRANE_NAME_EXISTS'].includes(error.code)) {
            await finishCraneNumbering(numbering,false);
            try{await auto.app.launch(workflow.bundleId);await startOverlay();}catch(_){}
          }
          throw error;
        }
        // Native verifies the sole new identifier and that it became active.
        // Crane may reorder identifiers, so its index need not be the last.
        if(!result || result.created!==true || result.containerNumber!==containerNumber || result.count!==state.count+1 || !Number.isInteger(result.current) || result.current<1 || result.current>result.count || !/^[a-f0-9]{64}$/.test(result.stateToken || '') || result.stateToken===state.stateToken)throw fault('OUTCOME_UNKNOWN');
        // The number has been consumed once create+switch are confirmed, even
        // when reopening the app or starting its overlay later fails.
        await finishCraneNumbering(numbering,true);
        await auto.app.launch(workflow.bundleId);await startOverlay();return result;
      }
      await auto.store.set('workflowControl',{paused:false,stopAfterRow:false});await log({kind:'start',code:'RUN_STARTED'});
      try { for (let iteration=0;iteration<rows.length*runCount;iteration++) {
        const rowIndex=iteration%rows.length;currentRound=Math.floor(iteration/rows.length)+1;if(rowIndex===0)nextStart=0;
        currentRow=rowIndex+1;
        if(workflow.resetBeforeRow===true && !options.inspectOnly)await restartApp();else await auto.app.launch(workflow.bundleId);
        if (workflow.startURL)await auto.app.openURL(workflow.bundleId,workflow.startURL);
        await startOverlay();
        const uses=new Map();let visited=0,rowSkipped=false,rowHadError=false;
        async function heartbeat(stepIndex) {
          if(!controls)return;
          while(true) {
            const local=await auto.store.get('workflowControl');
            const remote=await invoke('ui.overlay.control',{bundleId:workflow.bundleId,controlId,row:rowIndex+1,step:stepIndex+1,total:workflow.steps.length,round:currentRound,totalRounds:runCount,action:workflow.steps[stepIndex] && workflow.steps[stepIndex].action,logs:history.slice(-16)});
            if(!remote || typeof remote.paused!=='boolean' || typeof remote.stopAfterRow!=='boolean')throw fault('INVALID_REPLY');
            stopAfterRow=stopAfterRow || remote.stopAfterRow || !!(local && local.stopAfterRow);
            if(!remote.paused && !(local && local.paused))return;
            await auto.sleep(300);
          }
        }
        function apply(effect,key,limit,index) {
          effect=effect||{action:'continue'};
          if(effect.action==='continue')return index+1;
          if(effect.action==='stop')throw fault('WORKFLOW_STOPPED');
          const used=(uses.get(key)||0)+1;uses.set(key,used);if(used>limit)throw fault('BRANCH_LIMIT');
          if(effect.action==='nextRow'){rowSkipped=true;nextStart=effect.stepId===undefined ? 0 : positions.get(effect.stepId);return workflow.steps.length;}
          return positions.get(effect.stepId);
        }
        for (let i=nextStart;i<workflow.steps.length;) {
          const step=workflow.steps[i];
          currentStep=i+1;
          if(step.disabled){i++;continue;}
          if(options.inspectOnly && i!==inspectionIndex){i++;continue;}
          if(++visited>(workflow.maxStepsPerRow||Math.min(20000,Math.max(100,workflow.steps.length*10))))throw fault('LOOP_LIMIT');
          await auto.store.set('workflowStatus',{row:rowIndex+1,step:i+1,total:workflow.steps.length,status:'running',round:currentRound,totalRounds:runCount,totalRows:rows.length});
          if(!options.inspectOnly)await log({kind:'step',row:rowIndex+1,step:i+1,stepId:step.id,action:step.action,code:'STEP_STARTED'});
          try {
            if(!options.inspectOnly && step.action==='restartApp'){await heartbeat(i);await restartApp();i++;continue;}
            if(!options.inspectOnly && step.action==='nextContainer'){
              await heartbeat(i);const result=await nextContainer();await log({kind:'step',row:rowIndex+1,step:i+1,stepId:step.id,action:step.action,code:'CONTAINER_CHANGED',containerIndex:result.current,containerTotal:result.count});i++;continue;
            }
            if(!options.inspectOnly && step.action==='createContainer'){
              await heartbeat(i);const result=await createContainer(step,i);await log({kind:'step',row:rowIndex+1,step:i+1,stepId:step.id,action:step.action,code:'CONTAINER_CREATED',containerIndex:result.current,containerTotal:result.count});i++;continue;
            }
            if(!options.inspectOnly && step.action==='resetIP'){
              await heartbeat(i);const result=await auto.network.resetAirplane(step.holdMs===undefined?3000:step.holdMs);if(!result||result.completed!==true||result.airplaneMode!==false)throw fault('OUTCOME_UNKNOWN');await log({kind:'step',row:rowIndex+1,step:i+1,stepId:step.id,action:step.action,code:'RESET_IP_COMPLETE'});i++;continue;
            }
            if(!options.inspectOnly && step.action==='nextRow'){rowSkipped=true;nextStart=0;i=workflow.steps.length;continue;}
            if(options.inspectOnly && ['restartApp','nextRow','nextContainer','createContainer','resetIP'].includes(step.action)){i++;continue;}
            const match=await act(workflow,options.inspectOnly && !['wait','condition'].includes(step.action) ? Object.assign({},step,{action:'assert'}) : step,rows[rowIndex],()=>heartbeat(i));
            if(step.action==='condition' && !options.inspectOnly) {
              const effect=match ? step.then : step.else;await log({kind:'branch',row:rowIndex+1,step:i+1,stepId:step.id,code:match?'CONDITION_TRUE':'CONDITION_FALSE',effect:effect && effect.action || 'continue'});
              i=apply(effect,step.id||String(i),step.maxUses||1,i);
            }else {if(!options.inspectOnly)await log({kind:'step',row:rowIndex+1,step:i+1,stepId:step.id,action:step.action,code:'STEP_COMPLETE'});i++;}
          }
          catch(err) {
            const code=safeCode(err.code),status={row:rowIndex+1,step:i+1,total:workflow.steps.length,status:['WORKFLOW_STOPPED','CRANE_AT_END'].includes(code)?'stopped':'failed',code};
            rowHadError=true;
            await log({kind:'error',row:rowIndex+1,step:i+1,stepId:step.id,code});
            const rule=(workflow.onError||[]).find(r=>r.code===code);
            if(!options.inspectOnly && rule && recoverableCodes.includes(code)) {
              await log({kind:'branch',row:rowIndex+1,step:i+1,stepId:step.id,code,effect:rule.effect.action});
              try{i=apply(rule.effect,'error-'+rule.code,rule.maxUses,i);}
              catch(branchError){await failure(Object.assign({},status,{code:safeCode(branchError.code),errorCode:code,status:branchError.code==='WORKFLOW_STOPPED'?'stopped':'failed'}));throw branchError;}
            } else {await failure(status);throw err;}
          }
        }
        await heartbeat(workflow.steps.length-1);
        if(rowSkipped){skipped++;if(rowHadError)failedRows++;await log({kind:'row',row:rowIndex+1,code:'ROW_SKIPPED'});}else{completed++;nextStart=0;await log({kind:'row',row:rowIndex+1,code:'ROW_COMPLETE'});}
        if(stopAfterRow){await failure({row:rowIndex+1,step:workflow.steps.length,total:workflow.steps.length,status:'stopped',code:'STOP_AFTER_ROW',completedRows:completed,skippedRows:skipped,failedRows});throw fault('WORKFLOW_STOPPED');}
      }
      terminalStatus={row:rows.length,step:options.inspectOnly ? inspectionIndex+1 : workflow.steps.length,total:workflow.steps.length,status:skipped?'partial':'success',round:runCount,totalRounds:runCount,totalRows:rows.length,completedRows:completed,skippedRows:skipped,failedRows};
      await auto.store.set('workflowStatus',terminalStatus);
      }catch(error){
        const code=safeCode(error.code);
        if(code!=='WORKFLOW_STOPPED') {
          const last=history[history.length-1];if(!last || last.kind!=='error' || last.code!==code || last.row!==currentRow || last.step!==currentStep)await log({kind:'error',row:currentRow,step:currentStep,code});
          await failure({status:code==='CRANE_AT_END'?'stopped':'failed',row:currentRow,step:currentStep,total:workflow.steps.length,code,completedRows:completed,skippedRows:skipped,failedRows});
        }
        throw error;
      }
      finally{if(overlayStarted)try{const payload=Object.assign({bundleId:workflow.bundleId,controlId,retainStatus:true,logs:history.slice(-16)},terminalStatus || {status:'stopped',code:'RUNNER_DISCONNECTED'});if(finishOverlay)await finishOverlay(payload);else await invoke('ui.overlay.end',payload);}catch(_){} }
    }
    return Object.freeze({capture:capture,run:run});
  }
  function sanitizeLog(entry) {
    entry=entry||{};const result={time:Number.isFinite(entry.time)?entry.time:0,kind:['start','error','branch','row','step'].includes(entry.kind)?entry.kind:'error',code:safeCode(entry.code)};
    if(['click','fill','select','check','wait','assert','condition','restartApp','nextRow','nextContainer','createContainer','resetIP'].includes(entry.action))result.action=entry.action;
    for(const key of ['row','step'])if(Number.isInteger(entry[key]) && entry[key]>0 && entry[key]<=2000)result[key]=entry[key];
    if(Number.isInteger(entry.round) && entry.round>0 && entry.round<=1000)result.round=entry.round;
    for(const key of ['containerIndex','containerTotal'])if(Number.isInteger(entry[key]) && entry[key]>0 && entry[key]<=2000)result[key]=entry[key];
    if(typeof entry.stepId==='string' && /^[A-Za-z0-9_-]{1,100}$/.test(entry.stepId))result.stepId=entry.stepId;
    if(['continue','goto','nextRow','stop'].includes(entry.effect))result.effect=entry.effect;return result;
  }
  const api={create:create,validate:validate,append:append,dataRows:dataRows,recoverableCodes:Object.freeze(recoverableCodes),sanitizeLog:sanitizeLog};
  if(typeof module!=='undefined' && module.exports)module.exports=api;
  else root.KPWorkflow=Object.freeze(api);
})(typeof globalThis!=='undefined' ? globalThis : this);
