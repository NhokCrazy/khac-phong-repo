/* Runs in a WKContentWorld. Records element identity, never screen coordinates or entered values. */
(function (root) {
  "use strict";
  const SHADOW_LIMIT=12;
  function error(code) { return Object.assign(new Error(code), {code:code}); }
  function clean(value, limit) { return String(value || "").replace(/\s+/g, " ").trim().slice(0, limit || 120); }
  function cleanText(value) {const raw=String(value||'');if(raw.length>8192)return '';return clean(raw.replace(/[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}/g,'[DATA]').replace(/[0-9][0-9 -]{4,}[0-9]/g,'[DATA]'),200);}
  function attribute(value) { return '"' + String(value).replace(/\\/g, "\\\\").replace(/"/g, '\\"').replace(/[\n\r\f]/g, " ") + '"'; }
  function editable(node) { return node && node.matches && (node.matches('textarea,select,[contenteditable="true"]') ||
    node.matches('input:not([type="button"]):not([type="submit"]):not([type="reset"]):not([type="checkbox"]):not([type="radio"]):not([type="hidden"]):not([type="file"])')); }
  function context(doc) {
    const loc=doc.defaultView.location,protocol=String(loc.protocol||'').toLowerCase();
    if(loc.username || loc.password)throw error("RECORD_PAGE_UNSUPPORTED");
    if(/^https?:$/.test(protocol))return {origin:loc.origin,path:loc.pathname};
    if(protocol!=='ionic:' && protocol!=='capacitor:')throw error("RECORD_PAGE_UNSUPPORTED");
    const host=String(loc.hostname||loc.host||'').toLowerCase(),rawPort=String(loc.port||'');
    if(rawPort && (!/^[0-9]{1,5}$/.test(rawPort) || Number(rawPort)<1 || Number(rawPort)>65535))throw error("RECORD_PAGE_UNSUPPORTED");
    const authority=host+(rawPort ? ':'+String(Number(rawPort)) : '');
    if(!host || host.length>253 || !host.split('.').every(part=>/^[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?$/.test(part)) ||
       String(loc.host||authority).toLowerCase()!==authority)throw error("RECORD_PAGE_UNSUPPORTED");
    return {origin:protocol+'//'+authority,path:loc.pathname||'/'};
  }
  function rootOf(node,doc) { return node && typeof node.getRootNode==='function' ? node.getRootNode() : doc; }
  function publicText(node,budget) {
    budget=budget||{count:0};if(!node || ++budget.count>256)return '';
    if(node.nodeType===3)return String(node.nodeValue||'');
    if(node.matches && node.matches('input,textarea,select,ion-input,ion-textarea,ion-select,[contenteditable="true"]'))return '';
    if(!node.childNodes)return String(node.textContent||'');
    let children=Array.from(node.childNodes);
    if(node.tagName && node.tagName.toLowerCase()==='slot' && typeof node.assignedNodes==='function')children=Array.from(node.assignedNodes({flatten:true}));
    return children.map(child=>publicText(child,budget)).join(' ');
  }
  function hostLabel(host) {
    const tag=host.tagName.toLowerCase(),named=host.getAttribute('aria-label')||host.getAttribute('title');
    if(named)return cleanText(named);
    if(host.matches && host.matches('button,[role="button"],[role="tab"],ion-button,ion-tab-button,ion-toggle,ion-checkbox,ion-radio'))return cleanText(publicText(host))||tag;
    return tag;
  }
  function nodeLabel(node,asHost) {
    if(asHost)return hostLabel(node);
    const field=editable(node);let value=node.getAttribute('aria-label') || (field ?
      (node.labels && node.labels[0] && publicText(node.labels[0])) || node.getAttribute('placeholder') || node.getAttribute('name') :
      (node.labels && node.labels[0] && publicText(node.labels[0])) || publicText(node) || node.getAttribute('title'));
    if(!value && !field){const owner=rootOf(node);if(owner && owner.host)value=hostLabel(owner.host);}
    return cleanText(value||node.tagName.toLowerCase());
  }
  function localDescriptor(node,scope,asHost) {
    if(!node || !node.tagName || !scope || typeof scope.querySelectorAll!=='function')throw error('RECORD_ELEMENT_UNSUPPORTED');
    const tag=node.tagName.toLowerCase();let selector,strategy;const candidates=[];
    ["data-testid","data-test","id","name","aria-label","placeholder"].forEach(key=>{
      const value=node.getAttribute(key);
      if(value && value.length<=160 && !/[\x00-\x1f]/.test(value) && cleanText(value)===clean(value,200))candidates.push({selector:tag+'['+key+'='+attribute(value)+']',strategy:key});
    });
    for(const candidate of candidates){const matches=scope.querySelectorAll(candidate.selector);if(matches.length===1 && matches[0]===node){selector=candidate.selector;strategy=candidate.strategy;break;}}
    if(!selector){
      const parts=[];
      for(let item=node;item && item.nodeType===1 && parts.length<12;item=item.parentElement){
        let part=item.tagName.toLowerCase();const parent=item.parentElement||scope;
        const siblings=parent.children ? Array.from(parent.children).filter(x=>x.tagName===item.tagName) : [item];
        if(siblings.length>1)part+=':nth-of-type('+(siblings.indexOf(item)+1)+')';
        parts.unshift(part);const candidate=parts.join(' > '),matches=scope.querySelectorAll(candidate);
        if(matches.length===1 && matches[0]===node){selector=candidate;strategy='structure';break;}
      }
    }
    if(!selector)throw error('RECORD_ELEMENT_UNSUPPORTED');
    return {selector:selector,tag:tag,strategy:strategy,label:nodeLabel(node,asHost)};
  }
  function describe(node,doc) {
    const scope=rootOf(node,doc),shadowPath=[];let owner=scope;
    while(owner!==doc){
      if(!owner || !owner.host || shadowPath.length>=SHADOW_LIMIT || owner.host.shadowRoot!==owner)throw error('RECORD_ELEMENT_UNSUPPORTED');
      const host=owner.host,parent=rootOf(host,doc);if(parent===owner)throw error('RECORD_ELEMENT_UNSUPPORTED');
      shadowPath.unshift(localDescriptor(host,parent,true));owner=parent;
    }
    if(node.tagName && /^ion-(button|tab-button|toggle|checkbox|radio|input|textarea)$/.test(node.tagName.toLowerCase()) && !node.shadowRoot)throw error('RECORD_ELEMENT_UNSUPPORTED');
    const local=localDescriptor(node,scope,false),field=editable(node);
    const target={kind:'web',selector:local.selector,tag:local.tag,type:clean(node.getAttribute('type'),30),label:local.label,strategy:local.strategy,
      sensitive:field && (node.type==='password' || /password|one-time-code|cc-/.test(node.autocomplete||''))};
    if(shadowPath.length)target.shadowPath=shadowPath;
    return target;
  }
  function unique(scope,selector) {
    let nodes;try{nodes=Array.from(scope.querySelectorAll(selector));}catch(_){throw error('INVALID_SELECTOR');}
    if(!nodes.length)throw error('ELEMENT_NOT_FOUND');if(nodes.length!==1)throw error('AMBIGUOUS_ELEMENT');return nodes[0];
  }
  function resolve(target,doc) {
    if(!target || target.kind!=='web' || typeof target.selector!=='string' || !target.selector)throw error('INVALID_TARGET');
    let scope=doc;
    if(target.shadowPath!==undefined){
      if(!Array.isArray(target.shadowPath) || !target.shadowPath.length || target.shadowPath.length>SHADOW_LIMIT)throw error('INVALID_TARGET');
      for(const step of target.shadowPath){
        if(!step || typeof step!=='object' || Object.keys(step).length!==4 || Object.keys(step).some(k=>!['selector','tag','strategy','label'].includes(k)) ||
           typeof step.selector!=='string' || !step.selector || step.selector.length>2048 || typeof step.tag!=='string' || !step.tag ||
           !/^[a-z][a-z0-9-]{0,63}$/.test(step.tag) || !['data-testid','data-test','id','name','aria-label','placeholder','structure'].includes(step.strategy) ||
           typeof step.label!=='string' || step.label.length>200)throw error('INVALID_TARGET');
        const host=unique(scope,step.selector);
        if(host.tagName.toLowerCase()!==step.tag || (step.strategy==='structure' && hostLabel(host)!==step.label))throw error('ELEMENT_CHANGED');
        if(!host.shadowRoot || host.shadowRoot.mode==='closed')throw error('SHADOW_ROOT_UNAVAILABLE');scope=host.shadowRoot;
      }
    }
    const node=unique(scope,target.selector);
    if(node.tagName.toLowerCase()!==target.tag || clean(node.getAttribute('type'),30)!==target.type)throw error('ELEMENT_CHANGED');
    if(target.strategy==='structure' && nodeLabel(node,false)!==target.label)throw error('ELEMENT_CHANGED');
    return node;
  }
  function create(doc,emit,options) {
    options=options||{};let stopped=false,mode=options.mode==='error'?'error':'normal';
    const handlers=[],bound=new Set(),seen=typeof WeakSet==='function'?new WeakSet():new Set(),observers=[];
    const semantic='button,a[href],[role="button"],[role="tab"],[role="checkbox"],[role="radio"],[role="switch"],input,select,textarea,[contenteditable="true"]';
    function accepting(){return !stopped && !(options.expiresAtMs && Date.now()>=options.expiresAtMs) && doc.visibilityState==='visible';}
    function capture(action,node,extra){if(!accepting())return;try{emit(Object.assign({action:action,target:describe(node,doc),page:context(doc)},extra||{}));}catch(err){emit({action:'unsupported',code:err.code||'RECORD_ELEMENT_UNSUPPORTED'});}}
    function path(event){const values=event.composedPath?event.composedPath():[event.target];return values.filter(node=>node && node.matches);}
    function control(event,fieldsOnly){for(const node of path(event)){if(fieldsOnly ? editable(node) : node.matches(semantic))return node;}const source=event.target;return !fieldsOnly && source && source.closest ? source.closest(semantic) : null;}
    function checkValue(node){if(node.matches('input[type="checkbox"],input[type="radio"]'))return !!node.checked;const value=node.getAttribute('aria-checked');return value==='true'?true:value==='false'?false:null;}
    function finalAriaCheck(node){
      let target,page;try{target=describe(node,doc);page=context(doc);}catch(err){emit({action:'unsupported',code:err.code||'RECORD_ELEMENT_UNSUPPORTED'});return;}
      const finish=()=>{if(!accepting())return;try{const now=context(doc);if(now.origin!==page.origin || now.path!==page.path || resolve(target,doc)!==node)throw error('ELEMENT_CHANGED');const checked=checkValue(node);if(typeof checked!=='boolean')throw error('RECORD_ELEMENT_UNSUPPORTED');emit({action:'check',target:target,page:page,checked:checked});}catch(err){emit({action:'unsupported',code:err.code||'RECORD_ELEMENT_UNSUPPORTED'});}};
      const win=doc.defaultView||{};
      if(typeof win.requestAnimationFrame==='function')win.requestAnimationFrame(()=>win.requestAnimationFrame(finish));
      else (win.setTimeout||setTimeout)(finish,0);
    }
    function handle(type,event){
      if(!event.isTrusted || !accepting() || seen.has(event))return;seen.add(event);scan(doc);
      const node=type==='click' && mode==='error' ? (path(event)[0]||event.target) : control(event,type==='focusin'||type==='input');if(!node)return;
      if(type==='click'){
        if(mode==='error'){
          if(editable(node) || node.querySelector && node.querySelector('input,textarea,select,ion-input,ion-textarea,ion-select,[contenteditable="true"]'))return;
          const message=node.closest && node.closest('[role="alert"]') || node,expected=cleanText(publicText(message));if(!expected)return;
          if(event.preventDefault)event.preventDefault();if(event.stopImmediatePropagation)event.stopImmediatePropagation();capture('condition',message,{test:{type:'text',operator:'contains',expected:expected}});mode='normal';return;
        }
        if(editable(node) || node.matches('input[type="checkbox"],input[type="radio"]'))return;
        if(node.matches('[role="checkbox"],[role="radio"],[role="switch"]'))finalAriaCheck(node);else capture('click',node);
      }else if(mode==='normal'){
        if(type==='change' && node.matches('input[type="checkbox"],input[type="radio"]'))capture('check',node,{checked:!!node.checked});
        else if(editable(node))capture(node.tagName==='SELECT'?'select':'fill',node);
      }
    }
    function bind(scope){
      if(bound.has(scope) || !scope.addEventListener)return;bound.add(scope);
      for(const type of ['click','focusin','input','change']){const callback=event=>handle(type,event);scope.addEventListener(type,callback,true);handlers.push([scope,type,callback]);}
      const Observer=doc.defaultView && doc.defaultView.MutationObserver;
      if(typeof Observer==='function'){const observer=new Observer(()=>scan(doc));observer.observe(scope,{childList:true,subtree:true});observers.push(observer);}
    }
    function scan(scope,depth,budget){
      depth=depth||0;budget=budget||{count:0};if(depth>SHADOW_LIMIT || !scope || !scope.querySelectorAll)return;bind(scope);
      for(const node of Array.from(scope.querySelectorAll('*'))){if(++budget.count>5000)return;if(node.shadowRoot && node.shadowRoot.mode!=='closed')scan(node.shadowRoot,depth+1,budget);}
    }
    scan(doc);
    return Object.freeze({setMode:value=>{mode=value==='error'?'error':'normal';},stop:()=>{stopped=true;handlers.forEach(x=>x[0].removeEventListener(x[1],x[2],true));observers.forEach(observer=>observer.disconnect());}});
  }
  const api={create:create,describe:describe,resolve:resolve,context:context,cleanText:cleanText};
  if(typeof module!=='undefined' && module.exports)module.exports=api;else root.KPRecorder=Object.freeze(api);
})(typeof globalThis!=='undefined' ? globalThis : this);
