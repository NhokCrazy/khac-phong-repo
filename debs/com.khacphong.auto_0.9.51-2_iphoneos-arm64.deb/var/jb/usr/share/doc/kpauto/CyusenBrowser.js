/* KP_AUTO_CONFIG
{
  "id": "cyusen-browser",
  "title": "Cyusen Browser",
  "version": "1.0.1 · Safari",
  "actions": [
    {
      "id": "run",
      "label": "CHẠY DATA"
    },
    {
      "id": "retryFailed",
      "label": "CHẠY FAILED"
    },
    {
      "id": "download",
      "label": "TẢI SHEET"
    },
    {
      "id": "reset",
      "label": "RESET IP"
    }
  ],
  "fields": [
    {
      "key": "sheetURL",
      "label": "Link Google Sheet",
      "type": "text",
      "default": "",
      "group": "Google Sheet"
    },
    {
      "key": "machineName",
      "label": "Tên máy / tab DATA",
      "type": "text",
      "default": "MAY01",
      "group": "Google Sheet"
    },
    {
      "key": "imapSource",
      "label": "Nguồn Gmail OTP",
      "type": "choice",
      "default": "sheet",
      "group": "OTP",
      "options": [
        {
          "value": "sheet",
          "label": "Sheet config!E3"
        },
        {
          "value": "manual",
          "label": "Nhập thủ công"
        }
      ]
    },
    {
      "key": "gmail",
      "label": "Gmail nhận OTP",
      "type": "text",
      "default": "",
      "group": "OTP"
    },
    {
      "key": "appPassword",
      "label": "Mật khẩu ứng dụng Gmail",
      "type": "secret",
      "default": "",
      "group": "OTP"
    },
    {
      "key": "otpDelay",
      "label": "Chờ OTP (giây)",
      "type": "number",
      "default": 7,
      "min": 1,
      "max": 60,
      "group": "OTP"
    },
    {
      "key": "pids",
      "label": "PID, phân cách bằng dấu |",
      "type": "text",
      "default": "9900000008505|9900000008512|9900000008529",
      "group": "Cyusen"
    },
    {
      "key": "loginMaxAttempts",
      "label": "Số lần thử đăng nhập",
      "type": "number",
      "default": 10,
      "min": 1,
      "max": 50,
      "group": "Cyusen"
    },
    {
      "key": "failurePauseMinutes",
      "label": "Nghỉ sau 5 FAILED (phút)",
      "type": "number",
      "default": 5,
      "min": 0,
      "max": 1440,
      "group": "Cyusen"
    },
    {
      "key": "resetEnabled",
      "label": "RESET IP giữa tài khoản",
      "type": "toggle",
      "default": true,
      "group": "RESET IP"
    },
    {
      "key": "resetMode",
      "label": "Cách RESET IP",
      "type": "choice",
      "default": "airplane",
      "group": "RESET IP",
      "options": [
        {
          "value": "airplane",
          "label": "Máy bay trực tiếp"
        },
        {
          "value": "shortcut",
          "label": "Phím tắt"
        }
      ]
    },
    {
      "key": "shortcutName",
      "label": "Tên phím tắt",
      "type": "text",
      "default": "RESET IP",
      "group": "RESET IP"
    },
    {
      "key": "discordWebhook",
      "label": "Discord webhook (tùy chọn)",
      "type": "secret",
      "default": "",
      "group": "Thông báo"
    }
  ]
}
*/
"use strict";
const cyusenDOM = (() => { const module={exports:{}};
"use strict";

// Derived from the supplied CyusenBrowser.box 1.5.26. This function must remain
// self-contained: KP Auto injects dispatch.toString() into its isolated world.
function dispatch(action, args) {
  "use strict";
  args = args || {};
  const doc = document;
  const view = doc.defaultView || window;
  const selectors = {
    email: '#login-form-email, #email, #login-form input[name="email"]',
    password: '#current-password, #password, #login-form input[name="password"]',
    login: '#form1Button, #login-form button[type="submit"], a.loginBtn',
    otp: '#authCode, input[name="authCode"], input[autocomplete="one-time-code"], input[inputmode="numeric"]',
    items: 'ul.comOrderList > li',
    form: '.mailForm form',
    radio: 'input[type="radio"]',
    agreement: 'input[type="checkbox"]',
    apply: 'a[href$="#pop01"], a.popup-modal'
  };
  function fail(code) { return { ok: false, code: code }; }
  function query(root, selector) { return Array.prototype.slice.call(root.querySelectorAll(selector)); }
  function text(node) { return String(node && (node.innerText || node.textContent) || '').replace(/\s+/g, ' ').trim(); }
  function visible(node) {
    if (!node || !node.isConnected || node.hidden || !node.getClientRects().length) return false;
    for (let current = node; current && current.nodeType === 1; current = current.parentElement) {
      const style = view.getComputedStyle(current);
      if (current.hidden || style.display === 'none' || style.visibility === 'hidden' || style.visibility === 'collapse' || style.opacity === '0') return false;
    }
    const rect = node.getBoundingClientRect();
    return rect.width > 0 && rect.height > 0;
  }
  function enabled(node) {
    return !!node && !node.disabled && node.getAttribute('aria-disabled') !== 'true' &&
      !(node.classList && node.classList.contains('disabled')) &&
      !(node.closest && node.closest('[inert], fieldset[disabled]'));
  }
  function describe(selector, root) {
    const matches = query(root || doc, selector);
    const node = matches.length === 1 ? matches[0] : null;
    return { selector: selector, count: matches.length, found: matches.length > 0,
      ambiguous: matches.length > 1, visible: visible(node), enabled: enabled(node),
      readOnly: !!(node && node.readOnly) };
  }
  function kind() {
    const path = String(location.pathname || '');
    if (/\/(?:lottery\/)?login-mfa(?:\.html|\/)?$/i.test(path)) return 'otp';
    if (/\/(?:lottery\/)?login(?:\.html|\/)?$/i.test(path)) return 'login';
    if (/\/lottery\/apply\.html$/i.test(path)) return 'lottery';
    return 'web';
  }
  function challenge() {
    // Page-owned grecaptcha globals are intentionally not consulted in this
    // isolated world. Cross-origin frame contents are never accessed.
    const frames = query(doc, 'iframe[src*="recaptcha/enterprise"], iframe[src*="recaptcha/api2"]');
    const candidates = frames.filter(function (frame) {
      return visible(frame) && /(?:\/bframe(?:[/?#]|$)|challenge)/i.test(String(frame.getAttribute('src') || '') + ' ' + String(frame.getAttribute('title') || ''));
    });
    return { manualChallenge: candidates.length > 0,
      challengeFrameCount: candidates.length,
      recaptchaPresent: frames.length > 0 || query(doc, 'script[src*="recaptcha"], script[src*="grecaptcha"]').length > 0 };
  }
  function loginError() {
    const body = text(doc.body || query(doc, 'body')[0]);
    const messages = [
      ['認証に失敗しました。もう一度操作を行ってください。', 'LOGIN_AUTH_FAILED'],
      ['メールアドレスまたはパスワードが一致しませんでした。', 'LOGIN_CREDENTIALS_REJECTED'],
      ['エラーが発生しました。時間をおいてから再度お試しください。', 'LOGIN_TEMPORARY_ERROR'],
      ['アカウントが一時的にロックされました。', 'LOGIN_TEMPORARILY_LOCKED'],
      ['reCAPTCHAの認証に失敗しました。', 'LOGIN_RECAPTCHA_FAILED'],
      ['ただいまサイトが大変混雑しています。', 'LOGIN_SITE_BUSY']
    ];
    for (let index = 0; index < messages.length; index++) {
      if (body.indexOf(messages[index][0]) >= 0) return { matched: true, code: messages[index][1] };
    }
    return { matched: false, code: '' };
  }
  function logoutURL() {
    const nodes = query(doc, '#dataForSendToInput[data-logout]');
    if (nodes.length !== 1) return '';
    try {
      const target = new view.URL(nodes[0].getAttribute('data-logout'), location.href);
      if (target.protocol !== 'https:' || target.origin !== location.origin || target.username || target.password ||
          !/logout/i.test(target.pathname)) return '';
      return target.href;
    } catch (_) { return ''; }
  }
  function inspectLogin() {
    const security = challenge();
    const email = describe(selectors.email), password = describe(selectors.password), button = describe(selectors.login);
    return { ok: true, kind: kind(), documentReady: doc.readyState === 'complete',
      email: email, password: password, button: button, security: security, loginError: loginError(),
      ready: kind() === 'login' && doc.readyState === 'complete' && !security.manualChallenge &&
        [email, password, button].every(function (item) { return item.count === 1 && item.visible && item.enabled && !item.readOnly; }) };
  }
  function otpButtonLabel(node) {
    // An input[type=submit] value is its public button label. Values from the
    // OTP field are never inspected here, and no label is returned to callers.
    return (node.tagName === 'INPUT' ? String(node.value || '') : text(node)).replace(/\s+/g, ' ').trim();
  }
  function otpFormOwner(node) { return node && (node.form || (node.closest && node.closest('form'))) || null; }
  function otpConfirmLabel(label) { return label === '認証' || label === '認証する'; }
  function otpButtons() {
    const primary = query(doc, '#certify');
    const fallback = query(doc, 'button[type="submit"], input[type="submit"], a').filter(function (node) {
      return otpButtonLabel(node).indexOf('認証') >= 0;
    });
    const inputs = query(doc, selectors.otp), inputForm = inputs.length === 1 ? otpFormOwner(inputs[0]) : null;
    const strictFallback = fallback.filter(function (candidate) {
      const candidateForm = otpFormOwner(candidate);
      return otpConfirmLabel(otpButtonLabel(candidate)) && (!inputForm || !candidateForm || inputForm === candidateForm);
    });
    return { nodes: primary.length ? primary : strictFallback, selector: primary.length ? '#certify' : null,
      primary: primary, fallback: fallback, strictFallback: strictFallback };
  }
  function inspectOTP() {
    const input = describe(selectors.otp);
    const selected = otpButtons(), buttons = selected.nodes, buttonSelector = selected.selector;
    const node = buttons.length === 1 ? buttons[0] : null;
    const inputs = query(doc, selectors.otp), inputNode = inputs.length === 1 ? inputs[0] : null;
    const inputForm = otpFormOwner(inputNode);
    // Keep broad source-label candidates available as sanitized diagnostics,
    // while only exact public action labels can become fallback click targets.
    const diagnosticCandidates = selected.primary.length ? selected.primary : selected.fallback;
    const button = { selector: buttonSelector, count: buttons.length, ambiguous: buttons.length > 1,
      visible: visible(node), enabled: enabled(node), primaryCount: selected.primary.length, fallbackCount: selected.fallback.length,
      strictFallbackCount: selected.strictFallback.length,
      visibleCount: diagnosticCandidates.filter(visible).length,
      enabledVisibleCount: diagnosticCandidates.filter(function (candidate) { return visible(candidate) && enabled(candidate); }).length,
      candidates: diagnosticCandidates.slice(0, 8).map(function (candidate) {
        const tag = String(candidate.tagName || '').toLowerCase(), type = String(candidate.getAttribute('type') || '').toLowerCase();
        const label = otpButtonLabel(candidate), candidateForm = otpFormOwner(candidate);
        const metadata = { tag: ['button', 'input', 'a'].indexOf(tag) >= 0 ? tag : 'other',
          type: ['submit', 'button', 'reset'].indexOf(type) >= 0 ? type : type ? 'other' : 'none',
          labelClass: /再送/.test(label) ? 'resend' : otpConfirmLabel(label) ? 'confirm' : 'other',
          primary: selected.primary.indexOf(candidate) >= 0, isMailAgain: candidate.getAttribute('id') === 'mailAgain',
          visible: visible(candidate), enabled: enabled(candidate), sameForm: !!inputForm && inputForm === candidateForm,
          insideForm: !!(candidate.closest && candidate.closest('form')) };
        if (!selected.primary.length && tag === 'a' && label.length <= 60 &&
            /^[\p{Script=Hiragana}\p{Script=Katakana}\p{Script=Han}ー\s「」『』【】（）()。、！？：・]{1,60}$/u.test(label)) {
          metadata.safeLabel = label;
        }
        return metadata;
      }) };
    const inputReady = kind() === 'otp' && input.count === 1 && input.visible && input.enabled && !input.readOnly;
    // Sites commonly disable confirmation until the input/change handler sees
    // a complete code. Filling must precede the enabled-button requirement.
    const buttonPresent = button.count === 1;
    const ready = inputReady && buttonPresent;
    return { ok: true, kind: kind(), input: input, button: button, resend: describe('#mailAgain'),
      inputReady: inputReady, buttonPresent: buttonPresent, ready: ready,
      submitReady: ready && button.visible && button.enabled };
  }
  function scan() {
    return query(doc, selectors.items).map(function (li, index) {
      const forms = query(li, selectors.form);
      if (!forms.length) return null;
      const radios = query(li, selectors.form + ' ' + selectors.radio);
      const agreements = query(li, selectors.form + ' ' + selectors.agreement);
      if (!radios.length || !agreements.length) return null;
      const ids = [];
      query(li, 'a[href]').forEach(function (link) {
        const match = String(link.href || link.getAttribute('href') || '').match(/\/(\d{10,14})\.html(?:[?#].*)?$/);
        if (match && ids.indexOf(match[1]) < 0) ids.push(match[1]);
      });
      const radio = radios.length === 1 ? radios[0] : null;
      const agreement = agreements.length === 1 ? agreements[0] : null;
      const links = forms.length === 1 ? query(forms[0], selectors.apply) : [];
      const body = text(li);
      const slot = body.match(/【[^】]*(?:本人認証済み|本人未認証)[^】]*】/);
      return { node: li, form: forms.length === 1 ? forms[0] : null, radio: radio, agreement: agreement,
        link: links.length === 1 ? links[0] : null,
        data: { index: index, pid: ids.length === 1 ? ids[0] : '', pids: ids,
          ambiguous: ids.length !== 1 || forms.length !== 1 || radios.length !== 1 || agreements.length !== 1 || links.length > 1,
          name: radio ? String(radio.getAttribute('aria-label') || '').slice(0, 160) : '',
          slot: slot ? slot[0] : '', completed: body.indexOf('受付完了') >= 0,
          disabled: !enabled(radio), checked: !!(radio && radio.checked),
          agreementChecked: !!(agreement && agreement.checked), hasApplyLink: links.length === 1 } };
    }).filter(Boolean);
  }
  function statuses(products, pids) {
    if (!Array.isArray(pids) || !pids.length || pids.some(function (pid, index) {
      return typeof pid !== 'string' || !/^\d{10,14}$/.test(pid) || pids.indexOf(pid) !== index;
    })) return fail('INVALID_PIDS');
    const result = pids.map(function (pid) {
      const matches = products.filter(function (product) { return product.data.pids.indexOf(pid) >= 0; });
      const ambiguous = matches.length > 1 || matches.some(function (product) { return product.data.ambiguous; });
      const product = matches.length === 1 && !ambiguous ? matches[0].data : null;
      return { pid: pid, found: matches.length > 0, ambiguous: ambiguous,
        completed: !!(product && product.completed), product: product };
    });
    return { ok: true, statuses: result,
      allCompleted: result.every(function (item) { return item.found && !item.ambiguous && item.completed; }) };
  }
  function target(pid) {
    if (typeof pid !== 'string' || !/^\d{10,14}$/.test(pid)) return { error: fail('INVALID_PID') };
    const matches = scan().filter(function (product) { return product.data.pids.indexOf(pid) >= 0; });
    if (!matches.length) return { error: fail('PID_NOT_FOUND') };
    if (matches.length !== 1 || matches[0].data.ambiguous) return { error: fail('AMBIGUOUS_PID') };
    if (matches[0].data.completed) return { error: fail('PID_ALREADY_COMPLETED') };
    return matches[0];
  }
  function mutable(node) {
    if (!visible(node)) return fail('ELEMENT_HIDDEN');
    if (!enabled(node)) return fail('ELEMENT_DISABLED');
    return null;
  }
  function click(node) {
    const error = mutable(node);
    if (error) return error;
    try { node.click(); return { ok: true, dispatched: true }; }
    catch (_) { return fail('OUTCOME_UNKNOWN'); }
  }
  function ledger() {
    const key = '__kpCyusenDOMV1';
    if (!Object.prototype.hasOwnProperty.call(doc, key)) {
      Object.defineProperty(doc, key, { value: { pending: null, attempted: Object.create(null) } });
    }
    return doc[key];
  }
  function popup() {
    const roots = query(doc, '#pop01').filter(visible);
    const buttons = query(doc, '#applyBtn').filter(visible);
    const valid = roots.length === 1 && buttons.length === 1 && roots[0].contains(buttons[0]);
    return { root: valid ? roots[0] : null, button: valid ? buttons[0] : null,
      data: { ok: true, visible: roots.length > 0 || buttons.length > 0,
        ambiguous: roots.length > 1 || buttons.length > 1 || (buttons.length > 0 && !valid),
        ready: valid && enabled(buttons[0]) } };
  }

  if (location.protocol !== 'https:' || location.hostname !== 'www.pokemoncenter-online.com') return fail('HOST_MISMATCH');
  if (action === 'inspect') return { ok: true, kind: kind(), documentReady: doc.readyState === 'complete',
    visible: doc.visibilityState === 'visible', security: challenge(), loginError: loginError(), logoutURL: logoutURL() };
  if (action === 'login.inspect') return inspectLogin();
  if (action === 'login.warmup') {
    const directions = [1, 1, -1];
    if (!Number.isInteger(args.step) || args.step < 0 || args.step > 2 || args.direction !== directions[args.step] ||
        !Number.isFinite(args.distanceRatio) || args.distanceRatio < 0.26 || args.distanceRatio > 0.34 ||
        !Number.isFinite(args.durationMilliseconds) || args.durationMilliseconds < 1050 || args.durationMilliseconds > 1350) return fail('INVALID_LOGIN_WARMUP');
    if (kind() !== 'login') return fail('WRONG_PAGE');
    if (doc.visibilityState !== 'visible') return fail('PAGE_HIDDEN');
    if (challenge().manualChallenge) return fail('MANUAL_CHALLENGE');
    const state = ledger();
    if (!state.loginWarmup) state.loginWarmup = { step: 0, running: false, completed: false, interrupted: false };
    const warmup = state.loginWarmup;
    if (warmup.completed) return { ok: true, completed: true, started: false };
    if (warmup.interrupted) return fail('LOGIN_WARMUP_INTERRUPTED');
    if (warmup.running) return fail('LOGIN_WARMUP_IN_PROGRESS');
    if (args.step !== warmup.step) return fail('LOGIN_WARMUP_SEQUENCE');
    const root = doc.scrollingElement || doc.documentElement || doc.body;
    if (!root || !Number.isFinite(view.innerHeight) || view.innerHeight <= 0 ||
        !Number.isFinite(root.scrollTop) || !Number.isFinite(root.scrollHeight) || root.scrollHeight < 0 ||
        typeof view.scrollTo !== 'function') return fail('LOGIN_WARMUP_UNSUPPORTED');
    const distance = Math.max(120, Math.round(view.innerHeight * args.distanceRatio));
    const start = root.scrollTop, maximum = Math.max(0, root.scrollHeight - view.innerHeight);
    const target = Math.max(0, Math.min(maximum, start + args.direction * distance));
    warmup.running = true;
    function interrupted() { warmup.running = false; warmup.interrupted = true; }
    function complete() { warmup.running = false; warmup.step++; warmup.completed = warmup.step === 3; }
    try {
      if (typeof view.requestAnimationFrame === 'function') {
        let startedAt = null;
        function animate(timestamp) {
          if (kind() !== 'login' || doc.visibilityState !== 'visible' || challenge().manualChallenge || !Number.isFinite(timestamp)) {
            interrupted(); return;
          }
          if (startedAt === null) startedAt = timestamp;
          const progress = Math.max(0, Math.min(1, (timestamp - startedAt) / args.durationMilliseconds));
          const eased = -(Math.cos(Math.PI * progress) - 1) / 2;
          try {
            view.scrollTo(0, start + (target - start) * eased);
            if (progress < 1) view.requestAnimationFrame(animate);
            else complete();
          } catch (_) { interrupted(); }
        }
        view.requestAnimationFrame(animate);
      } else {
        view.scrollTo({ left: 0, top: target, behavior: 'smooth' });
        complete();
      }
    } catch (_) { interrupted(); return fail('LOGIN_WARMUP_INTERRUPTED'); }
    return { ok: true, completed: false, started: true };
  }
  if (['login.input.prepare', 'login.input.append', 'login.input.end'].indexOf(action) >= 0) {
    if (args.field !== 'email' && args.field !== 'password') return fail('INVALID_LOGIN_FIELD');
    if (kind() !== 'login') return fail('WRONG_PAGE');
    if (doc.visibilityState !== 'visible') return fail('PAGE_HIDDEN');
    if (challenge().manualChallenge) return fail('MANUAL_CHALLENGE');
    const selector = selectors[args.field], found = query(doc, selector);
    if (found.length !== 1 || !visible(found[0]) || !enabled(found[0]) || found[0].readOnly) return fail('LOGIN_INPUT_NOT_READY');
    const input = found[0], owner = otpFormOwner(input), state = ledger();
    if (!state.loginInputs) state.loginInputs = Object.create(null);
    let record = state.loginInputs[args.field];
    function unchanged(value) {
      const current = query(doc, selector);
      return kind() === 'login' && doc.visibilityState === 'visible' && !challenge().manualChallenge &&
        current.length === 1 && current[0] === input && otpFormOwner(input) === owner &&
        visible(input) && enabled(input) && !input.readOnly && input.value === value;
    }
    function changed() { return fail('LOGIN_INPUT_CHANGED'); }
    const setter = view.HTMLInputElement && Object.getOwnPropertyDescriptor(view.HTMLInputElement.prototype, 'value');
    if (!setter || typeof setter.set !== 'function') return fail('LOGIN_INPUT_UNSUPPORTED');
    if (action === 'login.input.prepare') {
      record = { input: input, owner: owner, value: '', valid: false, ended: false };
      state.loginInputs[args.field] = record;
      const previous = input.value;
      try {
        input.focus();
        if (!unchanged(previous)) return changed();
        setter.set.call(input, '');
        input.dispatchEvent(new view.Event('input', { bubbles: true }));
        if (!unchanged('')) return changed();
        input.dispatchEvent(new view.Event('change', { bubbles: true }));
        if (!unchanged('')) return changed();
      } catch (_) { return fail('LOGIN_INPUT_EVENT_FAILED'); }
      record.valid = true;
      return { ok: true, prepared: true };
    }
    if (!record || !record.valid) return fail('LOGIN_INPUT_NOT_PREPARED');
    if (record.ended) return fail('LOGIN_INPUT_ALREADY_FINISHED');
    if (record.input !== input || record.owner !== owner || !unchanged(record.value)) return changed();
    if (typeof args.expected !== 'string') return fail('INVALID_LOGIN_INPUT');
    if (action === 'login.input.end') {
      if (args.expected !== record.value) return changed();
      record.valid = false; record.ended = true;
      try {
        input.dispatchEvent(new view.Event('change', { bubbles: true }));
        if (!unchanged(args.expected)) return changed();
        input.blur();
        if (!unchanged(args.expected)) return changed();
      } catch (_) { return fail('LOGIN_INPUT_EVENT_FAILED'); }
      record.valid = true;
      return { ok: true, ended: true };
    }
    if (typeof args.character !== 'string' || args.character.length !== 1 || args.expected !== record.value + args.character) return fail('INVALID_LOGIN_INPUT');
    const previous = record.value;
    record.valid = false;
    try {
      input.focus();
      if (!unchanged(previous)) return changed();
      if (typeof view.KeyboardEvent === 'function') {
        input.dispatchEvent(new view.KeyboardEvent('keydown', { bubbles: true, key: args.character }));
        if (!unchanged(previous)) return changed();
        input.dispatchEvent(new view.KeyboardEvent('keypress', { bubbles: true, key: args.character }));
      } else input.dispatchEvent(new view.Event('keydown', { bubbles: true }));
      if (!unchanged(previous)) return changed();
      if (typeof view.InputEvent === 'function') {
        input.dispatchEvent(new view.InputEvent('beforeinput', { bubbles: true, cancelable: true, data: args.character, inputType: 'insertText' }));
        if (!unchanged(previous)) return changed();
      }
      setter.set.call(input, args.expected);
      input.dispatchEvent(typeof view.InputEvent === 'function'
        ? new view.InputEvent('input', { bubbles: true, data: args.character, inputType: 'insertText' })
        : new view.Event('input', { bubbles: true }));
      if (!unchanged(args.expected)) return changed();
      input.dispatchEvent(typeof view.KeyboardEvent === 'function'
        ? new view.KeyboardEvent('keyup', { bubbles: true, key: args.character })
        : new view.Event('keyup', { bubbles: true }));
      if (!unchanged(args.expected)) return changed();
    } catch (_) { return fail('LOGIN_INPUT_EVENT_FAILED'); }
    record.value = args.expected; record.valid = true;
    return { ok: true, appended: true };
  }
  if (action === 'login.valuesMatch' || action === 'login.submit') {
    if (typeof args.email !== 'string' || !args.email || typeof args.password !== 'string' || !args.password) return fail('INVALID_LOGIN');
    const fields = [selectors.email, selectors.password, selectors.login].map(function (selector) { return query(doc, selector); });
    const nodes = fields.map(function (matches) { return matches.length === 1 ? matches[0] : null; });
    const ready = doc.visibilityState === 'visible' && inspectLogin().ready;
    const matches = ready && nodes[0].value === args.email && nodes[1].value === args.password;
    if (action === 'login.valuesMatch') return { ok: true, matches: !!matches };
    if (kind() !== 'login') return fail('WRONG_PAGE');
    if (doc.visibilityState !== 'visible') return fail('PAGE_HIDDEN');
    if (challenge().manualChallenge) return fail('MANUAL_CHALLENGE');
    if (!ready) return fail('LOGIN_FORM_NOT_READY');
    if (!matches) return fail('LOGIN_VALUES_MISMATCH');
    function formOwner(node) { return node.form || (node.closest && node.closest('form')) || null; }
    const owners = nodes.map(formOwner);
    try {
      nodes[0].blur();
      nodes[1].blur();
      nodes[2].focus();
    } catch (_) { return fail('OUTCOME_UNKNOWN'); }
    // Focus/blur may run website validation or replace a form. Resolve again
    // before dispatching; do not submit a replacement form or changed values.
    const current = [selectors.email, selectors.password, selectors.login].map(function (selector) { return query(doc, selector); });
    if (current.some(function (matches, index) {
      return matches.length !== 1 || matches[0] !== nodes[index] || formOwner(matches[0]) !== owners[index];
    }) || nodes[0].value !== args.email || nodes[1].value !== args.password) return fail('LOGIN_FORM_CHANGED');
    if (doc.visibilityState !== 'visible') return fail('PAGE_HIDDEN');
    if (challenge().manualChallenge) return fail('MANUAL_CHALLENGE');
    if (!inspectLogin().ready) return fail('LOGIN_FORM_NOT_READY');
    return click(nodes[2]);
  }
  if (action === 'otp.inspect') return inspectOTP();
  if (action === 'popup.inspect') return popup().data;
  if (action === 'lottery.scan') return { ok: true, products: scan().map(function (product) { return product.data; }) };
  if (action === 'lottery.status') {
    const result = statuses(scan(), args.pids);
    const state = ledger();
    // A verified completion releases the popup association for the next PID;
    // its submission lock remains for the lifetime of this document.
    if (result.ok && state.pending && !popup().data.visible && result.statuses.some(function (item) {
      return item.pid === state.pending.pid && item.found && !item.ambiguous && item.completed;
    })) state.pending = null;
    return result;
  }
  if (action === 'otp.fill' || action === 'otp.submit' || action === 'otp.resend') {
    if (kind() !== 'otp') return fail('WRONG_PAGE');
    if (doc.visibilityState !== 'visible') return fail('PAGE_HIDDEN');
    if (challenge().manualChallenge) return fail('MANUAL_CHALLENGE');
    const state = ledger();
    if (state.otpResendUnknown) return fail('OUTCOME_UNKNOWN');
    if (action === 'otp.resend') {
      const resend = query(doc, '#mailAgain');
      if (resend.length !== 1) return fail(resend.length ? 'AMBIGUOUS_OTP_RESEND' : 'OTP_RESEND_NOT_FOUND');
      const error = mutable(resend[0]);
      if (error) return error;
      if (state.otpResendAt && Date.now() - state.otpResendAt < 18000) return fail('OTP_RESEND_TOO_SOON');
      state.otpResendAt = Date.now();
      state.otpResendUnknown = true;
      const result = click(resend[0]);
      if (!result.ok) return result;
      state.otpSubmitted = false; state.otpPrepared = null; state.otpResendUnknown = false;
      return { ok: true, dispatched: true };
    }
    if (state.otpSubmitted) return fail('OTP_SUBMIT_ALREADY_ATTEMPTED');
    if (typeof args.code !== 'string' || !/^[0-9]{6}$/.test(args.code)) return fail('INVALID_OTP');
    const inspected = inspectOTP();
    if (!inspected.ready) return fail('OTP_FORM_NOT_READY');
    const input = query(doc, selectors.otp)[0];
    const alreadyPrepared = state.otpPrepared && state.otpPrepared.input === input &&
      state.otpPrepared.code === args.code && input.value === args.code;
    if (state.otpPrepared && !alreadyPrepared) return fail('OTP_FORM_CHANGED');
    if (action === 'otp.submit' && args.requirePrepared === true && !alreadyPrepared) return fail('OTP_NOT_PREPARED');
    if (!alreadyPrepared) {
      const setter = view.HTMLInputElement && Object.getOwnPropertyDescriptor(view.HTMLInputElement.prototype, 'value');
      if (!setter || typeof setter.set !== 'function') return fail('OTP_INPUT_UNSUPPORTED');
      try {
        setter.set.call(input, args.code);
        input.dispatchEvent(new view.Event('input', { bubbles: true }));
        input.dispatchEvent(new view.Event('change', { bubbles: true }));
        const current = query(doc, selectors.otp);
        if (current.length !== 1 || current[0] !== input || input.value !== args.code || !visible(input) || !enabled(input) || input.readOnly) return fail('OTP_FORM_CHANGED');
        input.scrollIntoView({ block: 'center', behavior: 'smooth' });
        input.focus();
      } catch (_) { return fail('OTP_FILL_FAILED'); }
    }
    const inputs = query(doc, selectors.otp), buttons = otpButtons().nodes;
    if (inputs.length !== 1 || inputs[0] !== input || input.value !== args.code || !visible(input) || !enabled(input) ||
        input.readOnly || buttons.length !== 1) return fail('OTP_FORM_CHANGED');
    state.otpPrepared = { input: input, code: args.code };
    if (action === 'otp.fill') return { ok: true, filled: true, changed: !alreadyPrepared };
    if (mutable(buttons[0])) return fail('OTP_CONFIRM_NOT_READY');
    state.otpSubmitted = true;
    return click(buttons[0]);
  }
  if (['lottery.expand', 'lottery.select', 'lottery.agree', 'lottery.open', 'lottery.confirm'].indexOf(action) < 0) return fail('UNSUPPORTED_ACTION');
  if (kind() !== 'lottery') return fail('WRONG_PAGE');
  if (doc.visibilityState !== 'visible') return fail('PAGE_HIDDEN');
  if (challenge().manualChallenge) return fail('MANUAL_CHALLENGE');
  const state = ledger();
  if (state.attempted[args.pid]) return fail('FINAL_SUBMIT_ALREADY_ATTEMPTED');
  const item = target(args.pid);
  if (item.error) return item.error;

  if (action === 'lottery.expand') {
    const contents = query(item.node, 'dl.subDl > dd');
    if (contents.length !== 1) return fail('AMBIGUOUS_DETAILS');
    if (view.getComputedStyle(contents[0]).display !== 'none') return { ok: true, changed: false };
    const toggles = query(item.node, 'dl.subDl > dt');
    if (toggles.length !== 1) return fail('AMBIGUOUS_DETAILS');
    return click(toggles[0]);
  }
  if (action === 'lottery.select' || action === 'lottery.agree') {
    if (state.pending) return fail('POPUP_PENDING');
    if (action === 'lottery.agree' && !item.radio.checked) return fail('PRODUCT_NOT_SELECTED');
    const input = action === 'lottery.select' ? item.radio : item.agreement;
    const error = mutable(input);
    if (error) return error;
    if (input.checked) return { ok: true, changed: false, checked: true };
    const result = click(input);
    if (!result.ok) return result;
    return input.checked ? { ok: true, changed: true, checked: true } : fail('CHECK_NOT_CONFIRMED');
  }
  if (typeof args.operationId !== 'string' || !/^[A-Za-z0-9_-]{8,80}$/.test(args.operationId)) return fail('INVALID_OPERATION_ID');
  if (!item.radio.checked || !item.agreement.checked) return fail('PRODUCT_NOT_PREPARED');
  if (action === 'lottery.open') {
    if (state.pending || popup().data.visible) return fail('POPUP_PENDING');
    const error = mutable(item.link);
    if (error) return error;
    state.pending = { pid: args.pid, operationId: args.operationId, node: item.node };
    return click(item.link);
  }
  if (!state.pending || state.pending.pid !== args.pid || state.pending.operationId !== args.operationId || state.pending.node !== item.node) return fail('POPUP_TARGET_MISMATCH');
  const confirmation = popup();
  if (confirmation.data.ambiguous) return fail('AMBIGUOUS_POPUP');
  if (!confirmation.data.ready) return fail('POPUP_NOT_READY');
  // Set before dispatch: an exception can occur after the website received the
  // click. The outer runner must preserve this lock across navigation/restarts.
  state.attempted[args.pid] = true;
  const result = click(confirmation.button);
  if (!result.ok) return result;
  return { ok: true, submitted: true, outcome: 'unconfirmed', pid: args.pid };
}

if (typeof module !== 'undefined' && module.exports) module.exports = dispatch;

return module.exports; })();
const cyusenOTP = (() => { const module={exports:{}};
"use strict";

// Gmail MIME rules ported from the supplied CyusenBrowser.box 1.5.26, with a
// mandatory pre-login UIDNEXT/UIDVALIDITY baseline. No Node/browser decoders.
// Keep this function self-contained so it can be embedded in JavaScriptCore.
function selectOTP(messages, rules) {
  "use strict";
  function error(code) { const value = new Error(code); value.code = code; return value; }
  function uid(value) {
    if (typeof value !== 'number' && typeof value !== 'string') return null;
    if (!/^[1-9][0-9]{0,9}$/.test(String(value))) return null;
    const number = Number(value);
    return Number.isInteger(number) && number <= 4294967295 ? number : null;
  }
  rules = rules || {};
  const expectedValidity = uid(rules.uidValidity), actualValidity = uid(rules.actualUIDValidity);
  if (expectedValidity === null || actualValidity === null) throw error('UIDVALIDITY_REQUIRED');
  if (expectedValidity !== actualValidity) throw error('UIDVALIDITY_CHANGED');
  const floor = uid(rules.minUID);
  if (floor === null || typeof rules.notBefore !== 'number' || !Number.isFinite(rules.notBefore) || rules.notBefore <= 0) throw error('INVALID_OTP_BASELINE');
  const recipient = String(rules.recipient || '').trim().toLowerCase();
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(recipient) || typeof rules.subject !== 'string' || !rules.subject ||
      typeof rules.senderPattern !== 'string' || !rules.senderPattern) throw error('INVALID_OTP_RULES');
  let sender;
  try { sender = new RegExp(rules.senderPattern, 'i'); } catch (_) { throw error('INVALID_OTP_RULES'); }
  if (!Array.isArray(messages)) throw error('INVALID_OTP_MESSAGES');
  const now = Date.now();

  function invalid() { throw error('INVALID_MIME'); }
  function bytes(value) {
    if (typeof value !== 'string') invalid();
    const output = [];
    for (let index = 0; index < value.length; index++) {
      const character = value.charCodeAt(index);
      if (character > 255) invalid();
      output.push(character);
    }
    return output;
  }
  function unicode(input, charset) {
    const encoding = String(charset || 'utf-8').trim().toLowerCase();
    if (encoding !== 'utf-8' && encoding !== 'utf8' && encoding !== 'us-ascii' && encoding !== 'ascii') invalid();
    const ascii = encoding === 'us-ascii' || encoding === 'ascii';
    let output = '';
    for (let index = 0; index < input.length; index++) {
      const first = input[index];
      if (first < 128) { output += String.fromCharCode(first); continue; }
      if (ascii) invalid();
      let count, value, minimum;
      if (first >= 194 && first <= 223) { count = 1; value = first & 31; minimum = 128; }
      else if (first >= 224 && first <= 239) { count = 2; value = first & 15; minimum = 2048; }
      else if (first >= 240 && first <= 244) { count = 3; value = first & 7; minimum = 65536; }
      else invalid();
      if (index + count >= input.length) invalid();
      for (let offset = 0; offset < count; offset++) {
        const next = input[++index];
        if ((next & 192) !== 128) invalid();
        value = (value << 6) | (next & 63);
      }
      if (value < minimum || value > 1114111 || (value >= 55296 && value <= 57343)) invalid();
      if (value <= 65535) output += String.fromCharCode(value);
      else { value -= 65536; output += String.fromCharCode(55296 + (value >> 10), 56320 + (value & 1023)); }
    }
    return output;
  }
  function base64(value) {
    const compact = String(value || '').replace(/[\r\n\t ]/g, '');
    if (!/^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/.test(compact)) invalid();
    const alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
    const result = [];
    for (let index = 0; index < compact.length; index += 4) {
      const a = alphabet.indexOf(compact[index]), b = alphabet.indexOf(compact[index + 1]);
      const c = compact[index + 2] === '=' ? 0 : alphabet.indexOf(compact[index + 2]);
      const d = compact[index + 3] === '=' ? 0 : alphabet.indexOf(compact[index + 3]);
      if (compact[index + 2] === '=' && (b & 15)) invalid();
      if (compact[index + 3] === '=' && compact[index + 2] !== '=' && (c & 3)) invalid();
      result.push((a << 2) | (b >> 4));
      if (compact[index + 2] !== '=') result.push(((b & 15) << 4) | (c >> 2));
      if (compact[index + 3] !== '=') result.push(((c & 3) << 6) | d);
    }
    return result;
  }
  function quotedPrintable(value, header) {
    const source = String(value || '').replace(header ? /_/g : /$^/g, ' ').replace(/=\r?\n/g, '');
    const output = [];
    for (let index = 0; index < source.length; index++) {
      if (source[index] === '=') {
        const hex = source.slice(index + 1, index + 3);
        if (!/^[0-9a-f]{2}$/i.test(hex)) invalid();
        output.push(parseInt(hex, 16)); index += 2;
      } else {
        const character = source.charCodeAt(index);
        if (character > 255) invalid();
        output.push(character);
      }
    }
    return output;
  }
  function decodeHeader(value) {
    const compact = String(value || '').replace(/(\?=)[ \t]+(?==\?)/g, '$1');
    const pattern = /=\?([^?]+)\?([bq])\?([^?]*)\?=/gi;
    let output = '', position = 0, match;
    while ((match = pattern.exec(compact))) {
      const prefix = compact.slice(position, match.index);
      if (prefix.indexOf('=?') >= 0) invalid();
      output += unicode(bytes(prefix), 'utf-8');
      output += unicode(match[2].toLowerCase() === 'b' ? base64(match[3]) : quotedPrintable(match[3], true), match[1]);
      position = pattern.lastIndex;
    }
    const tail = compact.slice(position);
    if (tail.indexOf('=?') >= 0) invalid();
    return output + unicode(bytes(tail), 'utf-8');
  }
  function split(raw) {
    const separator = /\r?\n\r?\n/.exec(raw);
    if (!separator) invalid();
    return { headers: raw.slice(0, separator.index), body: raw.slice(separator.index + separator[0].length) };
  }
  function headers(raw) {
    if (raw.length > 65536 || /\r(?!\n)|\0/.test(raw)) invalid();
    const result = Object.create(null);
    raw.replace(/\r?\n[ \t]+/g, ' ').split(/\r?\n/).forEach(function (line) {
      const colon = line.indexOf(':');
      if (colon <= 0) invalid();
      const key = line.slice(0, colon).trim().toLowerCase();
      if (!/^[a-z0-9-]+$/.test(key)) invalid();
      const value = line.slice(colon + 1).trim();
      if (result[key] && ['subject', 'from', 'date', 'content-type', 'content-transfer-encoding'].indexOf(key) >= 0) invalid();
      result[key] = result[key] ? result[key] + ', ' + value : value;
    });
    return result;
  }
  function addresses(value) {
    // Exclude display names/comments so an address mentioned there cannot be
    // mistaken for an actual mailbox. Preserve the source's recipient headers.
    const decoded = decodeHeader(value).replace(/\([^()]*\)/g, '');
    const parts = decoded.match(/(?:"(?:\\.|[^"\\])*"|[^,])+/g) || [];
    const output = [];
    parts.forEach(function (part) {
      const brackets = part.match(/<([^<>]*)>/g);
      const addressText = brackets ? brackets.join(' ') : part.replace(/"(?:\\.|[^"\\])*"/g, '');
      const found = addressText.toLowerCase().match(/[a-z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-z0-9.-]+/g) || [];
      found.forEach(function (address) { if (output.indexOf(address) < 0) output.push(address); });
    });
    return output;
  }
  function internalDate(value) {
    if (typeof value === 'number') return Number.isFinite(value) ? value : NaN;
    if (typeof value !== 'string') return NaN;
    const match = value.trim().replace(/^"|"$/g, '').match(/^(\d{1,2})-([a-z]{3})-(\d{4}) (\d{2}):(\d{2}):(\d{2}) ([+-])(\d{2})(\d{2})$/i);
    if (!match) return NaN;
    const month = ['jan','feb','mar','apr','may','jun','jul','aug','sep','oct','nov','dec'].indexOf(match[2].toLowerCase());
    const day = Number(match[1]), year = Number(match[3]), hour = Number(match[4]), minute = Number(match[5]), second = Number(match[6]);
    if (month < 0 || day < 1 || day > 31 || hour > 23 || minute > 59 || second > 59 || Number(match[8]) > 23 || Number(match[9]) > 59) return NaN;
    const utc = Date.UTC(year, month, day, hour, minute, second);
    if (new Date(utc).getUTCDate() !== day) return NaN;
    return utc - (match[7] === '+' ? 1 : -1) * (Number(match[8]) * 60 + Number(match[9])) * 60000;
  }
  function fresh(value) { return Number.isFinite(value) && value >= rules.notBefore && value <= now + 300000; }
  function parameter(value, name) {
    const match = String(value || '').match(new RegExp('(?:^|;)\\s*' + name + '\\s*=\\s*(?:"((?:\\\\.|[^"\\\\])*)"|([^;\\s]+))', 'i'));
    return match ? (match[1] === undefined ? match[2] : match[1].replace(/\\(.)/g, '$1')) : '';
  }
  let partCount = 0;
  function mime(raw, depth) {
    if (depth > 8 || ++partCount > 128) invalid();
    const content = split(raw), fields = headers(content.headers);
    const type = String(fields['content-type'] || 'text/plain').split(';')[0].trim().toLowerCase();
    if (/^attachment(?:;|$)/i.test(fields['content-disposition'] || '')) return [];
    if (type.indexOf('multipart/') === 0) {
      const boundary = parameter(fields['content-type'], 'boundary');
      if (!boundary || boundary.length > 70 || /[\r\n]/.test(boundary)) invalid();
      const encoding = String(fields['content-transfer-encoding'] || '').toLowerCase();
      if (encoding && ['7bit', '8bit', 'binary'].indexOf(encoding) < 0) invalid();
      const result = [], lines = content.body.split(/\r?\n/);
      let active = false, closed = false, buffer = [];
      for (let index = 0; index < lines.length; index++) {
        const line = lines[index].replace(/[ \t]+$/, '');
        if (line === '--' + boundary || line === '--' + boundary + '--') {
          if (active) result.push.apply(result, mime(buffer.join('\r\n'), depth + 1));
          buffer = []; active = true;
          if (line === '--' + boundary + '--') { closed = true; break; }
        } else if (active) buffer.push(lines[index]);
      }
      if (!closed) invalid();
      return result;
    }
    // A forwarded attached message is not the source OTP message.
    if (type !== 'text/plain' && type !== 'text/html') return [];
    const encoding = String(fields['content-transfer-encoding'] || '').trim().toLowerCase();
    let body;
    if (encoding === 'base64') body = base64(content.body);
    else if (encoding === 'quoted-printable') body = quotedPrintable(content.body, false);
    else if (encoding === '' || encoding === '7bit' || encoding === '8bit' || encoding === 'binary') body = bytes(content.body);
    else invalid();
    return [unicode(body, parameter(fields['content-type'], 'charset') || 'utf-8')];
  }
  function htmlText(value) {
    return value.replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi, ' ')
      .replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi, ' ').replace(/<!--[\s\S]*?-->/g, ' ')
      .replace(/<[^>]+>/g, ' ').replace(/&#(x[0-9a-f]+|[0-9]+);/gi, function (_, number) {
        const code = number[0].toLowerCase() === 'x' ? parseInt(number.slice(1), 16) : parseInt(number, 10);
        return code > 0 && code <= 65535 && (code < 55296 || code > 57343) ? String.fromCharCode(code) : ' ';
      }).replace(/&(nbsp|lbrack|rbrack|amp|lt|gt|quot|apos);/gi, function (_, entity) {
        return { nbsp: ' ', lbrack: '[', rbrack: ']', amp: '&', lt: '<', gt: '>', quot: '"', apos: "'" }[entity.toLowerCase()];
      }).replace(/\s+/g, ' ').trim();
  }
  function code(parts) {
    const codes = [];
    parts.forEach(function (part) {
      const body = htmlText(part);
      const patterns = [/[\[【]\s*パスコード\s*[\]】][^0-9]{0,32}([0-9]{6})(?![0-9])/g, /パスコード[^0-9]{0,48}([0-9]{6})(?![0-9])/g];
      patterns.forEach(function (pattern) {
        let match;
        while ((match = pattern.exec(body))) if (codes.indexOf(match[1]) < 0) codes.push(match[1]);
      });
    });
    return codes.length === 1 ? codes[0] : null;
  }

  const seen = Object.create(null), candidates = [];
  for (let index = 0; index < messages.length; index++) {
    const message = messages[index];
    if (!message || uid(message.uid) === null || uid(message.uid) < floor) continue;
    const number = uid(message.uid);
    if (typeof message.raw !== 'string' || message.raw.length > 2097152) continue;
    if (seen[number]) {
      if (seen[number].raw !== message.raw || seen[number].internalDate !== message.internalDate) return null;
      continue;
    }
    seen[number] = message;
    candidates.push({ uid: number, raw: message.raw, internalDate: message.internalDate });
  }
  candidates.sort(function (left, right) { return right.uid - left.uid; });
  for (let index = 0; index < candidates.length; index++) {
    const message = candidates[index];
    let fields;
    try {
      fields = headers(split(message.raw).headers);
      const subject = decodeHeader(fields.subject || '').replace(/\s+/g, ' ').trim();
      if (subject !== rules.subject) continue;
      const from = addresses(fields.from || '');
      if (from.length !== 1 || !sender.test(from[0])) continue;
      const recipientFields = ['to', 'x-original-to', 'x-forwarded-to', 'envelope-to', 'x-envelope-to', 'delivered-to', 'apparently-to', 'resent-to'];
      const matched = recipientFields.some(function (name) { return addresses(fields[name] || '').indexOf(recipient) >= 0; });
      if (!matched) continue;
      const received = message.internalDate === undefined || message.internalDate === null ? null : internalDate(message.internalDate);
      const sent = fields.date ? Date.parse(decodeHeader(fields.date)) : null;
      if ((received !== null && !fresh(received)) || (sent !== null && !fresh(sent)) || (received === null && sent === null)) continue;
    } catch (_) { continue; }
    // Once the newest exact-source, exact-account fresh message qualifies,
    // malformed or ambiguous content cannot cause fallback to an older OTP.
    try {
      partCount = 0;
      const result = code(mime(message.raw, 0));
      return result ? { uid: message.uid, code: result } : null;
    } catch (_) { return null; }
  }
  return null;
}

if (typeof module !== 'undefined' && module.exports) module.exports = selectOTP;

return module.exports; })();
const createCyusen = (() => { const module={exports:{}};
"use strict";

// Pure orchestration; device services are supplied by KP Auto, tests use fixtures.
function createCyusen(auto, domDispatch, selectOTP, options) {
  options = options || {};
  const now = options.now || (() => Date.now());
  const safari = 'com.apple.mobilesafari';
  const host = 'https://www.pokemoncenter-online.com';
  const defaults = {sheetURL:'',machineName:'MAY01',gmail:'',appPassword:'',imapSource:'sheet',
    pids:'9900000008505|9900000008512|9900000008529',otpDelay:7,loginMaxAttempts:10,
    failurePauseMinutes:5,resetEnabled:true,resetMode:'airplane',shortcutName:'RESET IP',discordWebhook:''};
  let config, page, deadline=Infinity, deadlineCode='ACCOUNT_TIMEOUT', done=0, failed=0, current=0, total=0;
  function fail(code) { const error=new Error(code); error.code=code; throw error; }
  function code(error) { return error && error.code || 'SCRIPT_ERROR'; }
  function accounts(text) {
    if (text === null || text === undefined || text === '') return [];
    if (typeof text !== 'string') fail('DATA_INVALID');
    const result=new Set();
    text.split(/\r?\n/).forEach(line => {
      if(!line.trim()) return;
      const split=line.indexOf('|');
      if(split<1 || !/^[^\s@|]+@[^\s@|]+\.[^\s@|]+$/.test(line.slice(0,split)) || !line.slice(split+1)) fail('DATA_INVALID');
      result.add(line);
    });
    return [...result];
  }
  function csv(text) {
    if(typeof text!=='string' || /^\s*</.test(text)) fail('SHEET_INVALID');
    text=text.replace(/^\uFEFF/,'');
    let result=[],row=[],cell='',quote=false;
    for(let i=0;i<text.length;i++) {
      const c=text[i];
      if(c==='"') { if(quote&&text[i+1]==='"'){cell+='"';i++;} else quote=!quote; }
      else if(c===','&&!quote){row.push(cell);cell='';}
      else if(c==='\n'&&!quote){row.push(cell.replace(/\r$/,''));result.push(row);row=[];cell='';}
      else cell+=c;
    }
    if(quote) fail('SHEET_INVALID');
    if(cell||row.length){row.push(cell.replace(/\r$/,''));result.push(row);}
    return result;
  }
  function sheetURL(tab,range) {
    const match=String(config.sheetURL).match(/^https:\/\/docs\.google\.com\/spreadsheets\/d\/([a-zA-Z0-9_-]+)(?:\/|$)/);
    if(!match) fail('SHEET_URL_INVALID');
    return 'https://docs.google.com/spreadsheets/d/'+match[1]+'/gviz/tq?tqx=out%3Acsv&sheet='+encodeURIComponent(tab)+'&range='+encodeURIComponent(range)+'&headers=0';
  }
  async function getSheet(tab,range) {
    const reply=await auto.network.request({url:sheetURL(tab,range),method:'GET',timeoutMs:30000});
    if(reply.status!==200) fail('SHEET_READ_FAILED');
    return csv(reply.body);
  }
  async function bucket(key) { return accounts(await auto.store.get(key)); }
  async function save(key,values) { await auto.store.set(key,values.join('\n')); }
  async function remove(key,line) { await save(key,(await bucket(key)).filter(value=>value!==line)); }
  async function add(key,line) { const values=await bucket(key); if(values.indexOf(line)<0) {values.push(line);await save(key,values);} }
  async function progress(value) { await auto.progress.update({code:value,current:current,total:total,done:done,failed:failed}); }
  function remaining() { const ms=deadline-now(); if(ms<=0) fail(deadlineCode); return ms; }
  async function sleep(ms) { await auto.sleep(Math.min(ms,remaining())); remaining(); }
  async function stopping() { return !!(await auto.run.control()).stopRequested; }
  async function attach() {
    const views=await auto.web.list(safari);
    const visible=views.filter(v=>v.visible);
    if(visible.length!==1) fail(visible.length?'AMBIGUOUS_WEBVIEW':'NO_WEBVIEW');
    page=await auto.web.attach({bundleId:safari,webViewId:visible[0].webViewId});
    return page;
  }
  async function read(action,args) {
    const retry=['STALE_DOCUMENT','WEBVIEW_GONE','WEB_AGENT_UNAVAILABLE','NO_WEBVIEW','WEBVIEW_NOT_VISIBLE','WEB_DOCUMENT_NOT_VISIBLE','WEB_EXECUTION_FAILED','HOST_MISMATCH'];
    for(let count=0;count<12;count++) {
      remaining();
      try { if(!page) await attach(); return await evaluate(action,args); }
      catch(error){if(retry.indexOf(code(error))<0)throw error;page=null;await sleep(400);}
    }
    fail('PAGE_NOT_READY');
  }
  async function evaluate(action,args) {
    remaining();
    const result=await page.evaluate('return ('+domDispatch.toString()+')(args.action,args.value);',{action:action,value:args||{}});
    remaining();
    if(!result || result.ok!==true) fail(result&&result.code || 'DOM_INVALID');
    return result;
  }
  async function navigate(path) { await auto.app.openURL(safari,host+path); page=null; await sleep(800); }
  async function type(field,value) {
    await evaluate('login.input.prepare',{field:field});
    for(let i=0;i<value.length;i++) {
      remaining();
      if(i>0)await sleep(180+Math.floor(Math.random()*161));
      await evaluate('login.input.append',{field:field,character:value.charAt(i),expected:value.slice(0,i+1)});
    }
    await evaluate('login.input.end',{field:field,expected:value});
  }
  async function loginWarmup() {
    const directions=[1,1,-1];
    for(let step=0;step<3;step++) {
      const durationMilliseconds=1050+Math.floor(Math.random()*301);
      const value={step:step,direction:directions[step],distanceRatio:0.26+Math.random()*0.08,durationMilliseconds:durationMilliseconds};
      let result;
      while(true) {
        try {result=await evaluate('login.warmup',value);break;}
        catch(error){if(code(error)!=='LOGIN_WARMUP_IN_PROGRESS')throw error;await sleep(100);}
      }
      if(result.completed===true)return;
      if(result.started!==true)fail('DOM_INVALID');
      await sleep(durationMilliseconds+300);
    }
  }
  async function loginSecurityReady() {
    const until=Math.min(deadline,now()+12000);
    while(true) {
      remaining();
      if(!page || typeof page.loginSecurity!=='function')fail('RUNTIME_MISSING');
      let security;
      try {security=await page.loginSecurity();}
      catch(error){
        if(['STALE_DOCUMENT','HOST_MISMATCH','WRONG_PAGE','WEBVIEW_GONE'].indexOf(code(error))<0)throw error;
        page=null;await sleep(400);return false;
      }
      remaining();
      if(!security || typeof security.ready!=='boolean')fail('INVALID_REPLY');
      if(security.ready===true && security.sdkReady!==false)return true;
      if(now()>=until)fail('LOGIN_SECURITY_NOT_READY');
      await sleep(Math.min(500,until-now()));
    }
  }
  async function cleanup() {
    deadline=now()+45000;deadlineCode='CLEANUP_TIMEOUT';
    await progress('CLEANUP');
    if(page) {
      try {
        const state=await read('inspect');
        if(state.logoutURL){await auto.app.openURL(safari,state.logoutURL);page=null;await sleep(700);}
      } catch(error) {if(['OUTCOME_UNKNOWN','NATIVE_TIMEOUT','STOPPED'].indexOf(code(error))>=0)throw error;}
    }
    // Every run begins and ends with this same domain-scoped session cleanup.
    await navigate('/login/');
    let reply;
    for(let attempt=0;attempt<3;attempt++) {
      while((await read('inspect')).documentReady!==true)await sleep(500);
      try {reply=await page.clearData('pokemoncenter-online.com');break;}
      catch(error){if(code(error)!=='STALE_DOCUMENT')throw error;page=null;}
    }
    if(!reply || reply.cleared!==true) fail('CLEANUP_NOT_CONFIRMED');
    await auto.app.close(safari);page=null;deadline=Infinity;
  }
  async function resetIP() {
    if(!config.resetEnabled)return;
    await progress('RESET_IP');
    if(config.resetMode==='airplane') {
      const reply=await auto.network.resetAirplane(3000);
      if(!reply || reply.completed!==true || reply.airplaneMode!==false)fail('AIRPLANE_RESET_FAILED');
      await auto.sleep(5000);
    } else {
      const reply=await auto.shortcuts.run(config.shortcutName,120000);
      if(!reply || reply.completed!==true) fail('SHORTCUT_NOT_COMPLETED');
    }
  }
  async function authenticate(account) {
    await progress('LOGIN');
    let notBefore=now();
    const credentials={gmail:config.gmail,appPassword:config.appPassword,timeoutMs:Math.min(30000,remaining())};
    let baseline=await auto.imap.baseline(credentials);
    let submittedAt=0,attempts=0,otpAt=0,otpSubmitted=false,resends=0,lastLookup=0,loginUncertain=false;
    await navigate('/login/');
    while(true) {
      try {
      const state=await read('inspect');
      if(state.kind==='otp' || state.kind==='lottery')loginUncertain=false;
      if(state.kind==='login' && state.loginError && state.loginError.matched===true)loginUncertain=false;
      if(state.security.manualChallenge) {await progress('WAITING');await sleep(500);continue;}
      if(state.kind==='lottery')return;
      if(state.kind==='web' && otpSubmitted) {await navigate('/lottery/apply.html');continue;}
      if(state.kind==='login') {
        // A failed bridge response does not prove the click failed. Only an
        // explicit site rejection may unlock another login attempt here.
        if(loginUncertain){await progress('WAITING');await sleep(700);continue;}
        if(submittedAt && now()-submittedAt<12000){await sleep(700);continue;}
        if(attempts>=config.loginMaxAttempts)fail('LOGIN_FAILED');
        let fields=await read('login.inspect');
        if(!fields.ready){await sleep(600);continue;}
        if(attempts) {notBefore=now();baseline=await auto.imap.baseline(Object.assign({},credentials,{timeoutMs:Math.min(30000,remaining())}));}
        otpAt=0;otpSubmitted=false;resends=0;lastLookup=0;
        let reuseValues=false;
        if(attempts)reuseValues=(await read('login.valuesMatch',{email:account.email,password:account.password})).matches===true;
        if(!reuseValues) {
          // A retry may have navigated while checking values. Resolve the
          // explicit login form again before entering credentials there.
          fields=await read('login.inspect');
          if(!fields.ready){await sleep(600);continue;}
          await loginWarmup();
          await type('email',account.email); await type('password',account.password);
          await sleep(5000);
        }
        if(!(await loginSecurityReady()))continue;
        remaining();
        submittedAt=now();attempts++;
        try{await evaluate('login.submit',{email:account.email,password:account.password});}
        catch(e){if(code(e)!=='WEB_EXECUTION_FAILED')throw e;loginUncertain=true;}
        page=null;await sleep(1000);continue;
      }
      if(state.kind==='otp') {
        if(!otpAt)otpAt=now();
        if(otpSubmitted && now()-otpAt<18000){await sleep(600);continue;}
        if(now()-otpAt>=18000) {
          const fields=await read('otp.inspect');
          if(resends>=3)fail('OTP_NOT_ACCEPTED');
          if(fields.resend && fields.resend.count===1 && fields.resend.visible && fields.resend.enabled) {
            notBefore=now();baseline=await auto.imap.baseline(Object.assign({},credentials,{timeoutMs:Math.min(30000,remaining())}));
            await evaluate('otp.resend');otpAt=now();otpSubmitted=false;resends++;lastLookup=0;continue;
          }
          if(otpSubmitted){await sleep(700);continue;}
        }
        await progress('OTP_WAIT');
        if(now()-otpAt<config.otpDelay*1000){await sleep(500);continue;}
        if(now()-lastLookup<3500){await sleep(500);continue;}
        lastLookup=now();
        const received=await auto.imap.messages(Object.assign({},credentials,{timeoutMs:Math.min(30000,remaining()),
          uidValidity:baseline.uidValidity,minUID:baseline.uidNext,notBefore:notBefore}));
        const match=selectOTP(received.messages,{recipient:account.email,
          senderPattern:'^info_at_pokemoncenter-online_com_[a-z0-9_]+@icloud\\.com$',
          subject:'[ポケモンセンターオンライン]ログイン用パスコードのお知らせ',notBefore:notBefore,
          minUID:baseline.uidNext,uidValidity:baseline.uidValidity,actualUIDValidity:received.uidValidity});
        if(!match){await sleep(3500);continue;}
        // Keep this exact fresh mail selection while the form settles. Do not
        // fetch another code or reset the account deadline during readiness.
        while(true) {
          const fields=await read('otp.inspect');
          if(fields.inputReady===true && fields.buttonPresent===true)break;
          await sleep(400);
        }
        await evaluate('otp.fill',{code:match.code});
        // Once filled, remain pinned to this document. A navigation/stale
        // target must fail instead of attaching elsewhere and reusing the OTP.
        while(true) {
          const fields=await evaluate('otp.inspect');
          if(fields.submitReady===true)break;
          await sleep(400);
        }
        remaining();
        otpSubmitted=true;otpAt=now();
        try{await evaluate('otp.submit',{code:match.code,requirePrepared:true});}catch(e){if(code(e)!=='WEB_EXECUTION_FAILED')throw e;}
        page=null;
        // Trash only the exact selected message. Failure does not invent another OTP.
        try{await auto.imap.trash(Object.assign({},credentials,{timeoutMs:Math.min(10000,remaining()),uidValidity:baseline.uidValidity,uid:match.uid}));}catch(e){if(['NATIVE_TIMEOUT','OUTCOME_UNKNOWN','STOPPED'].indexOf(code(e))>=0)throw e;}
        continue;
      }
      await sleep(700);
      } catch(error) {
        // Failed observation or deadline expiry cannot turn an uncertain login
        // into FAILED, where the account queue would submit it again.
        if(loginUncertain && code(error)!=='STOPPED')fail('OUTCOME_UNKNOWN');
        throw error;
      }
    }
  }
  async function lottery(active) {
    await progress('LOTTERY');
    const products=[];
    for(const pid of active.pids) {
      let status;
      for(let i=0;i<45;i++) {
        const result=await read('lottery.status',{pids:active.pids});
        status=result.statuses.find(x=>x.pid===pid);
        if(status.ambiguous)fail('AMBIGUOUS_PID');
        if(status.found && (status.completed || !status.product.disabled)) break;
        await sleep(2000);
      }
      if(!status || !status.found)fail('PID_NOT_FOUND');
      if(status.product)products.push(status.product.name);
      if(status.completed)continue;
      if(active.submissions[pid])fail('REVIEW_NEEDED');
      await evaluate('lottery.expand',{pid:pid}); await sleep(350);
      await evaluate('lottery.select',{pid:pid}); await sleep(550); await evaluate('lottery.agree',{pid:pid}); await sleep(550);
      const operationId=String(now())+'-'+Math.random().toString(36).slice(2);
      await evaluate('lottery.open',{pid:pid,operationId:operationId});
      let popup;
      for(let i=0;i<10;i++){popup=await read('popup.inspect');if(popup.ready)break;await sleep(300);}
      if(!popup || !popup.ready)fail('POPUP_NOT_READY');
      // Persist BEFORE the one-time action: restart can never replay it implicitly.
      active.submissions[pid]={attemptedAt:now(),confirmed:false};
      await auto.store.set('active',active);
      remaining();
      await evaluate('lottery.confirm',{pid:pid,operationId:operationId});
      let confirmed=false;
      for(let i=0;i<10;i++) {
        await sleep(2000);
        const result=await read('lottery.status',{pids:active.pids});
        const item=result.statuses.find(x=>x.pid===pid);
        if(item && item.found && !item.ambiguous && item.completed){confirmed=true;break;}
      }
      if(!confirmed)fail('REVIEW_NEEDED');
      active.submissions[pid].confirmed=true;await auto.store.set('active',active);
    }
    if(!(await read('lottery.status',{pids:active.pids})).allCompleted)fail('REVIEW_NEEDED');
    return products;
  }
  async function notifySuccess(products,start) {
    if(!config.discordWebhook)return;
    if(!/^https:\/\/(?:discord\.com|discordapp\.com)\/api\/webhooks\/\d+\/[A-Za-z0-9_-]+(?:\?[^#]*)?$/.test(config.discordWebhook))fail('WEBHOOK_INVALID');
    const url=config.discordWebhook+(config.discordWebhook.indexOf('?')>=0?'&':'?')+'wait=true';
    const response=await auto.network.request({url:url,method:'POST',headers:{'Content-Type':'application/json'},timeoutMs:15000,
      body:JSON.stringify({username:'Cyusen Browser',content:config.machineName+' · SUCCESS\n'+products.filter(Boolean).join('\n')+'\n'+Math.round((now()-start)/1000)+' giây',allowed_mentions:{parse:[]}})});
    let result;try{result=JSON.parse(response.body);}catch(_){}
    if(response.status<200 || response.status>=300 || !result || !result.id)fail('NOTIFICATION_UNCONFIRMED');
  }
  async function record(outcome,line) {
    if(outcome==='failed')await save('failed',(await bucket('failed')).filter(value=>value!==line).concat([line]));
    else await add(outcome,line);
    if(outcome==='success'){await remove('failed',line);await remove('review',line);}
    if(outcome==='review')await remove('failed',line);
    await remove('data',line);
  }
  async function run() {
    config=Object.assign({},defaults,(await auto.store.get('config'))||{});
    const action=(await auto.store.get('action'))||'run'; await auto.store.set('action','run');
    if(['run','retryFailed','download','reset'].indexOf(action)<0)fail('ACTION_INVALID');
    if(['airplane','shortcut'].indexOf(config.resetMode)<0)fail('CONFIG_INVALID');
    await progress('START');
    if(action==='reset') {config.resetEnabled=true;await resetIP();await progress('DONE');return;}
    if(action==='download') {
      if(!/^[A-Za-z0-9_-]{1,50}$/.test(config.machineName))fail('MACHINE_INVALID');
      const rows=await getSheet(config.machineName,'A6:A');
      const excluded=[].concat(await bucket('success'),await bucket('failed'),await bucket('review'));
      await save('data',accounts(rows.map(row=>row[0]||'').join('\n')).filter(line=>excluded.indexOf(line)<0));
      await progress('DONE');return;
    }
    const pids=String(config.pids).split(/[|,\s]+/).filter(Boolean);
    if(!pids.length || pids.some((pid,i)=>!/^\d{10,14}$/.test(pid)||pids.indexOf(pid)!==i))fail('INVALID_PIDS');
    for(const [name,min,max] of [['otpDelay',1,60],['loginMaxAttempts',1,50],['failurePauseMinutes',0,1440]]) {
      config[name]=Number(config[name]);if(!Number.isInteger(config[name])||config[name]<min||config[name]>max)fail('CONFIG_INVALID');
    }
    const unfinished=await auto.store.get('active');
    if(unfinished && unfinished.line) {
      if((await bucket('success')).indexOf(unfinished.line)<0)await record('review',unfinished.line);
      else await remove('data',unfinished.line);
      await cleanup();await resetIP();await auto.store.set('active',null);
      await progress('REVIEW_NEEDED');fail('INTERRUPTED_ACCOUNT_REVIEW');
    }
    if(config.imapSource==='sheet') {
      const row=await getSheet('config','E3:E3'); const pair=String(row[0]&&row[0][0]||'');const pos=pair.indexOf('|');
      if(pos<1)fail('IMAP_CONFIG_INVALID'); config.gmail=pair.slice(0,pos).trim();config.appPassword=pair.slice(pos+1).replace(/\s/g,'');
      await auto.store.set('config',config);
    }
    config.appPassword=String(config.appPassword).replace(/\s/g,'');
    if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(config.gmail)||!/^[a-z0-9]{16}$/i.test(config.appPassword))fail('IMAP_CONFIG_INVALID');
    if(await stopping())return;
    await cleanup();await resetIP();
    let consecutive=0;
    while(true) {
      if(await stopping())break;
      const excluded=[].concat(await bucket('success'),await bucket('review'));
      let queue=action==='retryFailed'?[]:(await bucket('data')).filter(line=>excluded.indexOf(line)<0);
      if(!queue.length)queue=(await bucket('failed')).filter(line=>excluded.indexOf(line)<0);
      if(!queue.length)break;
      total=Math.max(total,current+queue.length);const line=queue[0],split=line.indexOf('|');
      const active={line:line,pids:pids,submissions:{},startedAt:now()};
      await auto.store.set('active',active);current++;
      deadline=now()+180000;deadlineCode='ACCOUNT_TIMEOUT';
      let outcome='success',products=[],errorCode='';
      try {await authenticate({email:line.slice(0,split),password:line.slice(split+1)});products=await lottery(active);}
      catch(error) {
        errorCode=code(error);
        const uncertain=Object.keys(active.submissions).some(pid=>!active.submissions[pid].confirmed);
        outcome=uncertain||['OUTCOME_UNKNOWN','NATIVE_TIMEOUT','MANUAL_CHALLENGE','REVIEW_NEEDED'].indexOf(errorCode)>=0?'review':'failed';
      }
      deadline=Infinity;
      await record(outcome,line);active.outcome=outcome;await auto.store.set('active',active);
      if(outcome==='success'){done++;consecutive=0;}else{failed++;consecutive++;}
      await progress(outcome==='success'?'SUCCESS':outcome==='review'?'REVIEW_NEEDED':'FAILED');
      await cleanup();await resetIP();await auto.store.set('active',null);
      if(outcome==='success')await notifySuccess(products,active.startedAt);
      if(outcome==='review')fail(errorCode||'REVIEW_NEEDED');
      if(['IMAP_AUTH_FAILED','IMAP_CONFIG_INVALID','IMAP_UIDVALIDITY_CHANGED','UIDVALIDITY_CHANGED','STORE_READ_FAILED','STORE_WRITE_FAILED'].indexOf(errorCode)>=0)fail(errorCode);
      if(await stopping())break;
      if(consecutive>=5) {
        await progress('PAUSE');const until=now()+config.failurePauseMinutes*60000;
        while(now()<until){if(await stopping())return;await auto.sleep(Math.min(1000,until-now()));}
        consecutive=0;
      }
    }
    await progress('DONE');
  }
  return {run:run,accounts:accounts,csv:csv};
}
if(typeof module!=='undefined'&&module.exports)module.exports=createCyusen;

return module.exports; })();

async function main(auto) { return createCyusen(auto,cyusenDOM,cyusenOTP.selectOTP || cyusenOTP).run(); }
